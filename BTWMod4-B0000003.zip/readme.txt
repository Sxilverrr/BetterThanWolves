FlowerChild's Better Than Wolves Total Conversion 4.B0000003
(Compatible with Minecraft Version 1.5.2)

[*** COPYRIGHT NOTICE ***]

This document and the files contained in this package are Copyright �(2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019) and are the intellectual property of the author. All rights reserved.  It may not be reproduced under any circumstances except for personal, private use as long as it remains in its unaltered, unedited form. It may not be placed on any web site or otherwise distributed publicly without advance written permission. Decompilitation and reverse engineering is strictly prohibited without advanced written permission.  Use of this mod on any other website is strictly prohibited, and a violation of copyright.
 
Note: I DO NOT grant redistribution rights to this mod to anyone that asks, whether that be for a mod-pack or whatever. Don't bother asking, as it won't happen.

[************************]

For new versions of this mod, videos, and other useful info, please consult the following thread on the Minecraft forums:

http://www.minecraftforum.net/viewtopic.php?f=1032&t=275333

or consult the official forums for the mod:

http://www.sargunster.com/btwforum/

[****** Installation Instructions ******]

Please consult the following thread for the most up to date installation instructions:

http://www.sargunster.com/btwforum/viewtopic.php?f=9&t=9272

[********* Compatibility Information **********]

Better Than Wolves is designed as a standalone mod and as such does not support compatibility with any other.  Existing compatibly with any given mod is purely coincidental and may be removed without notice in future updates.

[********** Change Log ************]

4.B0000003

-Added the ability to piston pack Loose Stone items into Loose Cobblestone blocks.
-Added more spoilerific feature descriptions to the change log for version 4.B00 (Vegehenna) in the readme.
-Added a sound effect whenever the player can't eat something for whatever reason (like if full, or they have food poisoning).
-Changed blacksmith villager trades involving raw ore to involve nuggets instead, to make them a tad less restrictive.
-Changed (reduced) the price of hoe blacksmith trades to reflect hoes being crafting with 1 ingot instead of the old 2.
-Changed Wicker blocks and slabs to not allow tools to be stuck in them. This should not affect already placed tools.
-Changed the way food poisoning works, so that you can no longer drink potions (or milk) while it is in effect, in the same way that you can't eat food.  This corrects an exploit that made Rotten Flesh way too effective a food item once milk was obtained, serves to make milk a far less effective counter to Jungle Spiders, and also ups the value of splash potions.
-Changed the way lightning strikes calculate damage to entities around them to correct some rare issues with players being killed by them when a strike occurred above them while below ground.
-Fixed a problem where upside down slabs placed next to mature groth wouldn't render correctly.
-Fixed a problem where the Refined Pickaxe and Mattock were not effective versus Obsidian.
-Fixed a problem where Nether Bricks were subject to Piston packing in incorrect quantities.
-Fixed a problem where Blight would devour Packed Earth and Dung Blocks in an entirely unreasonable manner.
-Fixed a problem where strings connecting Stakes would not render correctly at intersections.
-Fixed a problem where eating Cream of Mushroom with a full inventory would not produce an empty bowl.
-Fixed a vanilla problem where Wither Skeletons would spawn in 2 height gaps, resulting in suffocation death.
-Fixed a problem where the contents of the Millstone weren't being appropriately saved and loaded.
-Fixed a problem where signs and skulls weren't properly updating neighboring blocks when placed.
-Fixed a potential crash when placing lit Crude Torches on leaf blocks.
-Fixed and exploit where switching from a baited to unbaited fishing rod could allow you to catch fish without expending bait.
-Fixed a problem where Buddy wouldn't update the power state of neigboring blocks when moved by a piston.
-Fixed a problem where upward facing blocks (like Buddy) would face downwards when rotated on a Turntable.
-Fixed a problem where the player's respawn position was being reset when returning from The End dimension.
-Fixed a problem where Repeaters would pulse briefly when placed.
-Fixed a problem where Stone Brick variants (mossy, etc.) would drop individual Stone Brick items that wouldn't work properly in some crafting recipes.
-Fixed a problem where status effects like hunger and health weren't properly transferred when travelling between dimensions.
-Removed / Deprecated the Mould.  It had never been properly adapted to multiplayer resulting in some pretty severe exploits.  To fix that would take a relatively large amount of work, when from asking around the community it seems like a rarely used feature that no one will particularly miss.  It's unfortunately just not worth having around anymore <sniff>.  Existing Mould items will still hang around in your (or the Anvil's) inventory, but the Turntable crafting method and Villager trade have been removed, and they will no longer remain in the Anvil inventory upon closing <sob>.  Farwell old friend... you will be missed <queues bugles, pours one on the curb, shakes fist at uncaring universe>.

4.B0000002

-Changed the way dirt loosens its neighbors when dug with crappy tools to make for more interesting behavior, and so that dirt slabs loosen in the same manner as full blocks.
-Changed child animals to not grow into adults unless they have the space around them to do so.  This fixes a bug where children would sometimes suffocate upon growing into adults, and puts another juicy nail in the coffin of quantum animal farms.
-Changed (rebalanced) desert and jungle temple loot to be more interesting, and less uber.
-Changed village blacksmiths to generate with water in their trough, rather than lava, as it is more thematically  appropriate and a slightly less advantageous find given how powerful lava can be in the early game. 
-Changed the way chunk generation works slightly, so that changes made to structures (temples, village buildings and strongholds) will no longer affect stuff like the distribution of ores within a chunk or other random "decorative" aspects.  However, this necessitates that such things will be affected one last time for this one release. This will not affect biome distribution or the contour of terrain, or anything major that would cause seams in your world, but will affect minor aspects like where a particular veins of ore or trees may appear within a chunk.  This was done so that changes can be more easily made to things like loot lists and structure details without having to worry about affecting too many other aspects of chunk generation.
-Changed cows to experience less knockback than other animals as befits their stature.
-Changed Mushrooms to be crushed by falling blocks.
-Fixed a problem where sheep were still breeding with Cookies rather than with Pumpkin Pie.
-Fixed a problem where cows wouldn't bestow their hoofsies while grazing.
-Fixed a problem where pistons would occasionally extend two arms when first placed by the player.
-Fixed a problem with the weeds texture not being reinitialized when a new texture pack is selected.  This will hopefully fix rendering issues with weeds that players were experiencing.

4.B0000001 b

-Added new Wet Brick and Uncooked Nether Brick items as the interaction between the clay ball items being applicable as both mortar and placeable brick blocks was creating unnecessary interface confusion.  They're created with a single item of the corresponding type in the crafting grid.
-Changed the various forms of mortar (Clay, Slime, and Nether Sludge) so that it can be applied to blocks regardless of whether you're sneaking or not.  Hence the need for the above new items.
-Changed the color of Nether Sludge to help visually differentiate it from Nether Brick.
-Changed Buckets to no longer place as blocks for similar reasons.  I need to rework that system before proceeding further as it was way too prone to unintended consequences like accidentally placing buckets in lava while sneaking.  Until then, they may still be placed with Block Dispensers if you really feel the need to play with their block form.
-Fixed a duplication exploit with Wicker Slabs.
-Fixed an issue where mobs could spawn on ladders.

4.B0000001

-Added Hardcore Trim.  This means that Shears are now required in order to harvest the top of Hemp plants, without also killing the bottom.  Non-player harvesting (Pistons, Block Dispenser, etc.) isn't affected by this, so as to not interfere with existing builds.
-Added Straw as a new item.  It is harvested from the bottom block of mature Wheat, and may be fed to cows and sheep.
-Added the ability for playas to enchant hoes.
-Changed Hemp to only drop seeds when the top of the plant is harvested, not the bottom.  The texture has also been changed to reflect this.
-Changed Endermen to not be able to teleport onto block types that mobs can't spawn on (eg. wood).  Light levels still do not affect this however.
-Changed the Iron, Gold, and Diamond Hoe recipes to consist of 3 Shafts in a vertical line, with a single ingot to the top/side, instead of the two ingots it previously required, to better balance it relative to other tools.  The Refined Hoe recipe remains unchanged.
-Changed the Brick Oven to allow the player to add any size fuel (logs, etc.) when it is in the last visible stage of burning down (the non-whole-log texture) to make it a little more user friendly.
-Changed a number of mobs and animals to set fire to other entities that they attack while on fire, similar to how zombies worked previously.
-Changed a few things about how entities are unloaded to hopefully reduce the occurrences of players becoming invisible to each other.
-Changed (reduced) the time it takes to weave Wicker as it was rather excessive when making Hampers.
-Changed (refactored) how tool enchantability works internally to clean up the related code a bit.
-Fixed burning wolves and players dropping cooked instead of burned meat.
-Fixed a problem where Reeds could no longer be placed on blocks diagonal to water.
-Removed the recipe for Grass Planters as they opened up a number of exploits with regards to feeding animals, and they no longer really had an intended purpose within the mod.  Such Planters already within your world are unaffected by this change, but new ones may no longer be created.

4.B00 b

-Changed (tweaked) the efficiency of hoes made of different material to be more pronounced.
-Changed the timing on Bellows slightly to make them a little more forgiving.
-Fixed a problem that was causing Bellows to occasionally miss a stroke, which would cause Stoked Fire to randomly die down, and was causing stuff like Kiln cooking to randomly get interrupted.  I also applied this same fix to a number of other blocks (both mod and vanilla) that may have had less noticeable forms of it, as it turns out it was a rather obscure general problem with various kinds of block updates.  It was just most noticeable with the Bellows and Kiln because of the slower timing.
-Fixed a problem where a detached collision box would remain above tilled earth after it had reverted to regular dirt, under certain circumstances.
-Fixed a problem where Redstone Repeaters were not properly updating their state when placed by a Block Dispenser.

4.B00

-Added Vegehenna. It's a feature.  It's a way of life.  It's a revolution.  Vegehenna.
-Added Hardcore Weed, Hoes, and Basket Weaving.
-Added Bread Dough as a new item.  It is crafted with three Flour and a Bucket of Water, and can be cooked in an oven or kiln to bake bread, replacing cooking flour directly.
-Added new flammable Wicker, Wicker Slab, Wicker Pane, Grate, and Slat blocks.  I've split them off from some old combined block ID usage so they should now have more consistent and appropriate behavior overall (step sounds, applicable tools, etc.).  All such blocks already in your world will not be affected by this change, and conversion recipes for old to new blocks have been provided for each block type.
-Added Hopper filtering attributes to a bunch of the newer items and blocks that have been added to the mod.  I fell a bit behind on those, but they should hopefully all be accurate now.
-Added a more detailed change log for version 4.AFFFFFFF to the readme, which contains more spoilers than the original release.
-Added new weeds which will grow on the new tilled earth blocks, and which are capable of growing either alone, or in the various types of crops.
-Added new tilled earth blocks that need a supporting block under them to remain in place, and which support the new weeds.  Already placed tilled earth blocks will remain unchanged to avoid messing with automation, but if the earth is retilled, or the new type of wheat is planted on them, they'll convert to the new.
-Added a new Planter with Soil type which requires irrigation, like tilled earth.  Unlike tilled earth, Planters may be irrigated from directly below, weeds will not grow on them, and they do not need to be retilled after crops are harvested, making them ideal for automation and unsupervised crop growth.  The recipe has also been changed to just be an empty planter with loose dirt, no longer requiring bonemeal (bonemeal may be added to the block once placed, as usual).  Old planters within your world are unaffected by this change, and a conversion recipe has been provided for them.
-Added a new type of wheat that replaces the old and which has its own unique growth properties, left for the player to discover.  Old wheat crops and items will still function as previously to avoid messing with automated builds, but no new ones will be generated within newly generated chunks. This means that old wheat will not be present in any new worlds that are started.  A conversion recipe from old wheat seeds to new wheat has also been provided to kick start your horticultural odyssey.
-Changed Hoes to operate on left-click, and to take time in order to till earth.  They can now also be stuck in blocks for storage, like many other tools.
-Changed (increased) the distance you can fall onto tilled earth without trampling crops so that you can safely step off slabs, to provide a bit more flexibility in farm design.
-Changed Wicker textures to be lower contrast, to look a little more natural.
-Changed hats to be a little easier to wear.
-Changed Pistons to be more resistant to jamming on chunk load.  I haven't diagnosed or corrected the underlying vanilla problems, but I put some code in place to check for when they're stuck in an invalid state with an unextended piston base having an extended piston arm, so that they can fix themselves the next time they're updated.
-Changed (reduced) the number of Donuts cooked in the Cauldron at a time from 4 to 2 to balance relative to the new bread recipe.
-Changed (rebalanced) the Cookie Dough recipe to require 4 Flour (plus Chocolate), rather than just 2.
-Changed the Pumpkin pie recipe to require 3 Flour (plus sugar, a whole pumpkin, and an egg) instead of 1.
-Change sheep to breed with Pumpkin Pie rather than cookies.
-Changed (refactored) a bunch of block and item code to clean things up a bit.  This mostly had to do with the physical properties of items (and blocks in item form) such as buoyancy and Hopper filtering.  The changes to Hopper filtering, and Block Dispenser block placement were particularly extensive so please let me know if you notice any problems there.
-Fixed a problem where Saws were not properly harvesting Vine blocks and other vegetation, and where they would not be appropriately powered if placed directly on a powered Axle.
-Fixed a problem where a large amount of hunger would sometimes be consumed while climbing ladders.
-Removed all modifiers to crop growth based on what blocks neighbor them.  These were vanilla modifiers that were never well understood, and which were difficult to intuit, and thus I did not feel they contributed anything positive to gameplay.

4.AFFFFFFFd

-Added the ability for wolves to seek out tasty food items that are laying on the ground.
-Changed (tweaked) some of the features involved in the Cluckaclysm to refine them further.
-Fixed an issue that was slowing milk and wool production more than intended.
-Fixed a lighting glitch when torches were removed near Brick Ovens.

4.AFFFFFFFc

-Fixed a problem with pathfinding that was still causing some animals and mobs to rarely get stuck in corners.  I believe this fix also noticeably improves the quality of pathing overall.

4.AFFFFFFFb

-Removed certain animals not being able to jump under certain circumstances as it just came across as being buggy.  I'll likely add this back in later once I have a chance to adapt pathing to it.

4.AFFFFFFF

WARNING: Your animals are about to die.  Some will definitely die.  They may all die.  You will reach skyward with freakishly long arms and beg mercy from an uncaring and unresponsive cubic universe.  If you do get a response, it will likely sound a lot like laughter.  If this freaks you the heck out, please consider backing up your savegame before installing this release.  Otherwise, there's nothing to worry about.

-Added Animageddon.  Accept no pork based substitutes.
-Changed the glass block recipe to require 8 blocks of sand and 1 Nether Quartz in a Crucible to produce 4 blocks of glass.  This was done to better balance it relative to other building options.
-Changed the math involved in determining when pathfinding has arrived at a destination slightly to provide more accurate outcomes.
-Fixed a problem where a crash could occur when pumpkins and melons grew on top of their own stem.

Details:

-Added Hardcore Hunger For Animals.  Animals will now need to eat in order to survive.
-Added ability for animals to heal over time if they are well fed.
-Changed animals to graze on crops and various other forms of vegetation (especially pigs).
-Changed wolves to be able to starve to death when possessed.
-Changed animals to only follow handheld breeding items, if they are ready to breed, to help make sorting them a little easier.  Note that this doesn't apply to chickens and Chicken Feed, as that is both a food source and a breeding item.
-Changed chickens to no longer spawn in snow biomes.
-Changed milk, and wool production to be dependent on an animal's hunger.  They will need to be well fed at all times for production to continue and will consume more food than usual while producing, 
-Changed animals to drop Burned Meat rather than cooked when they die while on fire.
-Changed Carrots and Potatoes to not drop a full carrot or potato when harvested before fully grown.
-Changed Wheat and Hemp to not drop seeds unless fully grown.
-Changed (reduced) the rate of Mycelium spread.
-Removed the ability to "cure" Mooshrooms with shears.
-Removed the ability for bonemeal to grow grass and flowers given they are now a food source for animals and not just decorative.


4.ABCFEFE e

-Fixed a problem with AI pathfinding that was causing mobs and animals to run in circles and generally spaz out.  This was particularly noticeable when attempting to get animals to follow you with grass or seeds.

4.ABCFEFE d

-Changed cows and sheep to be able to graze on Grass Slabs, and cows to be able to graze on Mycelium Slabs.
-Changed cows and sheep to clear any snow or ash cover resting on blocks they graze on.
-Changed grass and Mycelium to not grow from or to blocks under snow or ash cover.
-Changed rendering of most full 1m cube blocks slightly to increase performance.
-Fixed a problem where the extended arms of pistons could no longer be collided with.
-Fixed a problem where pistons, piston arms (if appropriately oriented), and blocks pushed by pistons, could no longer support falling blocks.

4.ABCFEFE c

-Changed (refactored) the changes the mod makes to Snowmen to simplify the related code somewhat.
-Changed some vanilla pathfinding code to provide improved performance and more accurate outcomes.
-Changed Netherwart to make sounds more appropriate for vegetation.
-Fixed a problem with Netherwart's collision volume that made it impossible to harvest.
-Fixed a vanilla AI problem that was causing mobs and animals to tend to favor wandering towards the northwest.

4.ABCFEFE b

-Added recipes to convert Iron and Gold Ore Blocks back into chunks.
-Fixed a problem with pickaxes not being effective on Netherbrick stairs and a few other Netherbrick based blocks.

4.ABCFEFE

WARNING: This release substantially changes the rules of mob spawning, in ways that can result in brutal and unexpected dismemberment.  Please make sure you understand the following changes thoroughly before playing in an existing world, lest you come home to a Creeper to the spleen, or to find your rustic wood mob trap's output has dropped to nothing.

-Added a new mob-spawning system that is listed as individual changes below, but as a summary of how it all works: mobs can now spawn on almost any shape of block, but are restricted by the materials they can spawn on.  No mobs can spawn on wood, giant mushroom blocks, Mycelium. or Bedrock.  Jungle spiders are the only mobs that can spawn on leaves (as before).  In the nether, mobs may only spawn on Netherbrick or Netherrack (as before).  That's it, that's all.
-Added new flammable giant mushroom blocks.  This will not affect blocks already placed in your world, but since mushrooms will now potentially grow into giant flaming emblems of the apocalypse, be sure to check in on any farms you have that might be affected.
-Added Blocks of Iron and Gold Ore.  These can either be created in the crafting grid with 9 ore, or through piston packing.  They can be smelted in a Kiln for a full ingot, which provides both a means of smelting in bulk, and an alternate method of automating ore smelting.
-Added the ability to see where mobs can spawn in the Nether while wearing Ender Spectacles.
-Changed all mobs to be able to spawn on pretty much any kind of block. I may have missed some, but the goal here is to reach a point where if there's room for a mob to reasonably stand on a block, it can spawn there.  If I forgot any, I'll correct them in the future, so please don't rely on block shape to prevent mob spawning anymore as it may change at any time.
-Changed mobs to not be able to spawn on blocks primarily made of wood (a thin surface layer like on Pistons and Turntables won't prevent spawning). The overall intent here is to make mob spawning less block type and more material dependent, both so that there's more of a progression and internal consistency to being able to build with spawn-proof blocks, and to further emphasize the unique building properties of different block types. Any flaming death that results is purely coincidental, as is any perceived glee I may seem to express at such events.
-Changed mobs to be able to spawn in 1-block high gaps if their body shape allows it.  This mainly applies to the various types of spiders, but also prevents exploiting certain block shapes to create player walkable areas that mobs can't spawn in.
-Changed mobs to be able to spawn on ice.  This was done to prevent frozen bodies of water from being big safe zones, especially in the early game.
-Changed mobs to be able to spawn on glass blocks to prevent glass from being a non-flammable, non-gravity-affected, non-mob-spawning, commonly-available, uber-material-of-doomy-doom-doom.
-Changed slimes to not be able to spawn on wood (like other mobs) in addition to their existing spawn restrictions, which remain unchanged from previous releases.
-Changed Ender Spectacles to accurately reflect all the changes to mob-spawning in this release.  If you're uncertain if a particular block type can spawn mobs on top of it, then Ender Specs are an ideal way to find this out.
-Changed (refactored) how the burn times for various blocks work internally for the sake of simplifying the related code a bit.
-Changed (refactored) a metric dung-ton of block code, both vanilla and mod, in the process of fixing the collision thing I describe below.  Please let me know if you run into any new weird block behavior, as it would be exceedingly unlikely that I didn't make a single mistake in the process.  On the bright side, I made a number of small unlisted improvements as I went along as well.
-Changed a number of blocks to render fewer non-visible faces to help with performance, in the process of refactoring their code.
-Changed cows to panic if you attempt to milk one that doesn't have a full udder.
-Fixed a problem where spiders targeting something other than the player could wind up hanging around without despawning for an exceedingly long time.
-Fixed a few vanilla problems where mobs (and other entities, like items) would sometimes fall through slabs and other sub-blocks, which became more noticeable now that mobs can spawn on them.  This is not related to the various visual glitches which can occur along these lines with entities bouncing between positions, but rather the entities themselves sometimes actually passing through the block.  Major thanks to Alexander Gundermann (taurose) for diagnosing and thoroughly documenting several Minecraft collision bugs here: https://github.com/taurose/Unglitch, as the information he has provided has been invaluable in resolving some of these issues.  This fix only covers the first issue (the race condition) he describes (as well as some secondary issues I discovered), but I'll likely be verifying and fixing a number of the problems he documents in upcoming releases.  Suffice it to say there are a LOT of collision issues in 1.5.2.
-Fixed vanilla problem where mobs and animals would get stuck in blocks and sometimes suffocate on chunk load.  This corresponds to item 3 (Floating Point Errors on Entity Load) in the documentation linked above.  Note that when loading old saves or chunks you may still see such errors occur, as the mobs in question will have already been saved embedded within those blocks, but it won't happen again to any new or non-embedded mobs after that first load.
-Fixed vanilla AI/pathfinding problems with animals getting stuck in fence corners (or the corners of other partial blocks) and refusing to move unless pushed out.  I greatly reduced such entities lingering excessively around non-corner edges as well, as they were often times trying to move through those blocks instead of pathing away from them before this fix.
-Fixed a problem where ground cover (snow and ash) resting around cobble walls would change the shape of the wall.
-Fixed an issue where Hand Cranks could no longer rest on top of Mill Stones, for I am a river to my people.
-Fixed a problem where dedicated servers would crash on startup if they were using the mod's config file.
-Fixed a problem with the Saw block playing a sawing sound when first placed, and under some other odd circumstances.
-Fixed a vanilla problem that was limiting the number of mobs that would spawn in flat areas with lots of ground cover like snow, or tall grass.  This was particularly noticeable in superflat worlds where it would prevent mobs from spawning entirely, but affected general mob spawning as well.
-Fixed a problem where Iron Chisels could not be stuck as blocks into Cobblestone.
-Fixed a problem where Pickaxes could be stuck as blocks into glass.
-Fixed a problem where Jack'O'Lanterns would still drop a torch when extinguished by water, even though they are now crafted with a Candle.
-Fixed a vanilla issue where some chunks would not properly render, even though they were fully loaded on the client, resulting in lines of missing chunks in the world.  Much thanks to Andr�s del Campo Novales for providing a very simple solution to this problem here: https://bugs.mojang.com/browse/MC-129 .  Please let me know if you see any new chunk or visual oddities as I suspect there might be a bit more work to be done here.  I've seen what felt to be a few weird things here and there, but overall this feels like too big an improvement to do without.
-Removed the config files options for limiting slime and nether mob spawning.  Given the extent to which mob spawning has now changed, configuring individual aspects of its behavior is no longer feasible, and I do not believe these options were used much anyways.
-Removed all the high-efficiency crafting recipes involving stone sub-blocks, as they were rendered obsolete by the inclusion of Stone Bricks in the last release.

4.ABCFAFBFC

-Added the Stone Brick as a new item.  Stone Bricks can be harvested in place of Loose Stones by using an Iron Chisel on Smoothstone blocks. They may also be created in greater numbers by combining Smoothstone Blocks with an Iron Chisel in the crafting grid (similar to splitting wood with an axe), and individual bricks can be split into Loose Stones via this same method.
-Added Loose Stone Brick blocks, stairs and slabs as new block types.  They may be crafted with individual Stone Bricks, in the same manner as similar blocks. Applying mortar to them to create vanilla Stone Brick blocks replaces the old creation method entirely.
-Added Loose Nether Brick blocks, stairs, and slabs as new block types.  As with Stone Brick, applying mortar replaces the old creation method.
-Added a variant of Netherrack that is affected by gravity.  Netherrack will now function as before when placed in the Nether, but if placed in other dimensions, will be subject to gravity.  Blocks already placed in your world will continue to behave as before, regardless of dimension.
-Added variable cook times for different block types to the Kiln, similar to the Brick Oven, and increased cook times overall.  Stuff like chunks of ore and logs will now take much longer to cook than baked goods.  This was done to further incentivize automation, as well as to increase the value of having multiple Hibachis in use.
-Added an additional particle effect (white smoke) when something is cooking in the Kiln, as the slower cook times made it difficult to tell if it was working.
-Added a new Smoothstone creation method where running lava over Loose Cobblestone or Loose Stone Bricks will fill in gaps in the block with hot lava.  Running water over the resulting block will then cool it off, forming a Smoothstone block.  Along with other changes in this release, this new system is intended to replace all other methods of stone generation previously in the game.
-Added the Lava Pillow as a new block type.  This block replaces the Smoothstone and Cobblestone that was previously created when lava blocks came into contact with water blocks, effectively removing lava based cobble generators from the game.  Note that the Lava Pillow may not be harvested intact through any means, including silk touch or the Block Dispenser.
-Added recipes for the stairs of the various "Loose" blocks (Cobble, Brick, etc.) that use 3 full blocks or slabs of the type in an "L" pattern in the crafting grid so that such stairs may be crafted in the player's inventory.
-Changed several crafting recipes involving Smoothstone to use Stone Bricks instead.  This affects the following: Hand Crank, Mill Stone, Turntable, Hibachi, Anchor, Piston, Redstone Repeater, Lever, Dispenser, Block Detector, Block Dispenser, Buddy Block, and the Chopping Block (now 8 bricks in a 'U').  Basically, almost every block that isn't entirely made of Smoothstone (like stairs or slabs) now uses Stone Bricks instead.
-Changed the Saw to take longer to cut blocks to further incentivize automating it, and adjusted the associated sound to fit the new timing better.
-Changed Chunks of Iron and Gold Ore to have a random facing when placed, rather than one based on player orientation, to make them feel a tad more irregular.
-Changed the name of the Stone item to "Loose Stone" to help further differentiate it from Smoothstone blocks.
-Changed Cactus blocks to be destroyed when hit by lightning.
-Changed (refactored) the way Oak and Nether Brick fences work internally to hopefully resolve some collision issues with them.  This change is largely a test that is being discussed on the BTW forums, and other fence types will be converted to this new format if the test is successful.
-Fixed a problem where Slimes, Squid, and Ghasts weren't reliably despawning within spawn chunks.
-Fixed a vanilla problem where Fireballs and Wither Skulls could hang around indefinitely in your world.
-Fixed a potential crash when baskets would catch on fire.
-Removed the ability to stop Cement from drying by applying a redstone signal to it.  This removes another form of infinite stone generator from the game.
-Removed the ability to harvest whole Smoothstone blocks by isolating them from their neighbors and then harvesting.  In practice I found this mechanic to be rather clunky and unintuitive, and the need for it has been largely replaced by the inclusion of Stone Bricks.

4.ABCFAFAFA :bee:

-Fixed a problem where the Block Dispenser couldn't place Chunks of Iron and Gold Ore.

4.ABCFAFAFA

-Added a new type of Gearbox block, or more precisely, split Gearboxes into two different types.  The existing one has been renamed to "Redstone Clutch" and its recipe remains the same (using a redstone latch).  All existing Gearboxes in your world will be converted to a Redstone Clutch block.  The new Gearbox is crafted in the same manner as before, but with an Axle in the middle of the grid, rather than a latch. It functions in a manner identical to the old Gearbox, except it can no longer be turned off via redstone.  This was done because I found the increased value of Gearboxes that resulted from the inclusion of the latch in the recipe had unfortunate side-effects like inspiring people to deconstruct their existing devices to build new ones, or to avoid automation projects all together because of gold shortages.  Hopefully this change will represent a better balance between gold value and automation fun-time.  Note that I've also added new textures for both kinds of Gearboxes to make them more visually distinct.
-Added a new Lightning Rod block that is crafted with a vertical line of 1 gold ingot as a base, with two gold nuggets above it.  It replaces the functionality of the old one entirely, and adds a number of additional aesthetic options as well in that it can be anchored to a block in any direction, not just below it. It draws any lightning bolts that are striking a lower point up to 16 blocks away from it horizontally to the rod instead, and this is checked after the bolt is drawn to any nearby high points, guaranteeing that the area around the rod will be totally safe.
-Added a new Iron Spike block that is crafted with a vertical line of 1 iron ingot as a base, with two iron nuggets above it.  It is intended to replace the aesthetic uses of the old Soulforged Steel lightning rods, and looks identical to how the old ones did, but with the additional aesthetic options of the new Lightning Rod.  A reminder that these kinds of blocks make excellent Candle holders, which is a much bigger deal now given the fire-starting tendency of torches.
-Added the ability to place Chunks of Iron and Gold Ore as blocks, and to smelt them in a Kiln.
-Added the ability to melt down the Piston Shovel in the Crucible.
-Added the ability for ground cover (snow and ash) to share space with a few additional blocks: Shafts, unlit Torches, unlit Campfires, tools stuck in blocks, Flower Pots, Fences, Redstone Dust, Buttons, Levers, Urns, Axles, Vases, Stakes and String.
-Added a concussive effect to lightning strikes.
-Changed Gear Boxes so that they may not be rotated by right clicking if they have any connected axles.  This is to make them feel a little more solid once placed, and to prevent accidents involving mistakenly right clicking on a block resulting in broken automation builds.
-Changed Gear Boxes so that they will display their output texture on the side opposite the input, if they have no connected output axles.  This sounds complicated but should be intuitive in practice, and makes orienting them easier under many circumstances.
-Changed lightning to "travel" further when looking for a high point to strike.
-Changed lightning strikes to take entities into account in determining the highest point in an area to strike.  This makes stuff like standing in an open field, or on a hill, during a lightning storm, an exceedingly bad idea.
-Changed lightning strikes to occur in Desert biomes when there's a storm raging.  This makes the desert just a wee bit less of a base building uber biome, and more of a barren uncaring landscape of unending torment.
-Changed the name of the old Lightning Rod to "Old Soulforged Rod", and removed its crafting recipe. It only remains to melt down or for decorative builds that already make use of it. 
-Changed how the flames on Candles look, to make them a little more candley.
-Changed Mycelium slabs to display a snow side texture when snow cover is resting on them, just like with the full blocks.
-Fixed a problem where a Mycelium full block wouldn't display its side snow texture if it had snow cover resting on it, and if the snow cover was combined with another block.
-Removed an extraneous space from the filename of the "fcBlockTorchFiniteIdle_burned.png" texture file, as it was reported to be causing problems on some systems.

4.ABCF:dancer::poo::dancer: :bee:

-Fixed a problem where spawn chunks would continue to be updated even after all players had left a server.

4.ABCF:dancer::poo::dancer:

-Added a big revamp of how chunk loading and block/entity updates work to create a more consistent system overall.  The individual changes involved are listed below, but as a quick summary: chunks around original spawn are now fully loaded and updated.  Chunks are loaded up to 10 chunks away from the player / original spawn, and all entities and blocks are fully updated up to 8 chunks away.  That's all the explanation really needed to understand how chunk loading now works.
-Added the ability to activate (right click) string blocks stretched between two Stakes to find out how much distance is between them.
-Added the ability to place Buckets as blocks and to push them over a ledge with a Piston causing them to tip over.  In situations where either using the bucket or placing the block are both valid (collecting water, or placing it for example), sneak clicking will force placement of the bucket as a block.  At present this feature isn't very useful as it is part of a larger system I am continuing to develop, but they are fun to play around with regardless, and are an interesting decorative block in their own right.
-Added a display of the number of chunks loaded in each dimension to the F3 debug display.  This was primarily for my own use in tracking down various issues with chunk loading, but I left it in for now to help diagnose any potential issues that might still be lingering.  Note that it'll only work in single player games as the display relies on the server being on the local computer.
-Changed logs to provide a Shaft when their 2nd level is punched, rather than just when a tool is used.  This was done to speed up first day progress a smidge.
-Changed the Campfire to burn a bit longer for a given amount of fuel, while requiring less fuel to cook a piece of food.  This means that food will take as long to cook as before, but less fuel will be consumed in the process, easing early game resource demands slightly.
-Changed the Campfire to smoulder for longer after going out to give the player more of a chance to relight it.
-Changed Snow and Iron Golems so that they can be created by hitting any of the blocks (snow or pumpkin) used to construct them with a Soul Urn, rather than just the head.
-Changed the Wither to be summoned by hitting its block construct (Bone Blocks and Infused Skulls) with a Soul Urn as is done with Golems, rather than by just placing the blocks.  
-Changed a few non-progression related villager trades involving chocolate to make it a resource that peasants want to buy rather than one they sell.
-Changed a few non-troublesome details about the Wither's behavior which are left to the player to discover.
-Changed the Jack'O'Lantern recipe to require a Candle rather than a Torch to reduce their effectiveness as a non-fire-starting light source somewhat.
-Changed spawn chunks to behave in a manner more consistent with other loaded chunks.  They will now update in the same way as chunks around the player, making original spawn an automation paradise. Note that these chunks will now even update when players are in other dimensions. In all cases I've tried to make this behave as if there's a player always standing at the original spawn location, but please let me know if I missed anything as it's a rather complex change, and one that can be difficult to test given it functions in the player's absence.  There will of course be some performance overhead to this change, given it means a larger number of background updates going on at all times, but given that these chunks were partially loaded anyways, I haven't found the performance impact to be severe in my own tests.  I've also performed a number of optimizations and bug fixes in this release that may even negate the performance loss entirely.
-Changed the despawn distance on mobs to be a rectangular solid rather than a sphere, to match the spawn distance.  This should aid performance somewhat as mobs won't be spawning just to instantly despawn as much, and result in more consistent spawning behavior overall.
-Changed (increased) the number of hostile mobs that can be in the world at any time to compensate for the decreased density of them due to the above change to a rectangular despawn volume.  This should result in mob density being roughly equivalent to what it was in previous versions in most cases, but will increase mob trap output somewhat if the surrounding area is well lit and all spawns are channeled into a small space.
-Changed updates of various kinds, including mob spawning, to occur up to the full world height (256 blocks), allowing automation projects and mob traps to be built as high as you like without their functionality being affected.
-Changed scheduled block updates to only occur up to 8 chunks away from the player/original spawn, instead of the full 10 that are normally loaded, for consistency with other update types, and to fix a number of issues (both vanilla and mod) with blocks loading neighboring chunks during their updates.  This was actually causing a large number of chunks to load when they shouldn't, especially in the nether (from fire trying to spread), which I suspect was a rather significant drain on performance.  These chunks would often also not be appropriately unloaded, resulting in memory leaks.  I think that in many cases this change alone may compensate for the performance cost of fully updated spawn chunks in this release.
-Changed unscheduled/random/irregular block updates (grass and crops growing, etc.) to occur up to 8 chunks away from the player/original spawn, instead of the 7 in vanilla, to be more consistent with other update types.  My goal here was to make the overall system easier for players to understand by using consistent distance values for a number of different update types. 
-Changed chunk loading to get rid of some extraneous chunks at a larger than normal distance around original spawn that vanilla was keeping unnecessarily loaded, to help with performance.
-Changed the view-distance dedicated server parameter to appropriately scale the distances at which entities and blocks update to solve a number of potential issues with its use.  All update distances mentioned in this release should now be appropriately scaled by this value, including those around original spawn.  This should solve problems where adjusting that parameter could seriously mess up mob spawning in particular.
-Changed a bunch of other small internal details about chunk loading/unloading and updates to improve performance, reduce chunk loading errors, and to facilitate future development.  At a certain point the number of changes became too large to track individually.
-Changed (refactored) how Wolves, Witches, Slimes, Endermen, Skeletons, Blazes, Pigmen, Magma Cubes, Ocelots, Bats, the Wither, and Villagers work internally to simplify the related code.
-Fixed problems where the gravel slab recipe involving two gravel blocks would return 2 slabs instead of the appropriate 4.
-Fixed a problem that prevented the Hopper from inserting items into Hampers.
-Fixed a problem where items in Brick Ovens would be improperly position when using the fast graphics option.
-Fixed a problem with tree stumps converted into Workbenches being retrieved intact by the Block Dispenser.
-Fixed a problem where quickly glancing at an Enderman, for a shorter time than would normally cause it to attack, could still cause other nearby Endermen to attack you.
-Fixed a mod issue where brown mushroom generation would cause unnecessary chunk loading / memory leaks.
-Fixed a mod issue where Witches spawning around Witch Huts could cause unnecessary chunk loading / memory leaks.
-Fixed a vanilla issue where zombies were causing unnecessary chunk loading / memory leaks while pathing.
-Fixed a vanilla issue where lava generation in the nether would cause unnecessary chunk loading / memory leaks.   
-Fixed a vanilla issue with village doors causing unnecessary chunk loading / memory leaks.
-Fixed a vanilla issue where players travelling between dimensions would cause unnecessary chunk loading / memory leaks.
-Fixed a problem where Iron Golems could still be created just by placing the pumpkin "head" block, without using a Soul Urn.
-Fixed (maybe) a problem where the player would rarely be attacked by invisible mobs upon repeated hardcore respawns.  This was a very infrequent bug, so unfortunately I can't be 100% certain it's actually resolved.  Please let me know if you run into it after this release.
-Fixed an issue where falling blocks could not rest on Light Blocks.
-Removed the ability to insert items into the Brick Oven with a Hopper, fixing a few related bugs in the process.  Such insertions were never intended.
-Removed vanilla restriction on mobs not spawning within 24 blocks of original spawn for more consistency.  Having a no-spawn volume smack in the middle of the now always active chunks didn't make much sense.

4.ABCEEFABc

-Fixed a problem with a villager trade involving bones that exceeded the new 16 stack limit, making the trade impossible to complete.  Any such trades they may already have will be automatically removed from your villagers.
-Fixed a crash when attempting to use a Fire Charge to light a Brick Oven.

4.ABCEEFABb

-Fixed a problem where Sheep would drop Wool blocks when sheared instead of Wool items.

4.ABCEEFAB

-Added new regular Torches (the ones made with nethercoal) that start fires above them in the same way as Crude Torches.  This does not affect lit torches already placed in the world, so your existing builds are safe.  This was done both as part of my ongoing effort to make fire a more interesting part of the game, and also to increase the value of late game lighting options like Glowstone, Light Blocks, and the Lens. These new torches may also be crushed by falling blocks, like Crude Torches. The flame particles have been removed from the old torches, to make them a little easier to identify.
-Added Burned Meat as a new item.  It's created when food is cooked for too long over a blazing campfire, and is similar to Cured Meat in terms of being a substandard processed meat product.  This will hopefully serve to better instruct new players in how the Campfire works, and can also work as an emergency method of quickly sterilizing meat in a pinch.
-Added a sound effect for when Campfires die down to a small state, to make maintaining them a bit easier.  Also changed the sound when they burn out so that it's easier to distinguish from the Crude Torch sound.
-Added the ability to burn flowers in Campfires and Ovens, just in case your world has yet to be completely reduced to an ashen husk.
-Added a Pile Of Gravel drop to the first level of Smooth Stone chiseling, to provide a little more feedback to players that their chiseling is doing something, and to create an interesting mechanic where having a lot of exposed stone has some small advantages in the early game.
-Added Chicken Feed as a new Item.  It is created by combining seeds and Bone Meal in the crafting grid.  Its role is explained below.
-Added an indicator next to the crafting output when recipes output secondary items (eg. bark and saw dust when splitting logs).  Note that I have to manually set these indicators at present, so if I missed any, please let me know.
-Added Bone Fish Hooks as a new item.  These are created with a single Bone in the crafting grid, which then turns into an item that needs to be worked over time to complete, similar to knitting.
-Added sound when baiting Fishing Rods.
-Changed the Fishing Rod recipe to be shapeless and to use only a single stick, 2 string, and an iron nugget (or Bone Fish Hook), so that it can be crafted in the player's inventory.
-Changed (decreased) the odds of catching fish somewhat, and changed fishing to require water source blocks rather than just regular water blocks, to prevent some exploits with man made ponds.
-Changed Fishing Rods to have less durability than previously.
-Changed the breeding items for various animals listed below to make wheat less of an uber item and to introduce some additional late game activity diversity.  Note that this may make automating the breeding of some of them impossible, which is something that will be addressed in future releases.
-Changed Chickens to breed (lay eggs) with Chicken Feed instead of seeds.
-Changed Pigs to *only* breed with Chocolate, whereas they could be bred with a variety of items previously.
-Changed Sheep to breed with Cookies rather than wheat.
-Changed Cows to breed with Cake rather than wheat.
-Changed fire blocks to no longer be extinguished just by clicking on them in order to make fire a more dangerous and persistent threat, as well as to make it more consistent with the fire mechanics added with burning ladders.  Note that fire may still be extinguished with water, or smothered with other blocks, it's just slightly trickier to deal with now.
-Changed (increased) the lag tolerance on Fire Ploughs and Bow Drills slightly to help reduce issues in high latency SMP games.
-Changed the order in which items are shift-clicked into the player's inventory from other containers (like chests) so that it's more consistent with stuff like picking up items.  This handles stuff like how when you pickup an item, it'd go to the leftmost slot of your hotbar, but if you shift click it from the crafting grid, it'd go to the rightmost.  This is just a small quality of life thing, but the inconsistency really annoyed me.
-Changed the name of Stone blocks to "Smooth Stone" to reduce confusion with the individual Stone item.
-Changed Gravel, Sand, and Dirt blocks to consist of 8 piles (4 for slabs) in order to provide a bit more resolution to pile drops, such as with the change to Smooth Stone chiseling listed above.
-Changed (increased) the minimum amount of hunger the player can respawn with after death, to make death spirals slightly less punishing.
-Fixed a problem where ladders weren't displaying the crack texture correctly while being harvested.
-Fixed a problem where tools placed as blocks wouldn't update neighboring blocks when first placed.  This would result in stuff like water not flowing into the block and such.
-Fixed a problem where Snow Golems could not be created with the new snow blocks that were added in a recent release.
-Fixed a problem where pushing both an unfired pottery (like an Urn) block, and the block below it, at the same time with pistons, could result in a visual duplicate of the unfired pottery block.
-Fixed a problem where wolves would sometimes just sit back and chill in the middle of attacking you.
-Removed zombie villagers decaying into regular zombies with time as I didn't like how it played out in the mid to late game when respawning near a village and just needing to wait out the decay to collect the bootsies.  Its main purpose was to discourage the early game wheat rush, which is no longer as much of an issue anyways due to the above changes to animal breeding.

4.ABCEEEFAb

-Fixed a potential crash when converting an old Millstone inventory into a new one.

4.ABCEEEFA

-Added Clay Piles as a new item.  Clay blocks harvested without a shovel will produce Piles, much like with Dirt, but in the case of Clay only a Stone Shovel is needed for a full harvest.  2 Clay Piles may be combined in the crafting grid to produce a Clay ball.
-Added crafting sounds to the Anvil and Mill Stone.
-Added new Blocks Of Oysters and the corresponding slabs, which may be piston packed out of 16 Creeper Oysters.
-Changed Sandstone blocks to be harvested whole with Diamond Picks (or better), instead of through the isolate & chisel method of regular stone. The intent here is to make sandstone a more practical mid-game building material without saturating the early game with versatile building blocks.  This applies to sandstone stairs and slabs as well.
-Changed the direction in which the Piston Shovel ejects items so that it's a little more consistent, similar to the changes to the Mill Stone in the previous release.
-Changed (increased) the loss of durability when an Iron Chisel is used to convert a Stump into a Workbench, to make doing so more of a strategic consideration rather than something you can just spam all over the place.
-Changed Bone items to only stack up to 16, to be more consistent with other similar packable mob drops, and to further incentivize piston packing.
-Changed how the Fire Plough works internally to hopefully resolve some issues with it sometimes not working properly in SMP.
-Changed how multiple hardcore respawns in the same area work to discourage some exploits.
-Fixed a problem where re-opening a Hamper while the lid was in the process of closing could cause a looping sound to be played.

4.ABCEEEEF

-Added a new Hamper block as an early game storage option.  It may be crafted with 8 pieces of Wicker surrounding a single Planks block. It's intended to help smooth out the progression from Baskets to Chests.
-Added the ability to use the Anvil (formerly "Dead Weight") as a Workbench, while removing the ability to craft Workbenches.  This means that Stumps and Anvils have now completely replaced vanilla Workbenches in terms of functionality.  I also changed a number of aspects of the Anvil's behavior in the process to bring it more in line with other mod blocks. As before, Anvils may be crafted with 7 iron ingots in an "I" pattern, or found in villages.
-Added Metal Fragments as a new item, which result when Anvils are harvested or otherwise broken, and which may be melted down in the Crucible.  Anvils can only be moved intact through silk touch or a Block Dispenser.
-Added a GUIless interface to the Mill Stone, gave it an audio and visual revamp, and changed it to only be able to hold a single item at a time.  Any items you previously had in one are safe, and can either be retrieved by right clicking on the Mill Stone, or they will be processed as normal until the inventory is exhausted.
-Added crafting sounds to swords.
-Added a lossy conversion recipe from Wicker Baskets back to Wicker items.
-Changed the Mill Stone to eject items in more predictable directions once done milling.  This should prevent old issues like items occasionally winding up directly below or above the Mill Stone due to odd trajectories, and make automating it a little more intuitive.
-Changed how items eject from chiseled / incrementally harvested blocks (logs, smoothstone, etc.) to better represent the facing being hit, similar to the above change to the Mill Stone.
-Changed the sounds when placing Chisels as blocks to better reflect the block material they're being placed in.
-Changed the Grate recipe to consist of 5 Shafts in a '+' pattern, with either 4 Hemp Fibers or String in the remaining grid spaces.
-Changed the Wicker Pane recipe to be shapeless with a piece of Wicker and a Grate.
-Changed (reduced) the rate at which the Hardcore Spawn radius increases as the game progresses, to provide more overlap with earlier respawn areas.  This is to further incentivize building up individual respawns and overall infrastructure, as there will be a greater chance of being able to make later use of it.
-Changed how Hardcore Spawn works internally to provide more varied respawn locations.  This doesn't change any of the related mechanics, it just refines the math involved some so that repeatedly respawning in the same place becomes less likely.
-Changed Giant Spiders to not have silk, and Skeletons to not have bows, when created by mob spawners.  This is to reduce rare early game progression workarounds, and to be more consistent with spawner creatures not having weapons and armor.
-Changed Anvils to not spawn in abandoned or partially abandoned villages given how useful they are now.
-Fixed a problem with Hand Cranks, Turntables, and Mill Stones dropping the old Cobblestone blocks when they break.
-Fixed a problem where lightning strikes weren't traveling as far as intended when checking for nearby high points.
-Fixed an occasional crash that would occur with falling blocks.
-Removed the recipe for Chests that involves Planks.  This means you'll now need to use a Saw to obtain Wood Siding to create chests, with the Hamper that's been added acting as an earlier storage solution.

4.ABCEEEEE

-Added a new Piston Shovel block which may be crafted with 6 iron ingots in a stair shape.  The details of its use are left for the player to discover.
-Added new Ladder blocks which are flammable and which can be dislodged by water or falling blocks.  This does not affect already placed Ladder blocks so as not to mess with existing builds, but otherwise the new blocks replace the old.
-Added alternate Loose Cobblestone and Brick Stair recipes involving loose blocks of the corresponding variety, rather than just Brick and Stone items.  This was done for consistency with other stair recipes.
-Added the ability to rotate a few additional blocks on the Turntable, like Powered Rails, Detector Rails, Shafts, Jack'O'Lanterns, and Stakes as part of the refactoring work described below.
-Added the ability to Silk Harvest various slabs, like grass and mycelium.
-Added conversion recipe from Bookshelves back to Books.
-Changed Chisels to not be efficient at harvesting stone once it has reached a certain damage level (once all the stone items have been harvested / pried loose, and the texture changes to its final level).  This is to make early game tunneling less effective given recent increases to Chisel efficiency making it more viable than I had originally intended.
-Changed (refactored) the way block facing works internally for many blocks and how the Turntable rotates attached blocks to help make supporting additional block types easier.
-Changed Cactus to not be destroyed when hit by spider webs.
-Changed Bone and Flesh blocks to drop individual items of their type when in front of a Saw, rather than whole blocks.
-Changed Campfires to be crushed by falling blocks.
-Fixed problem where Snow Cover wasn't melting as intended near fires.
-Fixed a problem with falling Sand Slabs looking like gravel.

4.ABCDEFPotato c

-Fixed a problem where the Minecart With Chest crafting recipe wasn't working.

4.ABCDEFPotato b

-Fixed potential crash when placing Campfires immediately next to Snow or Ice blocks.

4.ABCDEFPotato

-Added a whole new set of snow blocks that serve as an early game building material.  The details of these are left to the player to discover, but one thing to note is that you can build out sideways with them if proper care is taken.  Old snow blocks have been renamed as "Old Snow", and may no longer be crafted.
-Added the ability to partially open Wicker Baskets by right clicking on them.  Note that the baskets will close automatically when you walk away, but you can also close them manually by clicking on the edge of the lid (a box will appear when you're over the right area).
-Added ability for Lava to set nearby blocks on fire directly.  This applies to stuff like Campfires, Unlit Torches, and Logs, that can burn without a neighboring fire block.  Keep this in mind if you have any weird builds like Lava running through Log sluices or what have you.
-Added the ability for Ice and Snow Cover blocks to melt due to nearby fire sources, rather than just due to light levels.  Please keep this in mind if you have any structures built out of ice.
-Added the ability for Fire Charges to directly ignite blocks like Campfires, Brick Ovens, and Torches when used by the player.
-Change Snow Cover blocks to drop Snowballs regardless of whether they are harvested with a shovel.
-Changed the texture on Wicker Baskets to provide an indication of which way they are facing.
-Changed Ghasts to drop Fire Charges instead of Nitre to make farming them a tad more rewarding.
-Changed Zombie AI to make them a little more interested in accessorizing their wardrobe.
-Changed the way cooking items are positioned within the Brick Oven so they're a little more visible, and so that they orient correctly to the direction the oven is facing.
-Changed how items eject from Wicker Baskets so that they tend to travel towards the front of the basket.
-Changed (adjusted) the selection box on Chewed Logs and Log Spikes to be a little less obtrusive.
-Fixed a problem with Ghast sounds in the overworld, that was causing them to be louder than intended when they weren't attacking anything.  
-Fixed a problem where Bloodwood Saplings couldn't plant themselves if Ash was covering a Soulsand block.
-Fixed vanilla problem where you could mine blocks while using an item, like drawing a bow, blocking with a sword, or eating food.
-Removed the generation of Ash from the burning of Bloodwood leaves, as it didn't really suit the nether very well.
-Removed the ability to place string as a block, as it never worked particularly well and conflicts with some of the design intent behind early game storage of items as blocks in the mod.
-Removed the crafting recipes for Tripwire Hooks given the above, and given they're duplicate functionality with the Lens that never suited the mod very well.  I probably should have just done this when they were first released, but I was much more timid about removing vanilla features back then.  You can still melt them down for a bit of iron in the Crucible if you have any laying about.
-Removed the Tripwire and Dispenser traps from newly generated jungle temples to fit the above.  Also removed all remaining Piston and Redstone blocks from newly generated non-looted temples to negate their sometimes progression-breaking impact.

4.ABBBBURNBABYBURNAHAHAHAHAHA b

-Fixed a problem where damaged logs could cause a crash when burning.

4.ABBBBURNBABYBURNAHAHAHAHAHA

-Added Cured Meat as a new food item. It is created by combining a piece of raw meat (or fish or chicken), and Nitre in the crafting grid.  Curing meat actually decreases the hunger value of raw food items, but it does eliminate any chance of food poisoning, and cured meats may also be stacked in greater amounts for easier storage.  Note that eating too many cured meats may result in a mild BURNing sensation.
-Changed the way lightning works so that it has an increased chance of creating fires that won't be immediately extinguished by rain.  WARNING: Please keep this in mind if you have any flammable structures that may get hit by lightning and BURN BURN BURN!
-Changed the way fire spreads to reduce the number of log blocks that remain suspended in the air after trees BURN!  This may not solve the issue completely, but should at least make it a bit less annoying to clear jungles and such by BURNing them down.
-Changed (refactored) the way a lot of the block placement code works internally to simplify a few things, and relieve myself of a BURNing desire to tidy things up.
-Fixed a vanilla problem that caused the player to slide while walking on slabs (and other partial blocks) placed on top of ice.  Note that I intentionally did not apply this change to items, so as not to BURN players with any builds that might rely on that behavior.
-Fixed people getting BURNed when loose stairs and slabs wouldn't properly stick to blocks with mortar in some orientations.
-Fixed a sick BURN where switching to an inventory slot while knitting caused the game to crash.
-Removed the ability to place Clay on leaves as it made for excessively lame early game Brick drying racks.  BURN.

4.AB4 Bonnets

-Added Loose Cobble and Loose Brick Stairs.  Both are created with 6 of the corresponding items in a stair pattern.  Once placed, mortar may be applied to them, in the same manner as other such blocks.
-Added a new system for placing the various forms of Cobblestone and Brick blocks.  The way this works, if you place the loose version of the block, connected to another of the same material (eg. brick next to brick) that already has mortar applied (Clay or Slime), it will stay in place for a brief time before collapsing.  This gives you a chance to apply mortar to the new block before it falls, to fix it in place.  In addition to spanning gaps, this also allows you to place blocks like upside down slabs and stairs.
-Added the ability to retrieve tools placed as blocks by right clicking.
-Added the ability to use Nether Sludge as mortar.
-Added a more detailed change log for version 4.AAAAAAAAAAHHHH below, which I wrote back when I was working on it.
-Changed the look of Wicker Baskets containing items, to make their state a bit more evident.
-Changed (refactored) the way falling blocks (sand, gravel, etc.) work internally to make it easier to add new blocks of this type (like the stairs in this release).
-Changed (refactored) how many slab blocks work internally for similar reasons.
-Changed how mining speed modifiers due to stuff like hunger and health work internally once again to try to reduce desync problems between client and server.  I made some modifications to the networking code for this, which will result in you getting promptly booted if you join a server running an older version.
-Fixed a problem that could cause a crash when placing a tool at the same time as using it to harvest a block.  In the process, I also just prevented placing tools while harvesting entirely as it felt rather strange.
-Fixed a vanilla issue where mobs wouldn't catch fire in sunlight if standing on slabs or other partial blocks.
-Fixed how annoying Ghast sounds can be in the overworld, similar how I fixed grinding Netherrack in the past.
-Removed Hardcore Sinkholes from the mod, as the random deaths that were sometimes caused by this feature were too punishing given how much more demanding the early game has become.
-Removed Redstone from loot chests close to the surface due to its progression breaking properties.
-Removed Pumpkin Seeds from the same.

4.AAHHHHHHhhhhhh

-Added a slightly decreased sense of soul crushing despair to the early game as part of my ongoing balancing efforts.  Yes, this means I just made things slightly easier for once, but please be assured that I'm having a full set of medical tests conducted.
-Added some Reeds to newly generated Jungle biomes to provide additional sources of them in the early game.
-Added the Bone Club as a new early game weapon.  It's an upgrade over the wood one, and is crafted with two bones in a vertical line.
-Added "smouldering" state to the Campfire, that will allow you to relight one that's burned out for some time afterwards, just by adding fuel.  Note that any cooking progress is lost when this happens, and it takes time for the fire to fully relight, so it's still important to tend your fires.
-Added the ability to place most tools as blocks, to act as an early game storage alternative and decorative option.  They may only be placed on blocks that each particular tool is effective on (axes on logs for example).
-Added a new Clay Block which is crafted with 9 Clay Balls either in the crafting grid or through Hardcore Packing.  For the most part it's functionally equivalent to the old naturally generated Clay blocks, which have been changed to have a new look, and to only drop a single Clay Ball and some dirt when harvested.  Note that the new ones need to be supported by a block below them (like other Unfired Pottery), which may affect existing Pottery builds.  The old ones may be converted to 9 Clay Balls in the crafting grid if you have any in storage.
-Added conversion recipes from Iron and Gold Ore blocks, to Chunks of Iron and Gold Ore.
-Added Mycelium slabs, and the ability for Mycelium to spread to loose dirt.
-Changed (tweaked) the efficiency of the Pointy Stick and Sharp Stone to be slightly faster, to provide a little more wiggle room in the first day, and to help differentiate them from using your hands, and from each other.
-Changed (tweaked) Unfired Bricks to cook more quickly in the sun.
-Changed (tweaked) Chunks of Iron and Gold Ore to be crafted with two piles of the associated type rather than four.
-Changed the name of the Club to "Wood Club" and gave it knockback to make it slightly more worthwhile.
-Changed how Groth, the Brick Oven, snow, stairs, and slabs work internally to help improve rendering performance.

4.AACK

-Added Hatsies for Zombies and Wolfsies Hatsies with enhanced Hoofsies and Boomsies.
-Added crafting sounds for various forms of clothing and armor.
-Added recipes for Wood Fences, involving 6 Wood Planks in the pattern other fence recipes use.
-Added the vanilla recipe for Fence Gates (4 Shafts and 2 Planks, "SPS", "SPS") back in.
-Added lower tech Trap Door recipe (2 Shafts and 4 Planks, "PPS", "PPS"), and changed the high efficiency recipe to match (siding instead of planks).
-Added the Spider Jockey origin story.
-Changed Squid to have Nothing To Worry About.  Poor things were far too tense.
-Changed how wool colors blend during knitting to hopefully generate more intuitive results, and less grey.
-Changed the way health and hunger status penalties are handled internally, to hopefully reduce some client / server synchronization issues when mining blocks with such penalties in effect.
-Changed the way the early game fire starters work to make them more resistant to multiplayer lag.
-Changed the way spits work to disincentivize gamey behavior involving selectively punching blocks at various times in the early game.
-Changed the Knitting Needle recipe to require undamaged Pointy Sticks for similar reasons.
-Changed Baskets to be crushed by falling blocks.
-Changed the Hibachi to not instantly incinerate tree stumps.
-Changed several types of wood blocks to not drop intact when harvested with a Stone Axe, but to harvest whole with iron or better, for greater consistency between the various early game blocks.  I tried to cover as many as possible, but given the large number involved please let me know if I missed any.
-Changed workbenches to not harvest as quickly to better communicate that they always break on removal.
-Changed Wicker Baskets to have a bit of hardness to help prevent them being accidentally broken.
-Changed Brick Ovens to not allow snow to accumulate on top of them when they are burning.
-Changed (refactored) how Zombies, Squid, Spiders, and Creepers work internally to help simplify some of the mod code.
-Changed Ghast navigation so that they're reluctant to enter water or lava.
-Fixed an issue with villagers still having a trade involving a stone furnace, even though they are no longer craftable.
-Fixed a problem where several mod fence recipes were outputting only 2 blocks instead of 6.
-Fixed problems with bricks being hardcore packed where it would take only 4 rather than the 8 bricks, and where the resulting block was created with mortar already applied.
-Fixed problem where the cracks weren't being displayed properly on Brick Ovens and Campfires when they were being harvested.
-Fixed an issue where creating Groth in a Cauldron would return a non-loose dirt block.
-Fixed problem with wolves sometimes being excessively chill about other wovles getting attacked nearby.
-Removed the Ghast spawn from Hoppers as it was never intended as a farming method, and with the removal of Ghasts from Soul Urns, had unfortunately become the default method of summoning them.
-Removed vanilla "Zombie Sieges".  They didn't appear to be working anyways, were not a particularly well understood or compelling mechanic if they did, and were complicating the mod code unnecessarily.

4.AABBBbbbbbb

-Fixed a problem where wool knit colors weren't mixing properly when creating wool armor.

4.AABBBbbbbb

-Fixed a problem with wool knit colors only displaying as black in multiplayer.  Unfortunately this causes some loss of fidelity when mixing colors when creating the knit (most will mix to grey unless identical colors are used), but I'll attempt to improve on that in the future.
-Fixed an issue with some smoke particle effects acting weird when the player got near to them.

4.AABBBbbbb

-Fixed problem where your very first tool no longer worked, which interfered with tech progression slightly.

4.AABBBbbb

-Added Hardcore Knitting.
-Added a new interface for interacting with one of the early game blocks.  Note that nothing you had in it will be lost.  Just right click on it with an empty hand to retrieve any previously stored items.
-Added conversion recipes for a few early game items to turn them into saw dust.  This acts as a backup method for burning them in a pinch.
-Changed stone picks to provide an enhanced sense of soul crushing suckitude.
-Changed cobble slabs to be craftable in the player's inventory.
-Changed stone and dirt to drop whole blocks when harvested with the appropriate tools.
-Changed stone pickaxe recipe to use three stone and the stone axe to use 2 to be more consistent with other tools of the same type.
-Changed spider silk drops to be slightly more random.  The overall mechanism remains unchanged from last release however.
-Changed spiders to not lose interest in the player quite so easily in sunlight if they are actively engaged in combat.  However they now have a greater tendency to chill out when you're not fighting them.
-Changed (increased) the duration of food poisoning to make eating uncooked food less effective.
-Changed how one of the early game blocks detect collisions slightly, so that it's easier to click on blocks neighboring it.
-Changed the old (non flammable) versions of workbenches chests, and webs, in item form to have different "Old Foo" names, and added conversion recipes for them to turn them into the new items.  This is to avoid confusion with them not stacking with the newer ones.
-Changed fire to deliver a mild burning sensation.
-Changed creepers to be slightly more dangerous to toy with.
-Changed nether portals to have slightly broader lighting requirements in terms of the types of fires within them.
-Changed rotten flesh and bone blocks so that they can *only* be created through hardcore packing with pistons, and not through the crafting grid.
-Changed carved pumpkins to not drop as an item when destroyed.
-Fixed a problem with collision volumes on some mod blocks (like the Soulforge) where they weren't being rotated correctly.
-Fixed a problem where the old non-flammable chest blocks would not display properly next to the new flammable ones.
-Fixed a problem with placed shafts not always rendering all their sides.
-Fixed problem with the Millstone applying ranged effects while ignoring height.
-Fixed a problem with items rendering within mod blocks sometimes being at the wrong angle when using the fast graphics setting.
-Fixed problem with Stump Remover not working on some stump types.
-Fixed problem where chests and some stairs couldn't be harvested with silk touch.

4.AABABABA

-Added flammability to workbenches, chests, wood doors, and webs.  Note that this does not affect blocks already placed in the world, and thus will not put your existing builds at risk.
-Added different harvesting properties to webs that are left for players to discover.
-Added the ability to stick shafts into the sides and bottom of "soft" (dirt, sand, etc.) blocks.
-Added an alternate recipe for one of the early game items involving Hemp Fibers.
-Added an alternate Planter recipe involving additional types of dirt.
-Added the ability to melt down an early game iron item in the Crucible.
-Added crafting sounds to shears, hoes, and all diamond tools.
-Changed book items so that they can no longer be crafted, and thus must be found as loot in the world to be used in enchanting.  This is intended to increase the significance of leveling up your enchanting capability, as well as the value of loot locations and strongholds.
-Changed the book and quill to be craftable with 3 paper, a feather, ink sack, and leather, essentially combining it with the old book recipe.
-Changed villager trades slightly to adjust for the above book recipe change.
-Changed regular zombies to no longer break down doors and other similar blocks.  This may seem odd for BTW, but I think it never worked very well or brought much to the game, really just causing players to not use wood doors anymore.  Now that wood doors are part of the progression, this change allows them to provide a nice quality of life improvement as you move ahead. Note that this change does not apply to zombie villagers or other creatures that may possess this ability, so wood doors may still not be suitable for all uses.
-Changed stone shovels to be accessible a bit earlier in the tech progression.  I won't state the recipe here to avoid spoilers, but it's very similar to the other early stone tools.
-Changed the stone axe recipe to not be shapeless to accommodate the above shovel change.
-Changed stone shovels to be slightly less effective to fit the above change, and to further emphasize iron shovels as an upgrade.
-Changed Blazes to drop the same number of rods regardless of whether they're killed by a player or not.
-Changed how spiders produce and drop silk to reduce the effectiveness of some forms of spider farming.
-Changed the way cobblestone, sandstone, and brick blocks (including slabs and stairs) drop as items with explosions, or with the inappropriate tool.
-Changed gravel blocks to potentially drop flint regardless of the tool type used on it.
-Fixed an issue with map items not updating properly when held by the player.
-Fixed a problem with mod slabs where you could place them clipping through the player when combining them with other slabs.
-Fixed a problem where chiseled sandstone would drop sand that does not stack with other items of the same type, and another similar problem with stone dropped from cobble walls.
-Removed redstone dust from looted jungle temples given it's now rather uber.

4.AAABBBA

-Added the ability for some specific blocks to spread fire between each other.  This does not affect pre-4.AAAAAAAAAAHHHH blocks or builds.
-Changed the player inventory to not get wet when only partially submerged.
-Changed how the compass renders internally to hopefully prevent some exploits.
-Changed netherrack to require iron or better tools to harvest, and increased its toughness to tools in general slightly.
-Changed grinding of netherrack to resolve the issue of it being too unpleasant to stand nearby due to the noise.
-Changed how torches work just a wee little bit that will most definitely not result in anyone dying in unexpected ways, and which in no way motivated me to release this as quickly as possible while subtly hiding this change towards the end of the log where no one will notice.
-Fixed a problem where the starter not-chest might have not-stuff in it.

4.AAAAAAABBB

-Added a visual indicator of whether some storage blocks contain items.
-Changed the way Raw Mutton looks in order to make it more visually distinct from Cooked Mutton.
-Changed the name of Coal Dust to better communicate its use.
-Changed how fire renders internally to hopefully help with issues with some texture packs.
-Changed the starter chest to be less so.
-Changed the Grate and Wicker Pane recipes to require Wood Moulding rather than just Shafts.
-Changed the way torches work internally so that they're added to your inventory in a more intuitive manner and to hopefully reduce or eliminate the flicker that would occur sometimes in SMP.
-Changed some log types to not be fully transparent to light.
-Changed some dirt slabs to be able to combine with grass slabs.
-Changed Shafts and some torch types to be crushed by falling blocks.
-Changed chest minecarts to not be quite so chesty.
-Removed the Workbench from villages.
-Removed generated torches in villages and abandoned mines.
-Removed the early game glass recipe.
-Fixed problem where using the number keys to swap items to the hotbar would sometimes cause the relevant slots to display the wrong item.
-Fixed a problem with blocks under destroyed snow not always rendering correctly.

4.AAAAAAAAAAHHHHeeeeeeeeee

-Changed animals to only be attracted to sunlight to make them a tad less self-immolatey.
-Changed the way chests work to make them less cheaty.
-Changed planks destroyed by explosions to be less planky.
-Fixed the Saw when attempting to cut plank blocks being excessively breaky.

4.AAAAAAAAAAHHHH d

-Changed an early game block to be a little toughter to harvest to help prevent accidents occurring.
-Changed another block to be more easily harvested with early game tools.
-Changed some code internally to hopefully help with problems for people running the Deco addon.
-Fixed problem with explosions inappropriately harvesting some logs.
-Fixed a problem where upside down slabs could no longer have redstone, torches, and other such blocks, placed on them.  This is the main reason for this patch release, as it could have major consequences for worlds with large redstone builds in them.
-Fixed a problem where sand would sometimes crush dungeon chests during world gen.

4.AAAAAAAAAAHHHH c

-Fixed a crash bug in SMP when using torches.

4.AAAAAAAAAAHHHH b

-Changed an early tool recipe to shapeless to make it a little more intuitive.
-Fixed problem where some wood blocks could be harvested with inappropriate tools leading to a tech progression workaround.
-Fixed problem where splitting logs with a stone axe would always produce oak bark regardless of the type of log involved.

4.AAAAAAAAAAHHHH

-Changed the entire mod.

Details:

-Added Chewed Logs as a new block.
-Added Loose Dirt and Loose Dirt Slabs as new blocks.
-Added Loose Cobblestone and Loose Cobblestone Slabs as new blocks.
-Added Loose Brick and Loose Brick Slabs as new blocks.
-Added Pointy Sticks, Sharp Rocks and Iron Chisels as new tools.
-Added Clubs as a new early game weapon.
-Added Fire Ploughs and Bow Drills as new early game fire starters.
-Added Campfires as a new block.
-Added the ability to use Clay and Slimeballs as mortar for Loose Brick and Cobblestone blocks.
-Added the ability to sun dry Bricks.
-Added the Brick Oven as a new block.
-Added Stones as a new item.
-Added chunks and piles of iron and gold ore as new items.
-Added Crude Torches as an early game light source, and changed regular torches so that they may only be crafted with Nethercoal.
-Added Wicker as an individual item, separate from wicker panes, and changed the name of wicker panes.
-Added Wicker Baskets as a new block.  They're crafted with 4 pieces of Wicker.
-Changed the Wicker Pane recipe to be Wicker, surrounded by 4 Shafts in the crafting grid.
-Changed Coal to grind to two Piles of Coal dust, instead of 1.
-Changed the Nethercoal recipe in the Cauldron so that it only produces one lump, instead of 4.
-Changed the way Smoothstone and Log blocks work so that they have multiple stages and drops when chiseled down.
-Changed Stone Axes to be crafted with a stone, shaft, and spider silk.
-Changed (refactored) the way the Soulforge renders and detects collisions.
-Changed Endermen so that they don't teleport away on the final hit that kills them.
-Changed (refactored) a bunch of code related to how tools function to help simplify things internally.
-Changed (refactored) how items determine which kind of enchantments apply to them.
-Changed the way clocks and compasses render so that they should only function in the player's inventory (and item frames for clocks).  This was also the case before, but I've made the related code a bit more robust to help discourage cheating.
-Changed (refactored) the way the spread of grass from block to block is handled internally to facilitate adding such functionality to new blocks (like Loose Dirt).
-Changed (refactored) how blocks specify if they have a solid top surface (for placement of other blocks like torches and snow) internally to unify mod and vanilla blocks into one system.  This may have some noticeable effect in being able to attach some additional blocks to others that weren't possible before.
-Changed (refactored) how the Battle Axe works internally to make it more consistent with how other axes function.
-Changed the Jack O'Lantern recipe to be shapeless.
-Changed nether portals so that they can be opened using a Campfire
-Changed the ladder recipe to require either spider silk or hemp fibers in the previously empty slots between the shafts.
-Changed the Hand Crank, Lever, Dispenser, Detector Block, and Piston recipes to use smooth stone instead of cobble.
-Changed the arrow recipes to a shapeless one that requires flint, a shaft, feathers, and spider silk (or hemp fibers).
-Changed blacksmith houses so that they contain brick furnaces, and only do so in non-abandoned villages.
-Changed abandoned librarian houses to not contain workbenches.
-Changed witch huts to replace the Workbench with a Basket, and removed the Cistern.
-Changed desert wells to have loot Baskets around them.
-Fixed vanilla problem where sand and gravel wouldn't fall if placed above blocks that wouldn't normally support them while falling, like snow, or torches.
-Fixed a problem introduced in a recent release where some creatures would continue to eat food items after they had died.
-Removed ability to start open fires with flint & steel.  Now only specific blocks can be lit.
-Removed the ability to cook glass and to smelt ores in block form in the furnace, which means they can only be cooked in the Crucible and Kiln.


4.A9 Pustules Lancing C

-Fixed problem with MCPatcher compatibility that was causing grass slab to render incorrectly.

4.A9 Pustules Lancing b

-Fixed a problem where cooking logs in a Kiln would produce bedrock instead of charcoal.

4.A9 Pustules Lancing

-Added Hardercore Spawning.  This changes Hardcore Spawning in a number of different ways that are left for players to discover.  The overall intent is to help HC Spawning remain relevant throughout the game, by changing how it behaves as you move further into the progression.  Note that as a result, players that already have developed worlds may find that HC Spawn behavior changes quite drastically, because they will not have incrementally progressed through the earlier stages.
-Added Hardcore Soul Mating as part of the above changes to hardcore spawn.  In the early stages of the game, this means that when one player dies on a multiplayer server, any other players that die in the following Minecraft day will also respawn in the same general vicinity as the first.  This is to help reduce the amount of time that people playing cooperatively will have to spend apart from each other, but since this only functions for a limited part of the progression, keep in mind that you'll want to switch to using soul sand to track each other down at some point.
-Added Largercore Spawning.  In worlds generated with large biomes, all distances related to Hardercore Spawning (including abandoned villages, looted temples, etc.) will be scaled upwards.  Large Biomes are still not officially supported in Better Than Wolves, but I figured that while I was refactoring various bits of code for the above features, I'd add this in as well for players looking for something a little different.
-Added a whole set of Blood Wood planks and associated blocks (slabs, stairs, fences, Moulding, Siding, Corners, Columns, Pedestals, Tables, Benches) to the game, in place of simply using jungle wood as a Blood Wood substitute, as was done previously.
-Changed cocoa beans so that their growth stages can be detected by a Buddy Block.
-Changed the way blocks render while being cooked in a Kiln, to make the process a little more evident, and to fix a problem where only one block could be displayed as cooking at a time.
-Changed the splash potion ingredient back to gunpowder (from Creeper Oysters), since gunpowder is now available earlier in the tech tree again, and since Creeper Oysters are rather common for such a powerful role.
-Changed the way maps are zoomed out, so that it is done by surrounding *empty* maps in the crafting grid with paper, rather than doing it with an already used map.  This bypasses a number of vanilla issues with zooming maps out, without losing any functionality since maps are reset when zoomed anyways.  You can see the current zoom level in the tooltip for the map.
-Fixed a very old and very rare crash bug involving mob spawners attempting to generate mossy cobble in chunks that had yet to generate.
-Fixed problem where ladders would sometimes default to odd directions when placed in tight spaces.
-Fixed (probably) a vanilla problem where groups of mating animals would sometimes produce more offspring than the number of parents should allow.  I say "probably" because it was a rather rare and random bug, which makes proving its nonexistence difficult.
-Fixed a problem where axes weren't properly harvesting Blood Wood logs.

4.A8 Milks A Tossing

-Added a config file setting that allows you to specify a URL which the game will use to fetch player skins.  This was necessary because Mojang deactivated the skin server for earlier versions of Minecraft.  Alternative URLs can be found on the BTW forums.
-Added decay to zombie villagers.  Note that this takes place regardless of whether the chunks they are in are loaded or not, making trapping them to cure at a later date an ineffective strategy.
-Changed Soul Flux to be used to increase the potency of potions rather than Brimstone as the recent changes to filtering glowstone into Brimstone caused these potions to revert to earlier in the tech progression than intended.
-Changed ladders so that they can be attached to the back of siding blocks.
-Changed Unfired Pottery, and other related blocks (like dough), so that they can be placed on glass blocks.
-Changed (refactored) the way stair blocks work internally to make them more consistent with other blocks.  You can now stick stuff (torches, ladders, etc) to their full sides, they have a slightly more accurate collision voume when their shape changes due to neighboring blocks, and snow can now accumulate on them when they're upside down.
-Changed (refactored) some code internally that handles how blocks attach to others, and which blocks can contain Hardcore Packing.  There should be no noticeable changes from this, except perhaps a few more blocks that function in those contexts.
-Changed the Dead Weight (vanilla anvil) to return more iron when melted down in the Crucible.
-Fixed an issue where the lighting on smoothstone stairs, wasn't consistent with other stair blocks.

4.A7 Squid A Swimming

-Added smoothstone stairs, made with 6 smoothstone blocks or 3 Moulding in the usual patterns.
-Added Rotten Flesh and Bone slabs.  They're created with the usual 3 blocks in a horizontal line in the crafting grid.
-Added some localization (language translation) capacity to Better Than Wolves.  At present it's limited to block and item names, with some message strings still hardcoded, but the underlying implementation allows translation into any language that Minecraft 1.5.2 supports, and also provides functionality for add-ons to easily add their own custom language files as well.  I won't be maintaining or distributing translations myself, but anyone who wishes to do so is welcome to.
-Added Carved Pumpkins as separate blocks from Pumpkins.  Carved Pumpkins are produced by crafting Pumpkins, while Jack'o'Lanterns are now created by combining Carved Pumpkins and a torch.  Pumpkins found in the wild will now either be Carved, or regular Pumpkins depending on whether you're within the Hardcore Spawn radius.
-Changed Melon and Pumpkin growth so that they'll happily crush neighboring plants with their fruit to make growing them a little more interesting and space consuming.  They will crush their own stem if all surrounding blocks are blocked for growth.  They have been changed to grow on pretty much any block with a solid top surface.  Their stems are also directional, attaching to a specific plant which will return to an earlier growth stage on harvest, and they have a greater number of growth stages now, slowing down overall production some.
-Changed (increased) hunger cost for jumping while sprinting to prevent several exploits.
-Changed cactus blocks so that they can only be placed /replanted in Planters. Similar to the recent lily pad change: too sploity.
-Changed boats so that they'll break apart if they fall from a height onto hard ground.
-Changed Blocks of Bone and Flesh to drop full blocks on harvest, rather than individual items, to better suit the inclusion of slabs of the corresponding types.
-Changed (increased) the player's movement rate on Bone Blocks to better facilitate paving the planet with the broken remains of your fallen foes.
-Changed the Hardcore Player Names config file setting to have an additional option so that names won't be visible behind blocks and other obstructions.   This setting is server side and will be automatically relayed to players.
-Changed (refactored) how config file loading works internally to simplify things a bit.  This should have no noticeable impact during play.
-Changed (refactored) how blocks determine which tools are effective on them internally.  
-Changed (refactored) a bunch of other more minor aspects of how blocks and items initialize internally to help facilitate the process of creating new blocks and items.
-Fixed vanilla problem where boats would be considered to be falling indefinitely while on the surface of water, potentially killing the player after long journeys.
-Fixed problem where lily pads could still be placed on the sides of blocks.
-Fixed problem where villages and other structures far from spawn (beyond around 50 kilometers) would sometimes be abandoned or looted.
-Fixed vanilla problem where sitting wolf cubs would sometimes teleport to their owning player when they grew up.

4.A6 Sided Sideshow

-Changed the way boat handling works, so that when holding a sail, a constant forward motion will be applied to the boat without the player having to hold down a control.  How it works should be obvious in practice, but the intent is to make long voyages and looking around while boating more convenient.
-Changed the way the player dismounting boats or other vehicles (minecart, pigs) works so that it favors the direction they are looking in, and placing them on dry land.
-Fixed problem with the bounding box on the Dormant Soulforge being too large.
-Fixed glaring oversight where Skulls could not be placed atop Shafts.
-Fixed a bug with an older priest villager trade that was causing chunk corruption in some saves.  My sincerest apologies to anyone that may have lost part of their world as a result.  This fix is the primary reason for this release.

4.A5 Pronged Poking

-Added Hardcore Poking.  This allows you to stick shafts into soft ground, primarily to test to see if it's stable before walking on it (falling blocks like sand will behave exactly as if a player had walked on them).  You can also place torches on top of them if you're planning a luau.
-Added the Dormant Soulforge as a new block which can be found in newly generated nether fortresses.  It may also be crafted with 10 gold in an "I" pattern in the crafting grid (requires an Anvil/Soulforge), and may be melted down in the Crucible.  This will hopefully make finding and exploring nether fortresses a more interesting and rewarding experience, and also inserts an additional fortress dependency into the progression.
-Added the ability to cure zombie villagers back into the game, but it's now done with Soul Urns so that it's not accessible too early on.  Note that unlike in vanilla, surrounding blocks like beds and iron bars do not affect the cure rate.
-Changed Soul Urns to have a maximum stack size of 16 to better match other throwable items, and got rid of their summoning of ghasts since  that conflicts with their new role in curing zombies.
-Changed the Anvil's name to "Soulforge", and changed its recipe to require a Dormant Soulforge, Nether Star, and Soul Flux.  As before, it may also be acquired through trading.
-Changed (tweaked) the types of villagers that spawn in the different village variants (abandoned, semi, etc.) to make the progression a bit more interesting.
-Changed the blacksmith building in villages to have a Dead Weight, even when abandoned.  This makes it a little more rewarding to find villages as you travel about.
-Fixed problem that was causing potion particle effects to not display properly on mobs.
-Fixed vanilla crash when loading the options file from versions newer than 1.5.2.  Unfortunately, this won't help on the first run of 1.5.2 when first installing the mod, but should at least prevent crashes if you switch back and forth between an existing BTW install and newer versions of Minecraft.
-Fixed some issues with leaves decaying when they shouldn't have.  I think this may have also improved performance on chunk generation slightly.
-Fixed a progression bypass I had accidentally built into Blacksmith trades in the last release.
-Removed ability to melt down the Flint and Steel item in the Crucible, as it just resulted in annoying gamey behavior for the sake of negligible returns.
-Removed a bit of nothing to worry about from the last release that didn't really work well with some of the other changes in this one, so I guess now would be a good time to totally freak out.  On the bright side, there's still at least one thing left not to be the least bit concerned with.

4.A4 Kiloblock Boon

-Added internal support for extended block IDs beyond the base 256 to facilitate future expansion of the mod.  This is based on Yhetti's code in the Deco add-on, with permission, so major thanks to him for his efforts over the years in helping this happen.
-Added a Rotten Flesh storage block (9 in the crafting grid), largely as a test of the above functionality as it makes use of the extended block IDs.  These blocks may also be assembled with pistons via Hardcore Packing.  Please let me know if you experience any odd behavior with these blocks as it will help me ensure that extended block IDs are working well before I make further use of them.
-Added a new interface for villager trading to help cut down on the amount of clicking in the mid to late game.  This will hopefully make the large number of trades that must be performed to get to the end much more convenient overall.
-Added the ability to filter Glowstone into Brimstone with a Hopper and Soul Sand filter. Like with filtering Ground Netherrack and Soul Dust, this will also produce souls which may be captured with an Urn.  This provides a method of producing limited amounts of gunpowder earlier in the tech tree.
-Added ability to assemble Blocks Of Bone with Pistons via Hardcore Packing.
-Added a couple of additional factors to not worry about.  In particular, you should be entirely unconcerned when performing activities that might result in loose tormented and likely deranged souls meandering about, especially if you have high level villagers nearby whose well-being you are totally chill about. You will totally not at all painfully face palm at the realization of how obvious a danger this doesn't represent if you just breath deeply, relax about the whole thing, and go about your business as if I hadn't said anything.  This should not be misinterpreted as some kind of warning, as really, there's always been nothing to worry about.  I have no idea why you're making such a big deal about this and I refuse to humor your dysfunction any longer.
-Changed priest villagers to have an extra trade slot available at high level to help offset some of the lack of variety in their trades.  This became a problem due to the mandatory trade offers I implemented in the previous release.
-Changed the order in which the Librarian trades are unlocked, and some of the level-up trades slightly to create a more interesting progression.
-Changed a few other minor villager trades here and there, particularly peasant trades.
-Changed (tweaked) the Block of Bone texture slightly to appear a little more aged.
-Changed Lilly Pads so that they can't be placed as blocks.  Sorry, too sploity, as they could easily be used to take a lot of the tension and danger out of longer boating trips.
-Fixed a bug where the furnace gauge wouldn't always display correctly after a save / load.
-Fixed problem with Hardcore Packing where sometimes blocks would get packed as the piston was retracting instead of extending.
-Fixed problem that was causing Jungle Spiders to spawn in fewer numbers than they should have.  You're welcome.

4.A3 Headed Beastie

-Added the ability to speed up boat travel if you are holding a sail (the item used to craft wind mills).  Without a sail, boats now have their speed greatly reduced.  This makes early game water travel a tad more problematic, and adds a bit of progression to boat use.
-Added additional hunger consumption when you swim vertically upwards.  This increases the inefficiency of swimming relative to boating, as well as making it tiring to simply tread water.
-Added the ability to see if a furnace has any contents (not fuel) without having to open it.  There's now a slight texture variation on the front of the furnace when it contains something, which makes working with large banks of furnaces much more convenient.
-Added Bone Blocks as a new storage block, created with 9 bones in the crafting grid.  When summoning the Wither, Bone Blocks now replace the soul sand that was previously used in a "T" shape beneath the skulls.
-Added Infused Skulls as a new item and block.  In terms of functionality, these replace Wither Skulls (now called Runed Skulls) for summoning the wither.  They may either be acquired through trading, or by combining a Runed Skull, a Soul Urn, and soul flux in the crafting grid.
-Added a new method of acquiring Wither Skulls (now called Runed Skull) through trading, to provide an alternative approach to decapitating a large number of wither skeletons.
-Changed the Wither so that it can no longer be summoned in dimensions other than the overworld (no summoning in the nether or end) to make fighting it more interesting.
-Changed the name of Wither Skulls, to Runed Skulls, to better suit their new role, acquisition method, and lore.
-Changed some of the crucial trades with villagers that facilitate progress towards the end.  Without spoiling too much, the priest is no longer the only villager required.
-Changed the Anvil recipe to use a nether Star and Soul Flux in combination with a Dead Weight (vanilla Anvil) in the crafting grid.  It may also now be obtained through trading, but may no longer be melted down in the Crucible.  This change makes the Anvil available earlier in the overall progression (through trading), opening up some of the more complex redstone blocks in the mod (like the Block Dispenser and Detector) before Soulforged Steel is acquired.
-Changed the way the sail item looks when held by the player slightly, to better suit its new role in yachting.
-Changed (tweaked) the AI of fleeing animals slightly, to make them a little harder to catch.
-Changed (reduced) the hunger value of Tasty Sandwiches slightly to make them a bit less universally awesome relative to other food sources, and to increase the value of finding potatoes and carrots.
-Changed (reduced) the hunger value of bread and Scrambled Eggs for similar reasons.
-Changed (tweaked) the level and value of a few minor villagers trades to create a smoother play experience.
-Changed boats to be burnable in the furnace.
-Fixed a problem where shears would sometimes glitch out if their last bit of durability was used to shear creepers, sheep, or mooshrooms.
-Removed a bunch of splash screen texts that were no longer relevant or which hadn't aged well.

4.A2 Timing Rodent b

-Fixed a problem where the Battle Axe wouldn't properly chop logs.

4.A2 Timing Rodent

-Added Hardcore Stumping in honor of the electoral process.
-Added Stump Remover for when you're sick of the electoral process.  It is made with creeper oysters, red mushrooms, and rotten flesh in the crafting grid.
-Added Hardcore Grass.  This changes grass so that it can only grow in natural light.  Torches will no longer work, nor will Light Blocks.
-Added a conversion recipe for nether brick slabs into full blocks to match those added for other slabs a couple of releases ago.
-Changed (decreased) the attack rate on slimes and magma cubes to better match other mobs.
-Changed sugar cane so that it can be burned directly in a furnace instead of having to be converted to paper first.
-Changed axes so that iron and better aren't damaged when splitting logs in the crafting grid.  Previously, there was no benefit to use better axes than stone to do so, which would create busy-work for the player in crafting and using stone axes just for that purpose.
-Changed chickens so that they'll reliably lay eggs the next morning after they are fed, instead of at a fairly random time.  This both slows down the rate of egg production, and makes collecting eggs manually less of an annoyance as you can now make it part of your daily routine.  Note that chickens must be fed at least 10 minutes before morning (the full night), or egg laying will be delayed a full day until the following morning.
-Changed piles of soul sand so that the cloud will only make whining noises if moving towards a target, but will stay silent if it doesn't detect anything.  This should make it a tad easier to use.
-Changed piles of soul sand to have a more evident visual effect when used.
-Changed gold and iron items so that they return only roughly two thirds of the original metal when melted in the Crucible.  This is intended to further incentivize mob traps and the use of higher tier tools, as both diamond and soulforged steel still have a 100% return.
-Changed villager trading so that trades aren't replaced by ones for the same or similar items as other unrelated trades are completed.  This created some rather sploity behavior with items like skulls, where the player could avoid particularly difficult trades by completing others, and was more confusing than anything else.
-Changed the install directions in this readme to work with the new Minecraft launcher.  If experienced mod users can review these and let me know if there are any issues with them, I'd be much obliged.
-Fixed problem where slimes and magma cubes would still deal damage to the player after they were dead.
-Removed wither skeleton skull trade from priests as it was disproportionately difficult to fill relative to other trades.

4.A1 Humped Camel

-Changed the night vision effect to improve visibility in gloomy areas.  Be cautious with this however, as it's now much more easier for night vision to run out and leave you unexpectedly surrounded by gloom.
-Changed the bounding box on small slimes to make them less likely to slip between diagonal gaps in blocks and Saw-based grinders.
-Changed (increased) the rate at which brown mushrooms generate deep underground as they were exceptionally difficult to find with the previous release.
-Fixed problem where not all block types would unsettle animals.
-Fixed problem where baby cows could be born with full udders.
-Removed the small amount of light that brown mushrooms produce, as it made it rather difficult to farm them given their growth conditions now require complete darkness :)

4.A Dingo

-Added Hardcore Slime.
-Added conversion recipes between some of the vanilla slabs and their full blocks.  This applies to cobblestone, brick, stone brick, and the various wood planks, basically covering any of the stock slabs that are made out of "parts" (like individual rocks in cobble) that you could see being easily recombined back into the original.
-Changed (increased) the despawn time of fired arrows stuck in blocks to be equal to the regular item despawn time (5 minutes instead of the previous 1) for consistency and due to the increased value of arrows in the early game.
-Changed animals to be a little more nervous.
-Changed brown mushrooms so that they'll only spawn deep down in the earth (or on mycelium), to make their initial acquisition more interesting, and to prevent swamps being a horn of plenty.  I figured out a way to do this without messing with overall worldgen so this and the following changes shouldn't cause seams in existing worlds.  Note that this also applies to the nether as I wasn't down with free food being everywhere in hell :)
-Changed brown mushrooms to also require complete darkness (or mycelium) in which to grow to make farming them a little more interesting.  The growth conditions remain otherwise unchanged.
-Changed reeds to only spawn in swamps, for similar reasons.
-Changed pumpkins to only spawn in plains biomes, and reduced the size of clusters in which they appear.
-Changed swamp biomes to only spawn pigs and chickens (no cows and sheep), and reduced the overall number of animals found there, to make them a little less zoo-like and more distinct.
-Changed chickens to avoid water when possible to reduce the number that would be found floating around off shore.
-Changed chickens to be visible from further away as they tended to pop-in quite close to the player.
-Changed cows to not get jiggy with the hoofsies  while wearing a breeding harness.
-Changed Bloodwood Saplings to render as items rather than blocks when in item form.  This changes the look of them slightly to be more consistent with other saplings as well as fixes a problem where they'd display oddly in item frames.
-Fixed problem where the player would appear to be falling in empty sky upon a hardcore spawn, and (hopefully) where they would sometimes spawn in solid blocks.  You'll likely notice increased time in the "loading terrain" screen upon respawn, as this fix revolves around waiting for more of the terrain to buffer before putting the player into the game world.  Let me know if you see any more instances of spawning in terrain, as while I ran numerous tests, this is the kind of thing that's rather difficult to be certain of since it was sporadic in the first place.
-Fixed problem where creatures would still attempt to path over some of the fences the mod adds (eg. stone brick fence) as if they were regular blocks.
-Fixed particle effects not appearing at all on smashing pumpkins. Also fixed both pumpkins and melons not displaying particle effects when dropped on invalid blocks like torches or slabs.
-Removed the vanilla wood fence, fence gate, trap door, and door recipes.  This means that you'll need a Saw to craft these items.
-Revised the install instructions in the readme to reflect the process with the "new" launcher.  If anyone spots any errors, please let me know.

Version 4.99999A0Fb Marsupial!?!?

-Changed Hardcore Hoofsies to use a "line of sight" check to prevent it functioning through walls and such.
-Fixed problem where wolves would attack cows when they weren't starving.
-Fixed vanilla problem where some AI entities would continue to try and attack others even when the target was dead.

Version 4.99999A0F Marsupial!?!?

-Added Hardcore Hunger for Wolves.
-Added Hardcore Hoofsies.
-Added the ability to burn some more "early game" items in the furnace, given keeping a fire going can now be a matter of life and death.  This applies to Wool, Wool Armor, arrows (both regular and rotted), bows, feathers, and paper.
-Changed the brightness of the changes I made to Hardcore of Darkness recently so that when Gloom isn't present, the overall brightness of the game should be much closer to what it is in vanilla (especially underground).  In other words, things should appear a bit brighter in general now than they did in the past couple of releases, and the transition from normal lighting into Gloom, a bit more dramatic.

Version 4.99999A0Eb Marsupial?!!!

-Fixed a problem where the game would sometimes consider you to be in Gloom when you shouldn't have been.

Version 4.99999A0E Marsupial?!!!

-Added a significant upgrade to Hardcore Of Darkness.  You'll know it when you see it, but it is really of course absolutely nothing to ever worry about in the teensy weensy little bit very least, particularly not because this release just happens to fall totally randomly in the most startling of coincidences on Halloween.  Thinking otherwise would just be symptomatic of rampant paranoia, and thus should be avoided at all costs.  Honest.
-Added the ability to dye wolf collars with Dung, because...you know...who am I to discourage people from rubbing Dung all over their pets?
-Changed the way player healing works so that it only stops due to hunger once you hit the "Peckish" state.
-Fixed problem where Concentrated Hellfire Beacons were no longer functioning in the previous release.
-Fixed problem with gravel and sand slabs acting weird when placed on cactus.
-Fixed problem where Mining Charges destroyed by Powder Keg explosions would leave "ghost entities".
-Fixed problem where cooking Cookie Dough in the furnace would produce 8 cookies for the first dough item, but only 1 cookie for additional items.
-Fixed some oddities with how redstone repeaters behaved on Turntables.

Version 4.99999A0D Marsupial??!!

-Added gravel and sand slabs.  This was done mainly for the sake of making gravel a more effective early-game road building material, with sand also being added for consistency and largely because it was a "free" addition in terms of development effort once the work for gravel was done.
-Added a new storage block for ender pearls made out of 9 of them in the crafting grid, which also replaces the functionality of obsidian within the corresponding beacon.  The reasons behind this will become more evident as the end game is added to BTW, but part of it is that it's intended to give more utility to mob traps in the end dimension. This unfortunately also means that any obsidian beacons you may have in your world will cease to function and will need to be replaced with the ender pearl version.
-Added a new system for despawning items dropped on player death.  Instead of using the regular item despawn timer, these items will disappear one Minecraft day after the player dies (20 minutes real time), regardless of whether the chunks they are in are loaded or not.  This makes the behavior of these items more consistent regardless of whether you are near original spawn or not, and reduces the effectiveness of gamey behavior like avoiding the area in which you died so that the items don't despawn.  It will also hopefully further encourage the building of infrastructure like road and rail networks to quickly return on death.  Note that in single player if time advances to the next day due to a death,  this is taken into account by the system and it does not cause you to lose the time in between in terms of item despawn.  Also note that this change will not affect items dropped on death previous to installation of this version, so if you have any lingering in the world, they will despawn as normal.
-Added ambient sounds to blocks containing silverfish to provide warning to players that may be tunneling into infested areas.  I became aware that it was possible (although rather rare) to get randomly ganked by silverfish in the early game if you happened to dig in the wrong place.
-Changed the restrictions on villager breeding slightly to be a little more forgiving: peasants will only breed to create peasants.  Butchers & Blacksmiths will breed to create both their own type, and the other.  Librarians and Priests function together in the same way.  The chances are higher when breeding of producing offspring of the class of the parents, but occasionally a child will be born at the same social level, but of the alternate class.  I changed this because finding a village with a librarian but no priest was potentially very frustrating in the late game given how difficult villages can be to find at times.
-Changed wolves to think that villagers are rather tasty and villagers to not think very highly of them as a result.
-Changed wolves to howl less frequently in general as the howling could get rather crazy if you were in an area with a large wolf population.
-Changed cows to sometimes spawn with distended udders (fair point Vioki ;) ).
-Changed (further balanced) a few of the villager trades, and fixed a couple that were buying for excessively high value.
-Changed the way the names of some items in the mod are capitalized for consistency both internally and with vanilla.  Things like "Pile of Dirt" instead of "Pile Of Dirt".
-Changed the way the decapitation bonus for mobs trapped between a chopping block and saw works so that it should apply much more consistently.
-Changed the player's initial spawn location so that it won't occur in jungles due to the night impossibility of surviving there initially.  This does NOT affect your respawn location after death with Hardcore Spawn, only original spawn, nor does it affect existing worlds, only newly generated ones.
-Changed the "/time" command to display both the current overworld time and the total overworld time.  This is mainly a debugging tool for myself, but I thought it worth mentioning in case it causes any confusion.  The total overworld time is an internal variable that isn't affected by such things as the time being set through server commands, or advancing due to HC spawn, and thus is useful for stuff like the item despawn after player death thing mentioned above.
-Fixed problem where child animals and villagers wouldn't be subject to possession while traveling through the nether.
-Fixed problem where the Buddy Block wasn't detecting the growth of wheat, carrots, and potatoes.  Note that in the case of carrots and potatoes I also fixed things so that Buddy only reacts if there's a visible change in the plant's state, and it will no longer react to internal invisible changes.  In other words, Buddy will react to 4 growth states with carrots and potatoes, not 8.
-Fixed a few out of place white pixels in the Chocolate Milk texture.
-Fixed a small problem with the collision volume on the fences the mod adds, when they are connected at a 90 degree angle.

Version 4.99999A0Cb Marsupial?!

-Fixed problem with movement modifiers due to terrain not consistently applying.

Version 4.99999A0C Marsupial?!

-Added Hardcore Sinkholes as yet another thing you shouldn't worry about, particularly in the nether, where you should really be completely relaxed about the whole thing.
-Added a few new trades to villagers to further flesh out the system in the previous releases.
-Added a chance to find a small number of peasant villagers in abandoned villages, as well as butchers and blacksmiths in semi-abandoned ones.  This should give villagers a bit more progression where the basic ones are more likely to be encountered in the early game, and with the more advanced professions only being encountered as your roam further afield.  This is to help play off of some of the tutorial aspects in the trades of villagers and to make them feel like a more integrated part of the overall progression.  It should also make finding abandoned villages in the early game a bit more interesting and make them more worthwhile to explore. Note that this will not affect already generated villages and will only occur with new ones.
-Changed (increased) the radius at which villages will be semi-abandoned to make them a bit more prominent and fit better with the above addition of different villager types to them.  Again, this only applies to newly generated villagers.
-Changed a little something something about priests.  This one you should probably worry about.
-Changed skeletons to not be damaged by cactus to make them a little less of a Swiss army knife defense system.
-Changed Bloodwood logs to use the same orientation method on placement as regular vanilla logs.
-Changed snow so that the movement penalty it applies is in addition to whatever modifier the block beneath it applies, instead of overriding it entirely.  This means for example that you will move faster on snow above cobble than you will on snow above leaves.
-Removed the cobble and gravel trades for villagers as upon further consideration I became concerned that those trades would actually discourage construction projects (roads in the case of gravel) as there might be a tendency to want to save those resources for trading.  I also wanted to limit the possibility of cobble gens being used to generate cash.  If your villagers already had such trades available, they'll still be there, but new ones won't be generated.
-Fixed problem that was causing the hunger bar not to wiggle on using a Hand Crank.
-Fixed a potential crash with the villager trading GUI that seemed to be a vanilla leftover.
-Fixed problem where Packed Earth, Dung, and Blight blocks wouldn't rotate on the Turntable in terms of them not transmitting rotation to blocks above them or attached blocks like torches.
-Fixed problem where the Block Dispenser was harvesting cocoa beans as cocoa powder, wouldn't plant cocoa beans when activated, and wouldn't spit out Cocoa Powder as an item.

Version 4.9 Marsupial?

Note: This is NOT the final release of BTW.  That's still on the way.  However, it does represent the finalization of both Hardcore Villagers, and the overall tech progression, so if you were waiting on proceeding beyond a certain point, feel free to proceed :)

-Added a new villager trading system which is left for the player to discover.
-Added visual feedback to the hunger meter whenever hunger is consumed by a player action.  This will hopefully make players more aware of some of the subtler aspects of the hunger system like how spam-clicking mobs burns excessive hunger, or how jumping or sprinting frequently does the same.
-Added a little more progression to axes: now, iron axes and better will not consume hunger when you are chopping through zero toughness vegetation like grass and flowers, making them ideal for clearing paths for yourself as you move about above ground.  In addition to this, diamond level axes and better will not consume durability when destroying leaf or vine blocks, which means you can use them to carve paths through jungles or other dense vegetation without them ever wearing out.  This gives a significant boost to the usefulness of axes in general as they were still rather underpowered relative to other tools, as well as further encouraging path and road building.  Note that gold axes are considered "worse" than iron for the purposes of this, and thus get no bonuses.
-Added a grunting sound to when players perform a zero-damage attack on a creature due to hunger or health depletion.  This should make it a little clearer what's happening under these circumstances.
-Added the ability to render Mystery Meat into Tallow.  My apologies for the glaring oversight there.  I guess I'm not a beautiful and unique snowflake after all.
-Added restrictions to villager breeding so that they will only produce children of the same class as one of their parents (Hardcore Caste System?).  Therefore, in order to gain access to a particular villager type you *must* find one in the world first.  Note that with the other changes in this release, this greatly reduces the value of partially abandoned villages, as well as increases the significance of keeping particular villagers safe once found.
-Added the color of candles to their names to simplify their identification.
-Changed a little something something about Pigmen behavior that is absolutely nothing to worry about.
-Changed the Ocular of Ender to use ender pearls in its recipe instead of eyes of ender.
-Changed the bed recipe to require Padding instead of wool.
-Removed the player's ability to craft eyes of ender, as this is now a villager trade.  I mention this aspect specifically since it changes the overall progression  In other words, you *must* find a villager willing to trade for them in order to progress beyond a certain point, meaning that finding and trading with villagers is now part of BTW's tech progression.
-Fixed problem with Wicker returning only 4 reeds when disassembled instead of 9.
-Fixed problem where Ropes could be attached to upwards facing Anchors.
-Fixed problem where Saws weren't cutting Hemp, sugar cane, or wheat.

Version 4.89PHILLIP

-Added Hardcore Brewing.  This is comprised of a number of small changes to the potion brewing system detailed below, to hopefully better balance it relative to the rest of the mod's content, and to up the value of various mob drops, while reducing the prominence of the whole "golden vegetable" bit.  As a general heads up though: don't make any assumptions about how to brew potions or their effects and make sure to read the below changes, as it's rather different from vanilla Minecraft now.
-Added recipe to convert planks straight into Shafts with a single block for convenience, particularly in the early game.
-Added the "Mysterious Gland" as a new semi-rare drop to squid which is used in the brewing of healing potions, instead of glistening melons.
-Changed fermented spider eyes to "Venom Sacks", and removed the ability to craft them.  They are now a semi-rare drop from jungle spiders, and are used in the same way as fermented eyes used to be within potion brewing.
-Changed the Grate and Wicker recipes to require 9 Shafts or sugar cane in a full crafting grid rather than the previous 4 for balance, particularly in the early game where they were being used by some players for excessively cheap barricades and windows.
-Changed night vision potions to be created with spider eyes rather than golden carrots.
-Changed (reduced) the drop rate of spider eyes to be a semi-rare drop to fit their new role in potion brewing.
-Changed poison potions to be created with red mushrooms rather than spider eyes.
-Changed the visual effect on night vision potions both to look cooler in terms of having interesting visual effects depending on circumstance, and so that you can now distinguish between areas in light and darkness with it active, as there were some rather severe disadvantages previously to using it as you couldn't really tell which areas were in darkness, and thus where monsters could spawn.
-Changed Creeper Oysters to brew splash potions rather than gunpowder to open up the possibility of using offensive potions earlier in the game.
-Changed Brimstone to be used to increase the potency of potions rather than glowstone dust to create more of a progression to when you gain access to more powerful potions.
-Changed the recipe for maps to have a Soul Urn in the top and bottom middle crafting slots instead of paper (it is unchanged otherwise with paper on the sides and a compass in the middle).  This was done both to better explain the "magic GPS" aspect of maps, so that they can't be relied on for navigation in the early game, and so that they fill the role more of an advanced navigation tool in the overall tech progression.  All told, hopefully they will feel a little less cheaty now, and more like a legitimate gameplay feature.
-Changed jungle saplings so that 4 of them next to each other will only grow into huge jungle trees if all 4 are fully grown.
-Removed the spider eye drop from jungle and cave spiders.  They are now exclusive to regular giant spiders.  In combination with the venom sack change above, this gives a distinct role to the different spider types, and a specific reason to farm Jungle Spiders.
-Removed the whole "healing potions hurt undead, harming potions heal them" thing from the game, as it was just hurting potion brewing overall as a system.  The problem was that it turned healing potions into a "swiss army knife" where they would both help you and hurt a good portion of the mobs in the game, including the wither, which is probably the fight where you most want potions.  Meanwhile, it relegated harming potions to pretty much never being used as a result (except in PvP) due to their tendency to both hurt you and help mobs.  Short version: all potions now effect undead the same way they effect other mobs.
-Removed spider immunity to poison potions for similar reasons (this applies to all spider types).  Minecraft just doesn't have enough mob types to justify these kinds of rules for potion use against them.  This isn't a classic RPG with over a hundred mobs or something that can support these kind of special case rules for potion use, without drastically decreasing their effectiveness to the point of being useless.  If potions are only effective some of the time, players likely just won't bother with them, and certainly won't keep them in their hot bar.
-Removed the ability to craft Blight into Nether Groth as it never really suited its intent as a nasty side-effect of the player's actions rather than something you'd want to intentionally create.  Mycellium is thus the only way to create it once again, but an alternate method will be coming soon in an upcoming release.
-Fixed a problem with sapling growth where they would revert to the smallest size on occasion if growing in tight spaces.

Version 4.89999999

-Added sound for when Gear Boxes are being overpowered by a Wind Mill in a storm to serve as a warning that damage will occur.
-Added ability to inject something directly into something from something else.  If you found the various features in the temples already, you'll know what I'm talking about :)
-Added a small grace period when the player switches dimensions in which ghasts and the enderdragon will not attack unless attacked first.  This is to prevent problems with popping into a dimension and immediately getting wiped out due purely to bad luck.
-Changed Wind Mills to only spin out of control in storms, rather than just in rain or snow.  This decreases the downtime you'll experience with them overall, but also means you'll have to keep a closer eye on the weather to make sure there isn't any resulting breakage.
-Changed (increased) the frequency of lightning bolts in storms to make the storm condition more evident and menacing overall.
-Changed snow and rain to look and sound less intense when there isn't a storm going to make the storm state more distinct, and to reduce the annoyance associated with the sound of rain.
-Changed HC Spawning so that if time is advanced to the next day on respawn, any storms will also stop to prevent the player having mobs spawn around them. 
 Similar to time advancing to the next day, this only affects single player.
-Changed (increased) the chance of storms occurring to make them a more significant threat.
-Changed the way storms work, so that a storm will only start after it's been raining/snowing for awhile to give the player a chance to react to changing weather conditions.  Basically, a storm won't just kick in out of nowhere from a clear sky anymore, but if it starts to rain/snow, you may want to prepare for a potential storm.
-Changed the order in which the Mill Stone processes items so that there's somewhat of a softest to hardest material order to it.  In other words, cocoa beans will grind before netherrack, and that kind of thing.
-Changed (reduced) the amount of hunger that melon slices restore slightly for balance.
-Fixed vanilla problem with it not getting visibly darker during storms, despite the fact that the game logic for monster spawns and such still treated it as such (it was basically an issue of the storm state not being communicated from the server to the client).  This should make storms much more evident when they occur.
-Fixed vanilla problem that was causing a delay in the transmission of changes in rain between server and client.
-Fixed item duplication bug with the Block Dispenser when failing to place clay balls.
-Fixed problem with Gear Boxes not breaking when overpowered in some circumstances.
-Fixed problem with the magic letters that flow between bookshelves and the Infernal Enchanter appearing in the opposite directions from where they were supposed to.
-Fixed a problem with how the Hopper was outputting XP orbs that was sometimes causing them to appear in the wrong locations.

Version 4.8999999c

-Fixed problem with something something sometimes dropping the wrong kind of something something when broken.

Version 4.8999999b

-Fixed a problem with the alignment of a certain something something in jungle temples, which was slightly off when the temple was facing in some directions.
-Fixed visual glitch where something something wouldn't always show the something something it contained if it was a small amount.

Version 4.8999999

-Added a couple of little something somethings to non-looted jungle and desert temples to make exploration more fun in general.  This was done particularly to make the search for villages more interesting as the player will now have secondary things to search for in different biomes as they travel about. What exactly is there and what it does is left to the player to discover, but suffice it to say these temples are now worth looking for and finding.  Obviously, this will only affect newly generated temples.
-Added the ability to right click on a Stake that already has string attached in the direction you are facing in order to remove the string and drop it around you current location (that sounds complicated but it really isn't in practice).  What this means is that you can place a succession of Stakes while trying to measure an exact distance without having to travel back to the original one to collect all the string each time you get it wrong.  Along with the other changes to them in this release, this was done to make measuring distances using Stakes and string a little more convenient, as I don't get the impression they were seeing much use as is.
-Added the ability to place Stake String through blocks than can normally be replaced by others like grass and snow for convenience, and because it felt distinctly weird when such attempts were blocked in this way, more like it was a bug.
-Added some sound to the placing and removing of Stake String to provide a little more feedback on its use, and make it a little more satisfying to play around with.
-Changed enchanting tables to no longer be player craftable.  Instead they must be found in the world similar to brewing stands with witch huts.  Guess that gives you a pretty strong hint as to what one of the something somethings in the temples is :)
-Changed the recipe for the Infernal Enchanter to consist of a regular enchanting table surrounded by 5 Soulforged Steel ingots in a "U" pattern around its sides and bottom, with two black candles with a bone in the middle on top.  In other words, it's now an "upgrade" to the regular enchanting table instead of being something the player creates from scratch.
-Changed the Hopper, Cauldron, and Crucible rendering to correct some minor visual glitches with texture alignment and lighting.  This should be most noticeable with custom texture packs.
-Fixed a problem that was causing XP orbs to get visually jittery as they were passing over the top of Hoppers in a water flow.

Version 4.899999

-Added Stoked Fire textures back into BTW and improved the way they render to create a seamless transition between Stoked Fire and any regular fire that may be above it.  Note for texture pack artists: This uses procedural textures (textures generated by code, not data) similar to how things worked in vanilla before 1.5.  This means that you can not modify the animations directly.  The textures will however adjust to the resolution of the texture file stubs you will find in the appropriate directory, so you can adjust their resolution to match the rest of your pack.  The actual image in the stub doesn't matter, but the size will determine the resolution of the resulting texture.  You'll also want to make sure the size of the various stoked fire texture stubs are the same to prevent problems.
-Changed shears to consume more durability when they're used to harvest Creeper Oysters.
-Changed the food system internally to make sure the player has valid food levels, as there was some indication they could get messed up on occasion.  I also changed fat level to reset to zero if you're importing a vanilla save.
-Changed wolf howls so that they are reduced in volume as you go deeper below sea level.  Note this in no way calculates sound attenuation due to traveling through stone or what have you (that would be way too computationally expensive), however it should greatly reduce the number of wolf howls you hear when you're digging deep in the earth.
-Changed webs to yield two silk when crafted instead of one, to make harvesting them with shears a little more rewarding.
-Changed Hardcore Buckets so that you can't pickup water in a bucket that you just placed.  In other words, a water block must have a valid source in order to fill a bucket.  This prevents exploits with being able to use the same water bucket over and over again by rapidly recollecting the water that results, in order to further promote the channeling of water for things like creating obsidian.
-Fixed the effect of beacons on compasses.  It turns out this was lost in the port from 1.4 to 1.5 due to changes in the texture system, and wasn't noticed until now.
-Fixed vanilla problem that was jamming up mob spawning under certain circumstances, which was particularly noticeable after spending a long time in a specific area.  This was mainly related to squid spawning, causing them to not spawn at all after awhile, but you may also notice a slight increase to mob spawning in general.
-Fixed a few vanilla item duplication bugs related to pistons, as I got curious as to what was causing them and it turns out they're super simple to correct.  This should mainly affect rails.
-Removed vanilla nether brick from the creative inventory to prevent confusion with BTW's item.
-Removed the ability to place pressure plates on fences as it was leading to item detection exploits, and the same aesthetics can be achieved with BTW Tables.

Version 4.89999

Note: Despite being small in size (mainly bug fixes here) this is a very special release of BTW in terms of it representing a significant development milestone.  It finalizes the balance of all the current content, with one notable exception: Hardcore Villagers (which I'll be wrapping up shortly).  There may be small tweaks and of course bug fixes that take place in the future, but from this point forward players can rest assured that nothing major will change under them within their worlds.  As such, it probably also represents a perfect point for those of you that have been waiting on starting a new world to do so, just as long as you stay away from those pesky villagers ;)

-Added the ability to place Candles on Lightning Rods and glass blocks for increased aesthetic options.  Note that the shape of the Lightning Rod will adjust slightly if there is a Candle above it to make it look more like a candle holder, and like before, Lightning Rods may be stacked to form one of the desired height.
-Changed the Lightning Rod recipe to be 3 Soulforged Steel nuggets in a vertical line with a SFS ingot at the bottom, both to reduce the cost of a largely aesthetic feature, and to provide in-game justification for why it functions to disperse lightning without a ground.
-Changed the way Axles work internally to resolve a number of outstanding issues with them.  Please let me know if this causes any noticeable issues with mechanical power as this change was rather involved.  Note that as one beneficial side effect of this change you can now connect 3 Axles to an Axle with a power source attached (Wind Mill or Water Wheel) without any of them breaking, which allows for slightly more flexibility when placing them, and slightly fewer Gear Boxes being used.
-Fixed problem with the Block Dispenser not placing Flour as bread dough.
-Fixed problem with clay and Unfired Pottery not playing sounds when spun on a Turntable with particles turned off.
-Fixed problem with Cement not appearing to slope in liquid form.
-Fixed problem with Cement Buckets making whimpering sound when not successfully placed.
-Fixed problem with Axles sometimes not updating their visual power state (whether they're animated as spinning).

Version 4.89667

-Added bread to Hardcore Baking (silly oversight on my part in the last release).  Flour may now be placed as a block which can be cooked into bread in the Kiln.
-Added the ability to Hardcore Pack blocks using any surrounding solid surface, not just full blocks.  In other words, if they are facing the right way, you can now use stuff like Siding, slabs, and other pistons to contain the area where the items will be packed.  Worth noting is that glass also works (it did in the previous release but I forgot to mention it), which is nice if you want to be able to see the interior of the packing area.  This should function with most suitable blocks, but I may have missed some so let me know if you come across any that don't work.
-Added the ability to place Candles as blocks.  As an aside, Vases make for lovely candle holders, and if you find another Vase, and place it down next to the first one, you can have a nice little path running down the middle (A path! A path!).

Version 4.89666

-Added Hardcore Packing as a new mechanic.  The way this works is that if a piston (or a solid block pushed by a piston) pushes certain items into an enclosed space (an empty block surrounded on all sides by solid blocks.  It doesn't work on partial blocks with solid surfaces at present, although I may add that in the future), the items will be automatically compressed into block form if they're present in sufficient number to complete the regular recipe (e.g. 4 clay balls for a clay block, 9 Dung for a Dung block).  This applies to clay balls, snowballs, flint, bricks, Nether Bricks, Soap, Dung, and the various piles (dirt, sand, gravel, & soul sand).  In other words, it basically works to form any simple storage block for items that wouldn't require additional work or tools in their crafting (like Padding or Iron blocks).  This is of course very useful in automation builds.
-Added Hardcore Baking.  This changes the crafting of cookies, cake, and pie (the recipes for which remain unchanged other than that I made them shapeless) so that they produce uncooked varieties.  These uncooked items may then either be cooked in a furnace, or in a Kiln (they may be placed as blocks manually or with a Block Dispenser) to produce the finished version.  This was done for the sake of consistency since it felt distinctly off that these items didn't need to be cooked. 
-Added the ability to place clay balls and Nether Sludge as blocks either manually or with the Block Dispenser.  Both of these items will cook into bricks of the appropriate type if placed in a Kiln, and this opens up the possibility of automating brick production.
-Changed the piston recipe to consist of 2 Wood Siding with an iron ingot in the middle on the top row, 2 cobble with a Soul Urn in the middle row, and 2 cobble with a Redstone Latch in the bottom row.  This is to adjust it for the changes in the last release that created a separation in the progression between obtaining a Crucible (and Soul Urns), and only obtaining Soulforged Steel once the player reaches the end dimension, while retaining the piston's overall dependance on BTW's tech tree.  It also allows for some basic automation involving pistons to be performed in the period in between.
-Changed the in-game name of the Chocolate Milk Bucket to just be "Chocolate Milk" to coincide with the milk bucket just being called "Milk".
-Changed the sounds on Clay and Unfired Pottery to be squishier.  I like squishy.
-Fixed vanilla problem with piston heads sometimes moving right through items without pushing them.  This was the issue that inspired people to use sticky pistons with blocks attached instead of regular pistons due to regular ones being unreliable.
-Fixed vanilla problem with other players in SMP either being invisible or appearing in the wrong location after going through a nether portal.  Thanks to Youtuber Panda4994 for posting his solution to this issue!
-Removed the ability of the Block Dispenser to assemble clay and snow balls into blocks, as this is now covered by Hardcore Packing and was serving to muddy the functionality of the BD too much.

Version 4.8942

-Added Ender Slag and Soul Flux as new items.  Ender Slag is produced as a result of cooking end stone in a Kiln (instead of Brimstone, and along with White Cobble).  Cooking the slag in a stoked Cauldron will then separate it into Brimstone and Soul Flux.  Soul Flux is required to successfully bind the souls in the process of creating Soulforged Steel in a Crucible (along with the previous iron, Soul Urn, and Coal Dust).  From a gameplay perspective, it is intended to better integrate the end dimension into BTW's overall progression, further encourage the creation of gunpowder by making cooking endstone a necessary aspect of progressing (creating Brimstone as a bi-product of that encouraging players to make use of it), and to help spread out the late game tech tree a little better as it was feeling very clumped together in the final stages.  This should give iron and diamond more of a place in the progression as well, since the ability to effectively use iron for tools, armor and weapons is largely gained with the Crucible (and previously made largely obsolete by SFS at the same time).  It also provides a little more room in the progression for the vanilla enchanting table, and coincides with BTW's "backstory" in terms of what the end dimension and its inhabitants represent.
-Added the ability to recycle tools and other items that use Diamond Ingots in the Crucible to further encourage the use of diamond tools & armor in the middle game, make them a more prominent part of the game overall (since players had a tendency to not want to create them due to the diamonds going to "waste"), and to provide an additional reward for attaining the Crucible level of tech now that SFS has been moved higher in the tech tree.
-Changed diamond tools, weapons and armor to be equally enchantable as iron, for similar reasons, as particularly with tools, the difference between an enchanted iron tool and a diamond one, was negligible, making it arguably more efficient to not upgrade to diamond.  Given such items are iron-based in BTW to begin with, this tends to fit.
-Changed the recipe for Ender Spectacles to no longer be dependent on the Anvil, since you can no longer obtain an Anvil without visiting the end dimension, and since Spectacles are more or less necessary if you want to travel there (without having nothing to worry about anyways).  The recipe now consists of two Oculars of Ender with a single Strap in between, in a horizontal line.  I've also changed the ocular recipe to only produce one unit, as the spectacles are now a significant enough portion of the tech progression to warrant the extra resource expenditure.
-Changed the recipe for the Screw to no longer require the Anvil for similar reasons, moving it a little earlier in the tech tree (not much mind you given glue is still required for a Screw Pump) while preventing it getting pushed much further into it with the other changes in this release.  The recipe is basically the same as before, with the bottom row chopped off, and requiring 6 iron ingots instead of the previous 8.
-Changed the recipe for the Lens to also no longer be Anvil dependent.  It now consists of 6 gold ingots in vertical lines with a single diamond in the middle of the top row, and a single glass block (not a pane...the idea is that the block is shaped into a lens as part of the crafting) in the middle of the bottom (you're welcome Dave ;) ).  My overall feeling on it was that the Lens wasn't seeing as much use as it should have due to the prohibitive cost, so hopefully that will correct that aspect as well as adjusting its availability based on the other changes in this release.  I also put in an "upside down" version of the recipe to make it a little easier to remember.
-Removed Endermen converting blocks to end stone while still in the overworld.  While cool, removing this was necessary to bottle-neck progression at the player going to the end dimension, as otherwise Soulforged Steel could be created without ever visiting it, albeit in a rather time consuming manner.  The conversion process is now considered to take place as the Endermen travel between dimensions.
-Removed the option to disable Hardcore Buckets. Sorry guys, but while I had left this in out of consideration for people with old worlds (myself included), my impression is that it was just being abused by new players far too much, largely wrecking BTW's balance in the process, while there aren't many of us left still playing worlds that old (and those worlds now feel "cheaty" for a whole host of other reasons that option couldn't reconcile anyways).  After putting a lot of thought into it I decided that the overall design has become way too dependent on HC Buckets being enabled to leave it as optional.

Version 4.8915

-Added a few aspects to Hardcore Wood to make tree farming in general more interesting and a larger part of the game.  First, all overworld saplings (not Bloodwood which remains unchanged) have 4 individual growth stages which vary in appearance.  The time it takes for saplings to grow into trees has *greatly* increased (they should now take longer than any other plant to grow), meaning that particularly in the early game, the player will be much more dependent on existing forests for wood, surviving in an area devoid of trees will be much more difficult, and tree farms will need to be much larger to keep up with the same demand.  Given Bloodwood is not affected by these changes, it also serves to further increase its value for automation later in the game.
-Added Jungle Spiders as a replacement for the cave/Vioki spiders that were previously spawning in jungles.  They have their own texture, unique attributes, and spawn conditions now which are left for the player to discover.
-Added a new *edible* Cocoa Bean item that is separate from the old one.  Old bean items will be converted into Cocoa Powder, which may be created by grinding the beans in a Mill Stone, and which may be used as dye in the regular manner.  Note that while Cocoa Beans are edible, Cocoa Powder is not unless it is used as a cooking ingredient to form other foods.
-Added the Chocolate Milk as a new food item.  It is created by mixing Cocoa Powder and a milk bucket in the crafting grid.  In addition to boosting the food value of milk buckets, Chocolate Milk also retains milk's poison neutralization effects.
-Added Chocolate as a new food item.  It is created by cooking Cocoa Powder, sugar, and a milk bucket in the Cauldron.  Similar to other desert items it may be eaten even when the hunger meter is full in order to build up fat.
-Added "Pigs Will Eat (almost) Anything!" as a new feature.  This changes pigs so that they'll eat, follow, and breed with *any* of the domesticated crops be that wheat, carrots, or potatoes (cooked or raw).  Coincidentally, they also love to eat chocolate (go figure) which means that in some cases they may be bred slightly earlier in the tech tree.  Note that they can still also be bred with Kibble, but will still not follow it (it still doesn't taste THAT good).
-Changed the growth and drop rates of cocoa plants to make farming them more interesting and balanced given their new role as an early game food source.
-Changed (reduced) the growth rate of sugar cane to better fit the balance of the rest of the mod.
-Changed the recipes for cookies to replace the cocoa beans with Chocolate.  The recipe is now two flour with Chocolate in the middle, in a horizontal line.
-Changed (increased) the hunger restored by drinking milk slightly.
-Changed spawn restrictions on mobs in general in jungles so that they can no longer spawn on leaves, basically reversing the change I had previously made to the vanilla spawning behavior.  This was done because of how other mob spawns now relate to Jungle Spiders.
-Changed some code internally to consolidate how animals are tempted by various items to reduce on the associated performance overhead.  I just mention this in case it causes any problems with which items tempt which animals.
-Fixed problem with hat damage being reduced by armor (it wasn't supposed to be).

Version 4.8914

-Added a brewing stand to witch huts and disabled the crafting recipe.  The only way to find them in game now is to track down a witch hut.  This was done to create a stronger association between witches and potions, because blaze rods are already sufficiently useful and tracking down a nether fortress was a requirement for most potions anyways given the need for netherwart to create them, and to provide an actual gameplay purpose to witch huts as finding them was largely a non-event.
-Added a sound to enchanting using the vanilla enchanter.
-Changed jack o'lanterns so that they go out in water in order to increase the value of glowstone as a lighting option.  Note that this will not affect jack o'lanterns already in your world to avoid breaking existing builds, but only newly placed ones.
-Changed the way golems (both iron & snow) are created.  They are built the same way as before, but now require a Soul Urn to be smashed against the pumpkin/jack o'lantern in order to bring them to life.  I also threw in a few particle effects and sounds into the process to make it a little more interesting and less sterile.  Note that this also provides a means of automating golem production should you be so inclined.
-Changed the sound on the Bellows as I didn't realize it had been changed to a click by a previous vanilla release.  This also involved changing the vanilla sound code so that an individual sounds amongst a random collection may be played.  I mention that last part in case it's also of use to add-on authors.
-Changed the positioning of ghast fireballs when first fired slightly so that they match up better with the direction in which the ghast is actually aiming.  This should allow them to fire through smaller gaps without accidentally hitting the walls on occasion.
-Fixed problem with how vanilla computes line of sight through blocks, which affects a wide range of behavior like Ghasts randomly firing at the player with no line of sight (this should no longer happen).  Note that this will likely have far reaching consequences to other systems (particularly to AI), as there were some fundamental problems with the related code, so you will probably notice slight improvements in other areas as well (like skeletons not randomly and repeatedly shooting at walls on occasion).  I rather extensively refactored the related code (bordering on a rewrite) in the process, making a number of optimizations to it along the way, so you may also notice a slight performance boost.
-Removed the restrictions I placed on only being able to access the crafting table from the top in the last release.  After more extensive playtesting, I've decided it was more of a pain than it was worth, and I'll instead endeavor to find another solution to the exploits in question in a future release.  Sometimes these things work out, and sometimes they don't :)

Version 4.8913

-Added a few additional refinements to Hardcore Headwear that I didn't have time to get into the last release.  Nothing to worry about here, as this should just make the existing behavior a little more evident and polished, rather than more dangerous.  Well...mostly ;)
-Changed zombie pigmen to not drop gold nuggets in the overworld so that effective pigmen farms are restricted to the nether.
-Changed the crafting table to only be usable via its top surface to prevent various placement exploits.  I've also added a message when other parts of the block are clicked since this functionality may not be immediately apparent.
-Changed Abandoned Villages to generate with all glass removed from the windows, as the glass was making it a little too easy to turn the buildings into early game shelters.
-Changed squid to only spawn in darkness.  Also changed it so that spawning may occur at any height (vanilla code had it limited to below sea level and not to occur at extreme depth).  I mention this as it may affect existing squid farm design, and it should be noted that the old BTW restrictions of only being able to spawn in large bodies of water still apply.
-Removed the Hemp Seed drop entirely from tall grass to make the method of obtaining it more clear cut, and because the existing rate had become so low that it was just encouraging people to do a lot of tedious grinding punching grass in the early game.  If you want to find Hemp Seeds, the method to do so is through tilling regular grass blocks.  If you want to lure chickens in the early game, look for pumpkins.
-Removed feather drop when chickens are sucked up by the Block Dispenser, as this was always intended as a gag feature, not as a means of automation.

Version 4.8912

-Added Hardcore Headwear. This isn't at all related to Hardcore Nothing To Worry About, but you still shouldn't worry about it regardless.  Just think of it as a new clothing option with which to further accessorize your Steve!  Huzzah!
-Added the ability to use Soul Sand Piles in the nether to help find nether fortresses.  It is rather short range, still requiring a fair amount of exploration, but throwing a pile will give you an indication as to whether there is a fortress in the vicinity, and in what general direction.
-Added the ability for witches to spawn in swamps.  They will spawn in darkness around and above sea level in swamp biomes and this replaces their witch hut spawns, making swamps slightly more dangerous overall.  On generation of witch huts, witches will spawn in their general vicinity once and once only, and these hut witches will not despawn, which means that when you first find a hut, it will almost always have witches nearby, and thus be dangerous.  This was done as the spawn conditions on witches were extremely gamey and resulted in rather cheezy traps.  Also, many players were never even seeing witches, so this is intended to make them a more integrated and interesting part of the game overall.
-Changed animals to be more responsive to tempting items the player is holding, so that if you switch items or move out of range, there will be less of a delay before they will become interested in them again.
-Fixed vanilla problem with lava not decaying properly.  This is largely an import of Mojang's fix for 1.6, but I also changed it around slightly to make the decay a little less uniform as the vanilla version looked a tad weird.

Version 4.89113

-Added ability to use Potash to bleach colored wool items in the Cauldron.  It takes a lot of wool though (32 of them) due to the ratio with wool blocks.
-Changed (increased) the rate at which ghasts spawn as part of Hardcore Hell, as it was still a little weak.
-Changed (further reduced) the range of Rotted Arrows as there still wasn't enough incentive to upgrade to normal arrows.
-Changed the chances of mobs picking up items to be uniform across difficulty levels.
-Changed enchanted equipment that spawns on mobs so it has uniform strength accross difficulty levels.
-Changed the chances of villagers turning into zombies when killed by zombies to be uniform accross difficulty levels.
-Changed chance of flaming zombies setting things they attack on fire to be uniform accross difficulty levels, since this could actually make things both harder or easier in BTW given it will both do more damage and cook animals for you.
-Fixed problem with lava buckets not retaining their cook time in furnaces on save/load. This should only be applicable with HC Buckets turned off.
-Fixed problem with fat levels not being properly communicated to other players in multiplayer.
-Fixed problem with the Block Dispenser sucking wool blocks off of sheep rather than wool items.
-Removed peaceful and easy difficulty levels as they were was no longer relevant to BTW given the large role mobs play in the mod overall, given BTW has not been balanced for them and thus they represented a fairly random play experience, and given these setting were just prone to exploiting.  It should be noted that with the changes I have made in this and previous releases, game behavior should be entirely consistent between the remaining difficulty levels (normal and hard), with the one exception of the damage that mobs do to players when attacking (and related aspects like poison duration).  This means that players should be able to make slight adjustments to the difficulty of combat to suit their tastes without worrying about it affecting other ambiguous aspects of the game such as the rate of output from mob traps, or the rate of fire spreading.  It is also worth noting that I have always balanced and tested BTW on normal difficulty alone, so if you're interested in playing the mod as it was designed and intended, then normal is the way to go.  I have left hard in for people that want to make things slightly more challenging, particularly in co-op play, but I make no guarantees as to its balance.

Version 4.891124

-Added Hardcore Hell.  This involves several tweaks to the nether (mostly to ghasts) to substantially increase its difficulty as it was feeling very weak compared to what it used to be.  There was a time when just waltzing around in the open in the nether was really not a feasible option, and that brought along with it a sense of tension and specific building requirements that were unfortunately lost somewhere in MC's ongoing development.  I've basically tried to restore the nether to being the terrifying experience I remember it as when I first started playing Minecraft (shortly after the nether was first introduced), and in the process extended the mid-game portion of BTW giving players good reason to spend time upgrading their equipment at the iron and diamond levels before progressing further.
-Added wool as a new item, which is dropped from sheep instead of wool blocks.  Wool blocks may still be created by surrounding a Wicker block by 4 wool items in the crafting grid (plus sign pattern), with the resulting color of block being a mix of the colors of wool used in its creation.  This was done to reduce the effectiveness of wool in the early game in creating cheap barricades, to make wool blocks feel more "solid", and along with other changes in this release, to increase the value of keeping sheep as livestock (particularly in the early game where shearing them can provide a renewable source of cloth and padded armor).  Thanks to DaveYanakov for this idea!
-Added a visual indication of fat level to the player model so that others will have a better idea of when someone is a particularly nutritious food source.
-Added recipe to convert snow blocks back into snow balls.
-Added some variance to where you will respawn after dying in the same area multiple times with Hardcore Spawn.  This was done both to decrease the number of incidents where the player would continually respawn in the same location only to be killed again by the same monsters, and to decrease the viability of intentionally killing yourself to exploit the hunger/health system.  You'll still respawn in the same general area, but your precise location will usually be different.
-Changed the Wool Slab recipe to require three Wool Blocks side by side in the crafting grid, similar to the recipes for vanilla slabs.  
-Changed the Padding recipe to consist of 2 fabric with 1 wool in the middle, in a vertical line.
-Changed the wool armor recipes to use the new wool items instead of wool blocks.
-Changed the wool armor recipes to produce armor of a color that's a blend of the various colors of wool that are used in its crafting.
-Changed (decreased) the regrowth rate of wool on sheep.  Similar to cows producing milk, they will now need to consume grass several times before their wool grows back.  Also added a sound effect for when the wool regrows.
-Changed the chance of fire spreading to be identical across difficulty levels.  It now always works as it did on hard difficulty previously.
-Changed (increased) the spawn rate of ghasts in the nether to increase the difficulty of the nether overall.  
-Changed (increased) the hit point value on ghasts as despite their large size, they were actually one of the weakest mobs in the game, and their hit points were never adjusted when bows became more powerful with the "adventure update".  This also helps to further promote the use of Broadheads in the late game, or at least the use of normal arrows as opposed to rotted ones when first visiting the nether, since archery is the primary method of dealing with ghasts.
-Changed (increased) the minimum distance at which ghasts can spawn from the player, to reduce instances of players getting blasted soon as they first emerge from a nether portal, or having a ghast pop up out of nowhere to immediately start shooting at you.  This should also mean that once you clear an area of ghasts, it should at least temporarily remain that way until they wander back into range.
-Changed a small thing about Hardcore Nothing To Worry About, which you also shouldn't worry about.
-Fixed vanilla problem with ghasts not actually aiming at the player (often it would be over your head if the ghast was above you).
-Fixed vanilla problem with "living" sounds on entities (chickens clucking, cows mooing, ghasts moaning, etc.) tending to play all at once for all entities when you first loaded the game or changed dimensions.  This was particularly noticeable with ghasts and caused a fair amount of stutter when entering the nether, but may result in an overall performance boost on game/chunk load.

Version 4.891123

-Added a few tiny little insignificant things related to how various creatures react to nether exposure.  Absolutely nothing to worry about here, as they like the nether lots and lots.  Mmmmm, mmmm...can't get enough of that nether exposure.
-Added recipes to incinerate/melt down the following items in the Crucible to retrieve the metal used in their creation: Gear Box, Saw, Pulley, Screw Pump, note block, and the various pieces of the gimp suit.
-Changed various in-game visual effects such as the Ender Spectacles, confusion, pumpkins, etc. to function even if the player has the GUI turned off in first person view.
-Changed (optimized) the code to prevent animals spawning in leaves from the last release as some performance problems were reported that I believe may have been related to it.  Note that due to these changes, animals *may* still very rarely spawn stuck in leaves (I haven't seen it happen but it's theoretically possible), but it should be greatly reduced from vanilla and I doubt it will ever happen in jungles (which is what that change was primarily meant to address).  Players may actually notice a slight boost in performance during chunk generation from what it is in vanilla or before the last release, as I also cleaned up the related vanilla code as part of this process.
-Changed the recipe for melting down iron doors in the Crucible so they return the gold used in making them as well as the iron.
-Changed (decreased) the drop rate of the Arcane Scroll associated with bats, as automated bat farming is now possible.
-Fixed problem with a crash in creative mode when breaking lily pads.
-Fixed vanilla problem with bows leaving a ghost item in your inventory when they break due to use.
-Removed pigmen spawning randomly around nether portals as it couldn't really be prevented in game, wasn't related to pigmen actually having access to your portal on the nether side, and was largely just an annoyance with no real in-game justification.  The stuff you should most definitely not worry about largely replaces this kinda thing now anyways, so any concern, dread, or sense of impending spikey doom you were experiencing over this is entirely unwarranted.  Sheeesh...you're just opening portals to hell, so I have no idea what you're getting so nervous about.  Chill.

Version 4.89112

-Added functionality to flint & steel for it to only have a chance of starting a fire each time its used, and to scare animals in the vicinity with each attempt.  This is both for immersion and to prevent exploits involving using it as a rather cheap (both in terms of cost & usage) weapon.  Also added a more satisfying sound for when it successfully starts a fire.
-Added a couple of sounds to witches in an attempt to make them cooler.  It didn't work.
-Added recipe to melt down Redstone Latches in the Crucible.
-Changed the Bellows to be able to blow items through blocks like pressure plates, and ones that can't be collided with (like torches).
-Changed Gear Boxes and Pulleys to drop a couple of gold nuggets when they break due to overpowering, and to not drop redstone dust (it is lost in the breakage) to adjust for the Redstone Latch being a part of their recipe now.
-Changed Bellows to drop a number of Straps instead of whole pieces of Tanned Leather when they break, as they were dropping more leather than was used in constructing them with the high efficiency cut leather recipe.  It also makes some sense that smaller pieces of leather would be all you could salvage.
-Changed animals to no longer be able to initially spawn embedded in blocks during world generation.  This should primarily affect animals spawning buried in leaves and unable to move, and should be particularly noticeable in jungles (although this affects animals in all biomes to a lesser degree as well).  Obviously, this won't affect animals already spawned into the world, so you may still see embedded animals in old chunks.  In combination with some of the below changes, this should make jungle biomes significantly more difficult to survive in as they were way too easy before.
-Changed (increased) the movement penalty associated with moving on leaf blocks to represent the difficulties of moving through dense foliage.  This should both make jungles more difficult to navigate, and further encourage clearing paths through them rather than just jumping onto leaves.
-Changed the smaller animals (chickens, pigs, and ocelots) to not be affected by movement modifiers due to terrain and vegetation, making catching them in dense brush much more difficult.
-Changed jungle biomes to not spawn the larger animals (cows and sheep) given the difficulty such animals would have navigating and grazing in such an environment, and given they didn't particularly suit the character of the biome.  
-Changed a small thing about mob behavior in jungles.  Nothing to worry about.  It's all good.  Honest.
-Fixed snowmen being inconsistent in their ability to place snow on slabs and other partial blocks (tall grass etc.), and not being able to place snow in front of Detector Blocks or Lens beams.
-Fixed problem with not being able to place blocks while swimming in lava.

Version 4.8911

-Added increased resolution to the hunger meter to accommodate foods with smaller hunger values (such as mushrooms).  Previously, it only worked in half-pip increments, which meant that was the minimum amount of hunger any food could restore.  This made balancing the foods any further extremely difficult.  Now, any food item can restore a minimum of 1/6th of a pip making staying full on low value food sources much more difficult.  Hopefully, this should also make activities that burn hunger quickly (such as jumping and sprinting) much more evident, as they'll have a more immediate visual impact.
-Changed mushrooms to only restore 1/6th of a pip of hunger instead of 1/2.  This adjustment was made primarily to decrease the value of swamps in the early game, as previously they were veritable horns of plenty.
-Changed Mushroom Omelets, Cream of Mushroom & Hearty Stew to require three mushrooms instead of 1 to create.  The only mushroom based recipe that doesn't require 3 now is the Kebab.
-Changed pumpkin seeds to also restore 1/6th of a hunger pip.
-Changed milk to have a fat value when consumed.
-Changed the piston recipe to require a Redstone Latch instead of redstone dust to be more consistent with the other recipes that involve the latch, and from a balance perspective because piston traps are one of the primary forms of nether mob traps with gold being one of the primary outputs of those traps, creating a nice feedback loop (collect gold, expand trap, etc.).  I hesitated on this at first because of the in-game logic behind why pistons would work the way they do ("shocking" the souls to move them versus giving them a little push), but in the end, decided this was the right way to go.  With the additional changes in the last release, the resulting recipe relative to the vanilla one then is Siding in place of the wood blocks, a Soulforged Steel ingot in place of the iron, and a Redstone Latch in place of the redstone dust.
-Changed crafting sounds (creeper oysters, shears, chopping logs with an axe, etc.) so that they will be heard by other players in SMP.
-Changed monsters so that they don't stop targeting something if they take damage from an environmental source (such as falling).  This should be particularly noticeable with spiders not stopping targeting the player if they take fall damage.
-Removed vanilla's decreased charge time on creepers when they fall on you from heights as it was just a silly artificial increase in difficulty that resulted in random deaths the player could do nothing about.

Version 4.891

-Added Hardcore Archery.  This makes a few changes to the way bows work.  First, it requires players to have arrows in their hot-bar in order to use them, abstracting the idea of a quiver, making bows a little more inconvenient to use to balance their power, and also allowing the choice of precisely what kind of arrows to use at any given time.  Arrows are used in left to right order should the player have multiple arrow types in their hot bar, and note that infinity enchanted bows do not require arrows in the hotbar (although they will use them if present) increasing the value of that enchantment.  Secondly, it reduces the range of Rotted Arrows when used with a regular bow (they still always break when used with a Composite Bow), reducing their effectiveness to further encourage making your own arrows.  Lastly, it reduces the output on the arrow recipes so that you only get 1 arrow instead of 4, making them a much more valuable commodity (the Broadhead recipe has had its output boosted slightly to compensate for the amount of Soulforged Steel it consumes).
-Added Hardcore Enchanting.  This rebalances the vanilla enchanting table in various ways to make it a better integrated part of the BTW tech tree, and to make it feel more like a feature and less like an exploit.  This feature is comprised of various changes that are listed individually below.
-Added the Redstone Latch as a new item.  This device creates a small amount of physical force when a redstone signal is applied, which can then be used to trigger various devices, and is meant to bridge the gap between redstone as a pure signal and various blocks that produce physical results (such as doors), following the in-game logic of powered rails producing similar results.  It is created by crafting redstone dust with a horizontal line of three gold nuggets above.  This is intended to bring both a bit more consistency to the internal game logic of what redstone does, and is also intended to increase the value of gold throughout the game.
-Added Soulforged Steel Nuggets as a new item for consistency with the other metals, and because the recipes involving ingots were getting overly complex for nothing, especially when the items were being melted down in a Crucible.
-Added high efficiency recipe for Black Stone (nether quartz) Stairs, made out of three Black Stone Moulding.
-Added a slight delay in recovering your air supply upon surfacing to prevent exploits involving placing temporary blocks like torches to create air pockets.
-Added sound effect for when the player is underwater and wearing a Soulforged Steel Helm with a respiration enchantment.  Yes, that's extremely special case.  I couldn't resist :)
-Changed the recipes for the following blocks to use the Redstone Latch in place of redstone dust: iron door, dispenser, note block, Gear Box, and Pulley.  The recipes remain unchanged otherwise.
-Changed gold ore to smelt into nuggets instead of ingots.  In the end, I decided that while previously it had been my hope to maintain the value of mining gold throughout the game, that it wasn't winding up being particularly compelling anyways, and that I'd prefer to further incentivize the construction of nether mob traps in the late game given that.  Additionally, gold was primarily getting abused as an early game tool substitute for iron given its relative abundance.  In the early to mid game, mining gold now has value given the changes with the redstone latch, and in the late, the desire to create additional redstone devices hopefully serves to further promote nether mob trap construction.
-Changed Crafting Tables and Furnaces to drop parts instead of whole blocks when harvested (unless a silk touch enchant or Block Dispenser is used) to fit better with the concept of these being non-portable workstations in contrast to the small crafting grid the player has in their inventory.  This is intended to encourage putting a bit more thought and planning into the setting up of more permanent installations for these crafting devices rather than just carrying them around and placing them wherever and whenever they're needed.
-Changed the vanilla enchantment table to not be able to apply some of the more powerful enchantments, which now may only be acquired through finding pre-enchanted tools and weapons, or through using the Infernal Enchanter (or through beacons in some cases).  This applies to silk touch, fortune, sharpness, father fall, and protection.  Basically enchants that have very specific (and powerful) effects (like silk touch & feather fall), or those that apply general bonuses (such as protection & sharpness) as opposed to specific ones (like blast protection or smite), have been moved higher in the tech tree to create more of a progression to enchanting overall.
-Changed the vanilla enchantment table to no longer be able to enchant bows and wood tools (the latter for consistency, implying that wood is a particularly difficult material to enchant).  This is strictly the domain of the infernal enchanter now.
-Changed the vanilla enchantment table to be crafted using Black Stone (nether quartz) blocks instead of obsidian, and an Ancient Manuscript instead of a book, to bump it up *slightly* in the overall tech tree as well as to increase the value of quartz.
-Changed the vanilla enchantment table to only be able to apply enchantments up to level 15 instead of 30.
-Changed the number of book shelves around the vanilla enchantment table required to get the maximum level enchant (level 15) back to 30 instead of 15.  In other words, it will require 2 book shelves for ever level of enchanting.  Additionally, the enchantment table will only produce level 1 enchants without any bookshelves at all.
-Changed the vanilla enchanter so that the top slot will always provide a level 1 enchantment, the bottom slot will always provide an enchantment of the maximum level allowed by the shelves present, and the middle slot will provide some random value in between the two to minimize annoyance in its usage.
-Changed the Broadhead Arrow recipe to use shafts instead of Moulding.  It was confusing for no good reason.
-Changed the Broadhead (arrowhead) recipe to use Soulforged Steel Nuggets instead of ingots.
-Changed the piston recipe to require a Soulforged Steel ingot instead of an iron one, and to *require* wood panels along the top instead of wood blocks (not just the high effeciency version anymore).  This was done to better integrate it into BTW's tech tree and to better explain how it functions in-game.
-Changed creepers so that they will not drop records if deoystered.  They're just too depressed to appreciate good music anymore.
-Changed trip wires to no longer be able to detect items to prevent exploits involving this behavior.
-Fixed crash when placing a Crucible (and potentially other blocks with associated tile entities) in a location recently occupied by dried cement.

Version 4.89

-Added Hardcore Smelt.  At its core this adds different cook/smelt/bake times for ores and bricks in the furnace.  Smelting and creating smoothstone out of cobble will now take much more time and fuel to accomplish, while baking bricks and cooking glass will take more time than cooking food, and less than smelting ore.  This was done to increase the value of tree farming in the early to mid game, create a more distinct transition when moving up to iron tools/weapons, and to increase the value of the Kiln in the mid to late game.  It was also done to provide some slight advantages to a sedentary lifestyle as opposed to going nomadic, as it will now take a significant amount of time in a single location to smelt ores.  This addition involves several other changes in this release as well, which are listed individually below.  Note that I've included internal hooks for add-on authors that want to specify their own cook times for custom items.
-Added the ability to harvest Creeper Oysters with shears.  You're welcome.
-Added sound to crafting with Creeper Oysters.
-Added high efficiency item frame recipe involving sticks and cut leather, as it was a little odd that it required Moulding (it still works with Moulding too though).
-Added texture overlay for when various blocks (such as ores and logs) are cooking in the Kiln to make the process more evident.  Note for texture pack artists: the overlay replaces the old unfired pottery texture, which is no longer used by the mod.
-Changed (increased) the cook times of the Cauldron, Crucible & Kiln to relate better to the adjusted values of the furnace, and to provide a more significant advantage to having more fire blocks beaneath them.  The minimum time it takes to cook something has remained unchanged (with 9 fire blocks), but the maximum time it takes to cook (with just 1) has increased significantly, making it much more rewarding to upgrade your builds with time.
-Changed the way the Kiln works internally so that the time it takes to cook something should be slightly more consistent.
-Removed furnace recipes to smelt ores other than metals (like diamonds, redstone, and lapis), as it just didn't make a whole lot of sense for them to be in there in the first place, and it muddied the functionality of the furnace in weird ways.

Version 4.88

-Added Soul Sand Piles to the game.  These function similarly to the other piles, in terms of Soul Sand breaking apart into them if a shovel (or Mattock) isn't used to harvest it.  However, they also have some additional functionality associated with them...
-Added the ability to use Soul Sand Piles to locate players after death.  Right click with a Soul Sand Pile in your hand to get started, with the subtleties of this behavior left to the player to discover.  Note that players who died before this change went into effect can not be tracked in this manner (this means you Charlie ;) ), but dying again will cause it to register.
-Added the ability to pass the various pile types through the appropriate Hopper filters.  I had neglected to do so in the past.
-Changed weapons to take damage to their durability when they are successfully used to block damage.
-Changed the name of the "Hunger" status effect to "Food Poisoning" for the sake of clarity.
-Changed Jack O'Lanterns so that they can be placed without having a solid block beneath them.  Previously, they couldn't be placed this way, but would remain in place if the supporting block was removed, which was just silly.
-Changed boats and minecarts so that they don't collide with items.  This should prevent some rather odd behavior such as boats self-destructing when the player cuts logs while in one.
-Fixed problem with rendering books (of all types) in a Cauldron creating half as much glue as they should have.
-Fixed problem with villagers not being able to open and close wooden doors.
-Fixed slight visual vertical offset on cow heads.  They were appearing a bit lower than they should have (and than they do in vanilla).
-Removed the option to disable Hardcore Spawn.  With the addition of Soul Sand Piles, this feature is now finalized, and it's simply the way BTW plays.

Version 4.87

-Added additional effects to the Gloom.
-Changed status effects text to not display when you are dead.
-Changed the way Hardcore Of Darkness works to hopefully resolve problems with it rendering properly with texture packs that use custom colors.
-Changed the way Hardcore Of Darkness works slightly to smooth out the edges between where ambient light meets the Gloom.  It should more closely resemble the borders with torch light now.
-Fixed problem with the Refined Axe (NOT the Battle Axe...that's still 5 ingots) using 3 Soulforged Steel ingots instead of the 2 of other axes.
-Fixed problem with axes returning the wrong number of ingots when melted down in a Crucible.
-Ported Mojang's "fix" (it doesn't appear to always work..but it does help) from 1.6.2 for animals escaping fences or suffocating in blocks during chunk load so that BTW players can benefit from it ahead of time.  Note that I've spotted the occasional animal (mostly babies) still escaping fences in both 1.6.2 and with this version of BTW. This doesn't appear to happen on chunk load, but rather as a result of collisions with other animals.  Please refer any problems that you may encounter with this to Mojang, as all I've done is duplicate their bug fix here, and it appears the issue is not fully resolved.  I'm hoping at the very least it takes care of the random animal suffocation, but I wouldn't put any money on it.

Version 4.86

-Added Hardcore Of Darkness to the mod.  This consists of two things: first, areas that are in total darkness (note, this does not apply above ground where ambient light will always allow you to see), will appear absolutely pitch black regardless of your gamma settings.  Secondly, I've added status effects for the player being in total darkness that will seriously impede your ability to function under such conditions.  This was done to further emphasize light (and torches...and coal) as a resource (particularly in the early game), to discourage exploits involving jacking up brightness to effectively see in the dark, and to induce general pant-soiling goodness :)
-Changed axe recipes (for all axe types other than Battle) to only require 2 stone/ingots instead of 3.  The recipe is the same as before, with the stone/ingot on the top of the shafts removed.  This is to help balance the relative usefulness of the various tools, with an axe being nowhere near as valuable as a pick at pretty much any stage of the game.
-Removed Mojang's update pester from the title screen, given BTW is not yet available for 1.6, and given that it was frigging annoying :)
-Fixed problem with hardcore spawn setting the time of day to the next morning in LAN play (it shouldn't do that).

Version 4.85b

-Added recipe for melting down Soulforged Steel Pressure Plates in the Crucible.
-Changed the recipe for melting down the trip wire hook in the Crucible to only return 1 nugget, to match the recipe change in the last release.
-Changed recipe to melt down Souflforged Steel Detector Rails in the Crucible so that the SFS used to make it is returned.  Note that at least 3 are required for this to function given the amount of resources used in the recipe to create them.  It might be time for me to add SFS nuggets ;)
-Changed the recipe for the Soulforged Steel Pressure Plate to be 4 SFS ingots in a row, with two redstone in the center slots below to better conform with an Anvil being required to work with SFS (this produces 2 plates, so it's actually cheaper than before).  I decided to do this now as the recipe was just completely broken in the last release and needed to be fixed anyways.
-Fixed problem with Scrambled Eggs (both raw and cooked) still returning a bowl when eaten.

Version 4.85

-Added an animated texture to the Saw when it is powered.  Note for texture pack artists: due to a bug in the vanilla rendering code, it's currently not feasible to create an animation that will rotate in the appropriate direction for both top and bottom textures.  This is why the default animation for the Saw has an ambiguous rotation direction, and I'd recommend doing the same in your texture packs.
-Added Hardcore Redstone Recipes.  What this basically does is change any vanilla recipes for redstone reactive blocks so that they actually include redstone in the recipe itself to avoid cheap exploits like using levers instead of redstone torches to save on redstone dust.  It also removes redstone functionality from certain early game blocks for consistency and to increase the value of their later game counterparts, and also ties some of the redstone devices into BTW's overall tech tree.  Changes to individual blocks as part of this are listed below.
-Changed the lever recipe to consist of redstone dust, cobble, and a shaft in a vertical line.
-Changed the pressure plate recipes to consist of redstone dust with siding of the appropriate type (wood or smooth stone) above.
-Changed the button recipes to consist of redstone dust with a corner of the appropriate type (wood or smooth stone) above.
-Changed wood doors, trapdoors, and fence gates to no longer respond to a redstone signal.
-Changed iron door recipe to include 2 units of redstone dust in the top and bottom corners of the crafting grid (the 6 iron part remains unchanged).
-Changed the tripwire hook recipe to consist of an iron nugget, wood Moulding, and redstone dust in a vertical line, and to only produce one hook as output.
-Changed Obsidian Pressure Plates to Soulforged Steel Pressure Plates for consistency with the other redstone recipe changes, and because it better explains the player-only functionality provided.  They are now created with 3 SFS ingots is a row, with 1 unit of redstone dust below.  Note that this also affects the Obsidian Detector Rail.
-Changed the "supports" in abandoned mineshafts to consist of logs rather than fences and planks.  This was done to increase the challenge of exploring them, as the fences were causing pathfinding issues for mobs, and the logs cut down on visibility leading to more nasty surprises while exploring them.  Logs also look rather cool in this role and give the mineshafts a more oppressive feeling.
-Changed Mystery Meat to only drop periodically to prevent exploits.
-Changed iron and gold ores so that they only drop in the specific color of strata mined if a silk touch enchant is used, otherwise they all drop in the lightest color of stone to prevent stacking issues.
-Changed (reduced) the growth rate of Hemp to encourage larger farms and to better match the reduced growth rate of other crops.
-Changed the Turntable and repeater recipes to use clocks instead of netherquartz (or redstone dust in the older recipes) in order to increase the value of gold in the middle to late game, with the underlying in-game logic that gold is used as an interfacing material between redstone and quartz, and thus is required to create timing mechanisms.
-Changed the drops on Gear Boxes, Axles, and Saws when they are broken due to misuse to take advantage of some of the newer items in the mod (like saw dust and iron nuggets) and in order to better convey the destruction involved.
-Changed the recipes for Chowder and Cream of Mushroom to produce two bowls of soup (with the recipes now requiring two empty bowls) instead of just one to increase the value of squeezing cow titties.
-Changed the recipe for Scrambled Eggs to no longer require a bowl (it's just a bucket of milk and a raw egg now), changed the icon to reflect this, changed the recipe to produce 2 units instead of 1, and increased the hunger restored to inspire additional squeezing action.  In other words, if you have access to milk, they're now a more efficient use of your eggs than Mushroom Omelets, given the relative difficulty of acquiring milk versus mushrooms.
-Changed Hardcore Spawn so that if you're playing single player (this doesn't apply to multiplayer for obvious reasons), and you are assigned a new spawn location (dying over and over and respawning in the same spot won't do this), you will respawn on the morning after you died.  This is to prevent overly harsh situations with respawning in the wilderness in the middle of the night, and to reduce suicidal behavior upon respawn awaiting the next day.
-Fixed problem with being able to walk on the edge of blocks in order to avoid movement modifiers due to HC Movement.
-Fixed problem with mobs not burning in sunlight when caught in spider webs.  Note that this fix may not apply to webs that have already been placed in your world, but will work for all newly generated ones.
-Fixed problem with redstone torches popping off of some surfaces to which they should be able to attach.
-Fixed problem with the player sometimes being assigned a spawn location in a ravine with Hardcore Spawn.
-Fixed problem with chickens still being able to be fed by hand even if they had just eaten seeds off the ground.
-Removed the recipe for creating synthetic redstone from the mod.  Sorry guys, but this was devaluing mining in the late game at diamond level, which is something I am trying to make more rewarding rather than discourage.

Version 4.84

-Updated BTW to version 1.5.2 of Minecraft.
-Added an internal add-on handling system that effectively replaces Modloader within BTW.  This was done for a number of reasons, but mainly so that the code for SSP & SMP would be more uniform since ModLoader does not have a server version.  This made the BTW code-base more annoying to maintain, and rather difficult for add-on authors to have their mods function in multiplayer.  Note that BTW will no longer function with ModLoader installed, and thus is now likely incompatible with all mods that make use of it.
-Added a new ability to the beast.
-Fixed vanilla problem with displaying the correct information on clocks and compasses in both the stats page, and in the crafting result slot, to prevent exploits.
-Fixed problem with torches still sometimes spawning around bonus chests as items.
-Fixed some weirdness (including an item duplication) when placing torches in a block occupied by both tall grass (or other similar blocks), and snow.
-Fixed weirdness with two zombies attempting to break down a barricade at the same time.
-Removed the step sound from chickens, as that clicking was super annoying.

Version 4.83

-Added sound to crafting planks out of logs with an axe in the crafting grid.
-Changed (reduced) the furnace burn time on Saw Dust, Bark, and saplings for balance.
-Changed recipes that play sounds when used in the crafting grid (namely those involving shears or axes) so that the sound is only played once no matter how many individual items are crafted at once.
-Changed Dirt Slabs so that they must be placed on a solid surface, and will "pop" (into Dirt Piles) if they are not.  They were being used way too much for exploity barricades that didn't make a whole lot of sense.
-Changed dirt, gravel, sand and logs to drop Piles or Saw Dust when destroyed by an explosion, mainly to provide a cost to "creeper mining", but also because it fits the pile functionality much better in general.
-Changed sand and gravel so that when they fall on other blocks like torches, they break apart into piles instead of producing full blocks.
-Changed (increased) the amount of damage cows can take before dying slightly, to make them feel bigger and tougher than the other animals, and to increase the effort it takes to kill them in the early game.
-Changed sticks to instead be called "Shafts" to better reflect their creation method and use.
-Changed mycelium and giant mushrooms so that monsters can't spawn on them.  This increases its usefulness of these block, and also goes hand in hand with the mushroom biome spawn change below.  It also facilitates giant mushroom farming, as unlike trees, they'd tend to create zones on top of them in which monsters could spawn upon growth.
-Changed mushroom biomes so that monsters can spawn in them to prevent them being total safe zones, which can ruin the early game experience if you spawn near them, while together with the above changes preserving their character of being barren and lifeless.
-Removed the ability for animals to respawn.  What you get on chunk generation, is all you'll ever get now, and if you exhaust the animals within an area through over-hunting, the only way to find more is to move on.
-Fixed problem with the death message associated with a little something something.
-Fixed problem with hungry wolves continuing to attack even if they are fed.  Note that if they are angry about something else though, feeding them won't get them to stop attacking.
-Fixed vanilla problem that prevented most mobs from spawning above ground in jungle biomes.  This should make jungles more dangerous places overall.

Version 4.82

-Added Better Wolves!  Yes, that's right, after two years of poking fun at wolves as a feature, I've decided to give them a working over to be a more interesting and integrated part of BTW.  The details of this feature are left for the player to discover.
-Added more Hardcore Wood which serves to further detail wood crafting in general, and makes wood a more valuable resource in the early game.  The first change that this entails is that punching wood no longer gives you logs.  Instead, it results in planks (1 unit), Saw Dust, and Bark (which is a new item) being dropped.  Secondly, splitting logs into planks in the crafting grid now requires combining a log and an axe, and the durability of the axe will be consumed for every log cut.  Crafting a log in this manner results in 2 planks (instead of vanilla's 4), Saw Dust, and Bark being created (the Saw Dust and Bark will scatter around you as you craft, with the planks being the actual crafting result).  Finally, a log may also be cut on a Saw in the usual manner, which will yield 4 planks, Saw Dust, and Bark, making it the preferred method for wood working.
-Added Bark as a new item.  Bark acts a replacement for the log blocks that were previously included in the leather tanning recipes, with different kinds of bark being more or less efficient for tanning as was the case with wood.  Bark may also be used as a furnace fuel in the early game, similar to Saw Dust, Saplings, and other wood-based items.  Bark is produced every time a log is converted into planks, regardless of the method used (harvesting by hand, crafting with an axe, or using a Saw).
-Fixed vanilla problem that would cause you to accidentally eat food (or drink potions) twice.  Note that as part of this fix, you will only eat one food item per click, so you will not continue to eat if you just hold the mouse button down for longer than it takes to eat one item.

Version 4.81

-Added Hardcore Fist.  What this does is reduce the effectiveness of punching significantly by limiting the "knockback" on mobs to when you do a significant amount of damage to them, giving them a chance to either flee (in the case of animals), or to attack you (in the case of monsters).  The lack of knockback may also apply when using weapons in a weakened state due to status effects as well, making such effects more dangerous.  This was done to encourage the creation and use of weapons and to make hunting more challenging in the early game, and to make getting caught by mobs while lacking in a weapon a MUCH more terrifying experience (seriously...run...your suffering will be legendary...).  Note that you can still do stuff like push mobs off cliffs by sprinting at them while punching, which will still cause knockback.
-Added the ability for zombies to break down fence gates and trap doors.  
-Added the ability for moving platforms to pass through spider webs.
-Added block destroy effects (sound and particles) for when a block is destroyed by a moving platform.
-Added place and break sounds for "schluppy" blocks like Blood Wood and Spider Webs.
-Added internal hooks so that add-on authors can specify the enchantibility of items in the Infernal Enchanter.
-Changed how enchanting works for Wool and Padded armor, in that they may not be enchanted through any means.
-Changed picks to be efficient vs redstone lamps.
-Changed (reduced) the drop rate of Hemp Seeds from tall grass to encourage farming in the early game to acquire the excess seeds needed to feed chickens.
-Changed grass blocks to send a block update when they are eaten by sheep, so that they may be detected by Buddy.
-Changed fence gates and doors to send block updates when they are open or closed, so that they may be detected by Buddy.
-Fixed problem with redstone lamps not always updating the Lens correctly.
-Fixed problem with Tanned Leather, Gimp, and Chain armors not being enchantable with the Infernal Enchanter.
-Fixed problem with wood shovels giving you piles when used on Dirt Slabs.
-Fixed vanilla exploit where players could place doors in such a way that zombies couldn't break them down.
-Fixed vanilla problem where mobs would treat open trap doors as closed, and closed as open.

Version 4.80

Note: My primary goal With this release was to finalize BTW's world generation changes.  What this means is that you should be perfectly comfortable starting a new world with this release, confident that it won't be changing any further (at least by my hand).

-Added Hardcore Stratification.  This works by dividing the stone beneath the overworld into different layers, or "strata".  These layers then require different qualities of picks in order to be able to mine them.  Note that the picks required to mine various ores are not affected by this change, even though their visual appearance will match that of the surrounding stone, and they may take longer to mine at depths.  In other words, the same tools as previous to this release (and the same as in vanilla) may be used to mine the various ores regardless of the strata in which they appear, so even if you descend to a depth where you can no longer mine the stone, you may still be able to mine the ores it contains.  This was done to further promote caving as the mining method of choice in the early game, as well as to introduce a greater amount of variety and a number of interesting aspects into the gameplay experience that are left to the player to discover.  Note that it comes at the cost of a slight performance drop during chunk generation (not chunk load), which may manifest as the occasional stutter, but which I suspect is still faster than vanilla chunk generation previous to my optimizations.  I did it in this manner to avoid altering people's worlds at a fundamental level, and as a result, if you uninstall the mod, all modified blocks in your world will automatically revert to their vanilla equivalents.  Also note that at present, worlds perviously generated do not automatically stratify, and thus there will be underground (and thus largely invisible) "seams" in your worlds that you may run into while mining.  I'll be providing functionality in the near future however to convert and stratify worlds if the player so desires, to get rid of those.
-Added Looted Temples.  These function similarly to Abandoned Villages in that temples within a distance of the player's initial spawn point will be looted in order to preserve the early game balance in cases where the player spawns near one, and to further add to the mod's back story.
-Added Golden Dung.  How to craft it, and its purpose are left to the player to discover.
-Added recipe for creating a Dirt Slab out of two Dirt Piles placed side by side in the crafting grid for convenience and consistency.
-Changed the contents of dungeons chests for balance and added depth beneath the surface as a factor in how their loot is generated.  Generally, the deeper you go, the more valuable their contents.
-Changed the chest minecarts in abandoned mineshafts in a similar manner to dungeon chests for balance.
-Changed the hunger display to shake based on your hunger level rather than on fat level.  It should only begin to shake once hunger penalties begin to kick in (at 'Peckish').
-Fixed problem with wood shovels giving you piles.
-Fixed bug that caused Hardcore Fishing to almost always act like it was day time.
-Fixed problem with shears not being efficient vs vines.
-Removed spider silk to wool conversion recipes from both regular crafting and the Cauldron.  Silk and wool are now considered to be two separate materials entirely.  This was done to further promote farming sheep for wool.

Version 4.71

-Added Hardcore Fishing.  This makes a number of changes to the way fishing works to make it a more interesting part of the game.  First, fishing rods must be "baited" by combining them with various items in the crafting grid.  Most "useless" meaty items work as bait, such as rotten flesh, spider eyes and Creeper Oysters.  You can still go through the motions of fishing with an unbaited rod, but you won't catch anything.  Each time you get a nibble, there's a chance that you'll lose your bait in the process, and when you catch a fish, you will always lose your bait.  Also, fishing may only be performed above ground, and if the bobber is in large bodies of water (away from the shore and in deep water...cast into a lake or ocean and you'll be good to go).  The chances of catching fish are also much higher in the day than at night, also increased during rain and further increased if you do it during dawn or dusk.  The exception to these rules is that fishing at night on a full moon will provide the best chances of all.
-Added Hardcore Piles.  When the player digs dirt, sand, or gravel, using a tool other than a shovel (or Mattock), they will get piles of the corresponding material instead of the full block.  These piles may be crafted back into blocks, at a cost of 4 piles per block (blocks may also be split into piles if you so desire in the crafting grid), but it should be noted that you only get 3 such piles when digging without a shovel.  In other words, if you don't use a shovel, some of the material you are digging is lost as you scrape away at it with your bare hands.  Note that Piles of Dirt may also be crafted into dirt slabs by placing two of them side by side in the crafting grid, and that Dirt Slabs will also break apart in this fashion when dug with your hands.  This was done to make shovels a more integrated part of the game, and more useful tools overall.  Note that at present all piles pass through Wicker filters unmodified (this is particularly relevant to gravel), but future features will address that.
-Added Bat Wings as a new bat drop to further incentivize batting bats while exploring bat caves.  Note that Bat Wings may be used as bat bait for Hardcore Fishing.
-Added Cut Scoured Leather.  This is simply for convenience, to allow leather to be cut before being Scoured in a Mill Stone, and then Tanned, so that players don't have to worry about cutting excessive leather or what have you, then not being able to tan it as a result.  Note that tanning Cut Scoured Leather, will require two pieces per Dung, plus the corresponding number of logs.
-Changed fishing rod recipe so that it consists of two sticks diagonally, with 2 string, and an iron nugget.  In relation to the vanilla recipe this means the top stick is replaced by a string, and the bottom string by the nugget.  I've also added the ability to melt down the various types of fishing rod (regular, baited, and carrot on stick) in the Crucible to recover the nugget.
-Changed (rebalanced) the hardness of various vanilla blocks so that they make more sense relative to each other.
-Changed (increased) the amount of time it takes to harvest blocks "by hand" when an appropriate tool is not used to further emphasize the advantages of proper tool use.
-Changed the crafting table so that it may not be used if it has a solid block above it, similar to chests and other similar blocks.
-Fixed vanilla problem that was introduced back in 1.3 with blocks insta-harvesting under certain circumstances.  This was most noticeable with netherrack and vegetation.
-Fixed vanilla problem where blocks like slabs, or mod blocks like moulding, would change orientation immediately after being placed in SMP.
-Fixed problem with the sides of snow on slabs not always displaying correctly.
-Fixed problem with bone meal not immediately appearing on the blocks on which it is placed in SMP.
-Fixed problem with tools not breaking at the correct time in SMP.

Version 4.70

-Added Hardcore Bouncing.  This prevents the player from placing blocks while jumping or while otherwise in the air, in order to reduce the effectiveness of "pillaring" (particularly when creating shelters in the early game), increase the value of stairs and ladders, and in general to promote a little more thought going into support structure when working on construction projects rather than just placing a column of dirt.
-Added Hardcore Protection which is comprised of a number of changes and additions to how armor works in BTW, which are listed individually below.
-Added Wool Armor (it's more like clothing, but offers minimal protection).  It is created with the standard armor recipes using wool blocks.  Like leather armor, it may be dyed various colors.  For now, it is always grey (assuming a mix of colors) when initially created, but I will likely base it on the color of wool used in crafting in a future release.  It is intended to act as an early game source of very low level armor.  Note that you may not make boots out of wool, as those would be socks ;)
-Added Padded Armor.  It is created with the standard vanilla recipes, using Padding.  It is as effective as leather, but has far less durability, and is intended as an early to middle game alternative to leather for those that decide to settle an area and farm rather than live a nomadic lifestyle.  It may also be dyed like leather.  Like with wool, you can not make boots out of Padding.
-Added "legit" Tanned Leather Armor, that may be made with the standard armor crafting recipes using Tanned Leather.  The "Gimp" version still exists, and old sets will retain this appearance, however, those items (and their recipes) are now left as easter eggs.  Tanned Leather armor has the same protection values as regular leather, but twice the durability.
-Added Cut Leather, and Cut Tanned Leather as new items.  They are created by combining leather in the crafting grid with shears, which consumes durability on the shears, but serves to increase the effective amount of leather you have on hand by reducing wastage.  All recipes that use leather may use Cut Leather instead, creating "high efficiency" leather recipes, in a manner similar to what the Saw does for wood.  This both serves to increase the value of shears throughout the game, making them a more integrated part of MC, and reduces the difficulty of acquiring leather since leather armor is now a much more important part of the game.
-Added Diamond Ingots as a new item.  These are created with a diamond and iron ingot along with Creeper Oysters in the crafting grid.  They replace diamonds in all tool, weapon, and armor recipes (other recipes that use diamonds, such as the Lens and enchanting table, remain unchanged).  This is intended to balance the relative value of iron and diamonds in the early game, and lead to diamond tools being more of an "upgrade" to iron rather than an outright replacement.
-Added the ability to melt down diamond tools, weapons, and armor in the Crucible in order to recover the iron used in their creation (the diamonds themselves are lost).
-Added internal hooks so that add-on authors can create their own custom armor, and have it display on players and mobs with minimal effort.
-Added internal hooks so that add-on authors can have items either not be consumed or get damaged during the crafting process.
-Changed the Breeding Harness recipe to be 5 Tanned Leather in a "plus sign", with Straps at each corner, since the "Gimp" version of Tanned Leather armor is no longer considered a part of the main tech tree.
-Changed the recipe for Straps so that they are created by combining Cut Tanned Leather with shears in the crafting grid.
-Changed the recipe for Tanning Leather so that it requires Scoured Leather, Dung, AND a number of logs (for Tannin).  The number of logs required is dependent on the species of tree, with the requirements left for the player to discover (even more Hardcore Wood!).
-Changed (further nerfed) the efficiency of stone tools on blocks to further encourage the upgrade to iron.
-Changed (greatly nerfed) the durability of wood and stone picks (this doesn't affect the other tool types of the same material) to further emphasize the advantages of upgrading to better ones, and to hopefully make branch mining with stone picks far less feasible to further encourage collection of iron in the early game through cave exploration rather than mining.
-Changed (optimized) the number of polygons that are rendered for snow, which should aid performance in taiga biomes.
-Fixed problem with picks not being efficient vs silverfish blocks.
-Fixed vanilla problem with the particles for block breaking effects rendering behind the cracks on the block itself.  It was too annoying to leave as is.
-Fixed vanilla problem where tools would break at -1 damage instead of zero.
-Fixed problem with the Lens inventory render sometimes changing shape based on activity with other blocks.
-Removed the high efficiency book and item frame recipes using Tanned Leather, as that functionality is now replaced more elegantly by Cut Leather.

Version 4.69

-Changed (further optimized) how grass blocks render.
-Changed (further optimized) how the full blocks that comprise most of the world (like stone and dirt) are rendered.
-Changed (optimized) the way most blocks determine if a particular side should be rendered or not.
-Changed (optimized) the way Groth renders to cut down on the total number of polygons involved.
-Changed picks to be effective on beacons and Light Blocks.
-Fixed problem with how water flow was computed in the last release.
-Fixed problem with the rendering of Vine Traps.
-Fixed problem with grass blocks not changing their side texture to the snowy one if they had both a vegetation block (tall grass etc.) and snow on top.
-Removed 3D anaglyph mode from most blocks as it was over-complicating further optimization.  Sorry guys, but it was largely useless/headache inducing anyways, and never worked quite right to begin with.

Version 4.68

-Added Hardcore Performance Enhancement to the mod, which is made up of several optimizations to how Minecraft works that are listed individually below.  Note that these are particularly targeted towards low end systems and the stutter which tends to occur on chunk load for some.  If you're already running at a decent frame-rate, you're unlikely to see significant improvements, but on low end systems the difference should be notable.  I will likely continue to add further such optimizations to the mod in the future, as time allows, so this should be considered a first pass.
-Added hooks to the pathfinding code so that add-on authors can specify pathing weight values for custom blocks.
-Added light value to redstone blocks for the sake of consistency.
-Changed (optimized) block rendering in general.  Note that this impacts add-on authors as I've replaced the Modloader method of registering custom block renderers with my own system.  Further details on this can be found on the BTW forums, in the add-on sub-forum.
-Changed (optimized) block rendering so that grass and regular block renders are special cased and handled separately.
-Changed (optimized) the way fluids render and update.
-Changed (optimized) the way mob pathfinding works.
-Changed (optimized) the way the Detector Block and Lens work internally to decrease the number of client/server messages they generate.
-Changed Minecraft's sound system so that sounds that move outside of audible range automatically stop playing.  This was done as a workaround to an outstanding vanilla bug that was responsible for a lot of the stutter that occurs when numerous sounds are playing, and was particularly noticeable as the primary source of framerate stutter when in the nether.
-Fixed problem with the Mill Stone sometimes not changing its sound state based on its contents.
-Fixed problem with the Block Dispenser not being able to combine clay and snow balls into blocks.
-Fixed problem with player names still getting displayed when players are crouching with Hardcore Player Names enabled.
-Fixed problem with string instantly popping off when placed on a Stake.
-Fixed problem with powered and detector rails popping off of moving Platforms.
-Fixed problem with Hardcore Spawn being centered around 0,0 rather than the actual original spawn.
-Fixed problem with Boats and Minecarts falling through upwards facing Block Dispensers.
-Fixed problem with not being able to place the mod's mushroom items in flower pots, and pots containing mushrooms dropping the old mushroom blocks.
-Fixed problem with the Block Dispenser not being able to place brewing stands.
-Fixed problem with the spider targetting code where they would occasionally aim for portions of the target's body to which they didn't have a clear line of sight.
-Fixed problem with snow resting in the same block as tall grass, flowers, and other similar blocks, appearing on top of any blocks placed in the same area it occupies.
-Fixed a few visual glitches when snow rests on slabs or other partial blocks.
-Fixed problem with the Hibachi not relighting automatically if the flame above it was extinguished.
-Fixed problem with blocks occasionally triggering oddly when rotated on Turntables with a redstone torch attached.

Version 4.67

-Changed (reduced) the speed of the Axle animation to make the motion look less modern, and more fitting with the mod. Also refined the texture to provide smoother animation.
-Changed shears so that they are damaged when trimming mooshrooms, and play the snip sound.
-Fixed problem with Cooked Wolf Chops having the same properties as raw ones.
-Fixed problem with dispensers not always rotating properly on the Turntable.
-Fixed problem with Pedestals not transmitting rotation to any attached objects (like torches) when rotated on a Turntable.
-Fixed problem with mod armors not displaying correctly when worn by mobs.
-Fixed problem with Buddy not updating his textures properly.
-Fixed problem with repeaters placed by the Block Dispenser not updating their power state immediately.
-Fixed problem with Lens beams not always updating properly when an obstructing block was removed.
-Fixed problem with axes being efficient on stone slabs (and ones with stone-like materials).
-Fixed problem with villagers offering trades that were impossible to complete due to the new stack limits on food.
-Removed villagers offering to buy rotten flesh as a trade.  What the heck were they doing with it anyways?

Version 4.66

-Updated the mod to version 1.5.1 of Minecraft.  Note that as part of this process, I ripped out almost all the new features that Mojang added as most of them serve to imbalance, are primarily useful only for their exploits, and/or don't fit well with BTW.  *Some* of that functionality may be reactivated in future releases, but I want to give myself proper time to consider each individual feature and its impact on the game before making them a part of BTW, instead of rushing those decisions as part of the update process.  My apologies, but vanilla design has gotten so substandard/random/absent that I am no longer comfortable just integrating anything new they put in by default, as it risks severely degrading the quality of the mod.  From this point forward I intend to hold vanilla features to the same design standards that I apply when adding new features to BTW (in other words, if I wouldn't want to add it to the game myself, I won't include it in BTW), and will  be referring to BTW as a "total conversion" (instead of a "mod") to reflect that.  The one exception I'll be making to this is features that affect world generation (like nether quartz), as I don't want to leave holes in people's worlds by disabling them.
-Added Crucible recipe where two trip wire hooks can be melted down into 1 iron ingot.
-Added high efficiency recipe for the Turntable using smoothstone siding instead of blocks.
-Added "on" textures for both wood and obsidian detector rails, to match the vanilla stone one.
-Added crafting recipe to convert web blocks into string.
-Changed the flint block to use the vanilla bedrock texture, as was originally intended.
-Changed nether quartz to better fit with BTW and the nether.
-Changed the clock, redstone repeater, and Turntable recipes to all use nether quartz instead of redstone dust.  Otherwise, the recipes remain unchanged.
-Changed picks to be effective versus Hand Cranks, levers, glass, glass panes, stone buttons, pistons, and glowstone.
-Changed axes to be effective versus wood buttons and ladders.
-Changed shears to be effective versus wool and leaf blocks.
-Changed the drops on boats when they are destroyed to better match the high efficiency recipe.
-Fixed problem with filled buckets and maps returning iron ingots when melted in a Crucible, instead of iron nuggets.
-Fixed problem with lit Mining Charges sometimes visually disappearing before they exploded.
-Fixed problem with the player moving excessively slow from side to side while climbing vines.
-Fixed vanilla problem where torches couldn't stick to the sides of redstone blocks.
-Fixed vanilla issue that was causing rendering glitches on lit TNT/Powder Kegs.
-Removed the string drop when you destroy a web with a sword.  Axes and swords are still efficient at cutting through webs, but if you want the string from them, you'll need to harvest with shears, then use the above listed crafting recipe to convert it to string.  Note that this makes shears an effective way of gaining access to string with which to make a bow in the early game.
-Removed vanilla method of repairing items through combining two of them in the crafting grid.  It was nigh useless in general play, never made a whole lot of sense, and was creating exploits involving wither skeletons and stone swords.
-Removed the mod's automatic disabling of spawn protection with Hardcore Spawn enabled, since vanilla allows server operators to turn that off themselves now.
-Removed the mod's "reliable block update" functionality, as this now seems to be provided by vanilla.
-Removed BTW's code for preventing compasses and sundials from displaying correct information in the stats page due to the code for them changing completely.  I'll reimplement that feature in a future release.
-Removed the Stoked Fire custom texture as the new vanilla system no longer supports procedural textures.  For now I'm just using the regular fire texture once again, but will create a new custom texture for a future release.
-Removed the dispenser's ability to place minecarts and boats as that functionality better suits the Block Dispenser.
-Removed the dispenser's ability to place and remove water or lava buckets, even when HC Buckets is turned off.  This functionality simply does not suit the block.
-Removed all the fetid and lingering remnants of the horrid monstrosity that is the Forge from the mod as part of the update to 1.5.1, since all the functionality I was still using is now provided by vanilla.  Huzah! :)

Version 4.65

-Added "partially abandoned" villages to the mod.  These exist on the border zone between abandoned villages and normal ones, in terms of distance from spawn.  This is largely an aesthetic change, and helps smooth the transition from one type to the other, but otherwise doesn't really impact the game in a way that should motivate people to start a new world or what have you.
-Added Hardcore Wood, which assigns different burn times to different wood types in the furnace.  The value of the different wood types is left to the player to discover.
-Added recipe to convert clay blocks to clay balls in the crafting grid instead of having to place and break them.
-Added sounds to the furnace when it is lit for greater ambiance.
-Added weeding as part of the overall farming experience.  Yeah...I'll let you figure that one out on your own ;)
-Changed (rebalanced) the relative value of wood & stone vs iron tools to make the gap in terms of effectiveness *much* wider.  This is intended to make the upgrade to iron a much larger jump, and thus far more rewarding than it previously was.  Generally, the nature of these changes are along the lines of a severe nerf to wood & stone (which also introduces further challenge into the early game), and durability increases to iron tools so that they'll last you longer once you obtain them.
-Changed the way blocks are harvested so that not using the appropriate tool on a material will always take a rather long time (similar to how it does when you break stone with your fist), regardless of whether you still get the result in the end.  For example, it will take much longer to break logs or dig dirt with your hands, although you will still get the wood or dirt in the end.  This greatly increases the value of axes and shovels in particular, which were both rather underused tools, as well as making things a tad more challenging in the early game, and also has a number of interesting consequences throughout play such as spider webs being extremely difficult to break and thus escape unless you have a blade.  If there are any blocks that feel like they don't have an appropriate tool assigned to them, please let me know, as this was a rather major change and it's entirely possible I missed a few.
-Changed the name of firework rockets to better reflect their functionality.
-Changed axes to be effective when used on leaves and vines, which makes them a much quicker way to clear them.  This also makes them a rather effective "machete" when attempting to navigate jungles.  Also made them effective vs webs, operating under the assumption that it takes a blade of some form to hack through them, as well as cactus and wool.  Basically, if you used to break it with your hands, and it's become a pain to do so...try using an axe ;)
-Changed the furnace to burn twice as long with the same amount of fuel, and to take twice as look to cook an item.  This leaves the amount of total fuel required to cook an object unchanged (example: coal will still cook eight items), but makes the furnace a more viable emergency light source for the early game if you've yet to find any coal.
-Changed the furnace to burn fuel regardless of whether there are any items to cook in its inventory, for the same reason as above.  This also makes furnace management more interesting in terms of avoiding wasting fuel, and furnaces automatically going out when they no longer have stuff to cook always felt rather meta-gamey anyways.
-Changed the Nethercoal recipe to produce 4 units instead of 2, and cut its burn time to half what it was in the furnace.  This makes it much more efficient for use in crafting torches, while leaving total furnace output unchanged.
-Changed furnace burn times on various blocks and items so that they relate better to each other, and to correct exploits.  This mostly affects wood in particular, given it's now the furnace fuel of choice since the changes to coal, but I've also tweaked burn times pretty much across the board so that they make a bit more sense relative to each other.
-Changed things internally so that furnace burn times set by mods will override those set by vanilla.  I mention this in case add-on authors can also make use of it.
-Changed fishing to make it more time consuming for balance compared to other food sources.
-Changed melon and pumpkin stems to not drop seeds when they are harvested to prevent exploits.  Seeds can only be obtained from the melons and pumpkins themselves.  If you kill the plant before it produces fruit, well...tough luck :)
-Changed (reduced) the rate at which grass spreads to encourage larger pastures for your grazing animals (cows & sheep).  This may also help performance on lower end systems as there is a *lot* of grass in the world, and it constantly makes these kinds of checks for growth, even when it's not possible.
-Changed the bucket recipe to use 7 iron nuggets in a 'U' pattern, instead of 3 iron ingots, to better balance it for the recent changes to iron.
-Changed the sound on webs to be squishier.
-Changed (tweaked) mob and animal AI a bit in ways you will likely not even notice, for a bit of subtle refinement to their behavior.  I just mention it in case any odd or buggy behavior shows up as a result, in which case you should let me know.
-Removed the ability to craft wood and stone swords from the game.  Note that the wood picks and shovels make for passable clubs (I've boosted the damage on the wood shovel to be the same as a pick), and the stone axe is an incrementally better weapon than the wood tools, creating a smoother progression curve to the early game, and providing a much greater reward for making iron swords, especially since you gain the ability to block with them.
-Removed the ability to craft the wood axe from the game, for the same reasons as above, and because it never made a whole lot of sense anyways.
-Removed the ability to craft wood and stone hoes from the game, which results in the player having to work their way up to the ability to farm crops in the early game.  It also makes hoes and expanding your farms a more significant investment and part of the game overall, as there was never any real reason to use anything other than a stone hoe in the past.  In an abstract sense, this also serves as an analogy for the player moving out of the hunter/gatherer "stone age", beginning to be able to farm crops, and being able to settle a location in a more permanent manner.
-Removed some lingering vanilla code that was causing some mobs to still stop wandering with distance from the player.
-Fixed problem with mushrooms cooking forever in the Cauldron in the presence of Dung.
-Fixed problem with books being enchantable.

Version 4.64

Note: This release appears to contain changes to world generation, contrary to my normal policy, but it should be noted that anything I have done here has none of the negative impacts normally associated with such changes: it will not cause unsightly seams in your world, nor place a whack of mod blocks into your world that will leave gaping holes should you uninstall the mod.  Everything I have done here has been done with extreme caution and moderation so as not to mess with your worlds, and that is a policy you can expect me to continue to maintain in the future.

-Added "abandoned villages" to the mod.  Villages within a certain radius of the player's spawn location will be abandoned, which resolves a number of balance issues in the early game when the player happens to spawn near a village.
-Added the ability for cows and mooshrooms to eat mycelium (as well as grass), and changed cows so that this is what triggers their transformation into mooshrooms, instead of just standing on it.
-Added the ability for Mooshrooms to spread mycelium to nearby dirt blocks.  In combination with the above, this subtly changes mycelium to be an infectious organism that uses cows and their eating habits in order to spread and reproduce, rather than just kinda sitting there :)
-Added a correlation between the drop rate of Mystery Meat and accumulated cellulite.
-Changed how which crops appear in which villages is determined.  Most will only contain wheat, with a few containing wheat & potatoes OR carrots (never both).  Along with abandoned villages this makes finding every crop in the game a much longer process, and helps smooth out the early game progression with Hardcore Hunger as you don't get every single crop upon finding a single village.  Note that which crops appear in which villages is not dependent on the world seed, and thus *may* vary even when using the same seed from world to world.
-Changed desert temples to have obsidian detailing rather than wool, as wool being used as a construction material in these kind of structures is an immersion breaker.  This was also done as a first pass test of my techniques to modifying world gen, to make sure it didn't have unanticipated consequences.
-Changed desert temples in one other subtle way that I'll leave to the player to discover ;)
-Changed the "tables" in villages to be Oak Wood Tables from the mod, to prevent another immersion breaker where either you or villagers jump on a table and cause an annoying clicking sound.  Obviously, these will get deleted if the mod is uninstalled from a world, but I sincerely doubt a few missing tables would be of offense to anyone.
-Changed village lamp posts to use a dark (spruce) wood block or sandstone (for desert villages) instead of cloth, for the same reasons as above.
-Changed the torch recipe to only produce one torch instead of 4, to help increase the value of coal (it is a vastly overabundant resource) and wood overall (particularly in the early game), and because it corresponds better to the recipe for redstone torches as well.  This also serves to increase the value of tree farms in the late game, and the use of the Saw to gain access to high efficiency recipes, as well as to encourage the player to consider torch placement a little more instead of just spamming them to light up an area.  Additionally, this increases the value of Nethercoal in the middle game.
-Changed a little something something in a way that will be left for players to discover.
-Changed mob spawners so that they won't spawn creatures wearing armor or with other equipment (skeletons still spawn with non-magical bows), thus eliminating the iron output of them.  This is to discourage their use in mob traps (since spawner traps are lame due to their AFK dependency), and further promotes the construction of full blown mob-traps.
-Changed (slowed) the growth rate of melons and pumpkins substantially to help further balance them as food sources.
-Changed ladders and other climbable blocks (like Ropes and vines) so that they may not be climbed if you are crippled, and so that other movement status penalties are also applied.
-Fixed problem with not being able to sprint at 5 hunger pips, instead of 4 (when 'Peckish' is first displayed).
-Fixed slight golden tinge in the Iron Nugget texture.
-Fixed vanilla problem where torches on village lamp-posts would be floating in mid air instead of attached to the lamp post itself.  Obviously, this only affects newly generated villages.
-Fixed problem with particles not displaying when cows converted to mooshrooms.
-Fixed texture-offset problem with distended cow udders.
-Fixed problem with wolves being able to eat Cooked Carrots and Chowder.
-Removed the ability to "cook" logs into charcoal in the furnace.  It must now be done in the Kiln.  This was done to help increase the value of coal in the early game (for all the reasons stated in the torch recipe change above), while not adversely affecting late game automated systems.  It also serves to increase the value of Kilns and particularly auto-Kilns in the late game.
-Removed the coal drop from wither skeletons to further promote the use of Kilns in the late game as a source of charcoal.  It never fit particularly well with them anyways.

Version 4.62

-Added the Iron Nugget as a new item.  It is created by smelting iron ore (which produces a nugget instead of an ingot) or by dropping an iron ingot into the crafting grid.  They may be crafted into iron ingots with 9 in the crafting grid (same as gold nuggets).  This corrects an imbalance with iron by *greatly* increasing the difficulty of acquiring iron tools and armor in the early game (it was trivially easy before), gives purpose to leather armor, increases the value of mob traps in the late game, increases the value of tools looted off of mobs, increases the demand for coal as a resource, increases the value of trading with villagers, and generally helps spread out the early game vanilla tech tree in interesting and challenging ways that mesh well with Hardcore Hunger.  
-Added Hardcore Armor to the mod.  This extends some of the concepts previously just applied to Soulforged Steel armor to other armors in the game.  Basically, the way it works is that every ingot (iron, gold, or Soulforged Steel) or diamond used in the crafting of armor, adds to its weight (leather armor has no such penalty).  For every unit of weight in armor your character is wearing, you gain fatigue more quickly (thus requiring more food).  If you have 10 units of weight or higher on, then you will also sink in water.  This does a number of things to the game, primarily related to leather armor.  First, it makes leather armor more valuable throughout the game, especially for long journeys, when running low on food, or when traveling over water.  Secondly, it promotes mixing and matching of armor sets instead of just wearing uniform sets of whatever happens to be "best" for the stage of the game you're in.  Lastly, it further increases the danger of combat, since it makes it less likely overall that the player will be well armored at any given time, unless they've specifically prepared for it.  Note that while chain armor provides only slightly less protection than iron armor, it has half as much "weight" (rounded up), thus making it rather valuable if you get your hands on some, increasing the value of villager trades in the early game.  The short version of Hardcore Armor is that if you wear a lot of heavy armor, you'll get hungry faster and sink in water ;)
-Added Mail as a new item.  It is crafted with 8 iron nuggets in a "checkerboard" pattern on the Anvil, and may then be used to create chain mail armor using the standard vanilla armor recipes.  It is intended as a late-game lightweight version of iron armor for situations where iron or Soulforged Steel may be impractical.
-Added a high efficiency boat recipe using Wood Siding instead of wood blocks.
-Added the Mushroom Omelet in both raw and cooked states as a new food item.  It is created by combining a Raw Egg and a brown mushroom in the crafting grid, and then cooking the result.  It is intended as an early game food source that can be farmed before finding a village, and prepared without a Cauldron.
-Added Scrambled Eggs in both raw and cooked states as a new food item.  They're created by combining a Raw Egg, a bucket of milk, and a bowl in the crafting grid, and then cooking the result.  It serves a similar role to the Mushroom omelet in terms of early gameplay.
-Added Mystery Meat in both raw and cooked states to act as an emergency food source, and added the ability to make Tasty Sandwiches and Hearty Stew out of it.  A Steve's gotta do...
-Added Hardcore Lactation to the mod.  This involves several changes to cows and milk production.  First, a small food value has been added to drinking a bucket of milk to provide an early game renewable food source.  Secondly, cows need to be able to eat grass in order to produce milk (similar to sheep for wool production), and will only do so periodically.  Lastly, whether or not a cow can be milked will be visually indicated by the size of its udder, and both particles and sounds have been added to the milking process for greater player immersion.  Also note that the above changes apply to mooshrooms and the production of mushroom stew (Cream of Mushroom), so you can no longer just get infinite bowls of it from them with no effort or delay. In combination with some of the new food recipes in this release, these changes make milk, and the tending of dairy animals, a more important and useful part of the early game.
-Added the ability to get cows and sheep to follow you by holding tall grass.  You can't breed them through this method, but it's enough to trick them into  following, which aids in penning them in the early game.  Pigs don't believe it for a minute though.
-Changed mushroom stew to "Cream of Mushroom".  It is made by combining brown mushrooms, and a bucket of milk with a bowl in the Cauldron.  It is also meant as an early game food source from ingredients that can be farmed before finding a village, as well as taking care of a recipe conflict between mushroom and Hearty Stew.  Also adjusted the hunger values on it to match its new role and ingredients.  As a bonus, it fits rather well with it being produced by mooshrooms :)
-Changed Fish Soup to "Chowder" for the same reasons as above.  It is made with fish, a bucket of milk, and a bowl in a Cauldron.
-Changed the Kebab to use brown mushrooms instead of potatoes in its recipe.  It is now made with brown mushrooms, carrots, and mutton, combined with a stick in the crafting grid.  It is intended as a middle-game food source for people that find carrots but not potatoes (much like Steak and Potatoes operates for potatoes).
-Changed the hunger status penalties to kick in slightly later than they did previously, in order to create a wider "buffer zone" between fat penalties and hunger penalties to further encourage keeping a store of fat on you for emergency use...without going overboard and riding pigs around :)
-Changed the dizziness/nausea effect from hunger to only kick in when the player is actually starving to death (losing health), as it was going on way too long before.
-Changed (increased) the durability of leather armor to make it a more practical option.
-Changed (increased) the durability of iron (and chain to match) armor given it is now much harder to come by.
-Changed (tweaked) the durability of Tanned Leather Armor to have a more direct correlation to that of leather armor.  Tanned Leather Armor offers the same protection as regular, but has superior durability, and will thus last longer.  Further refinements to this armor type will be made in an upcoming release, to make it more of a practical, and less of a "gag" item given that leather armor in general is no longer useless.
-Changed the way chain mail looks on your character in game, as frankly, it looked like total ass, and if it's going to see increased usage due to the other changes in this release, that was no longer reasonable.
-Changed the recipe for the compass to use 4 Iron Nuggets instead of ingots, to better match the changes to iron, especially in consideration of the impact they have on Hardcore Spawning.
-Changed the recipe for the clock to use 4 gold nuggets instead of ingots, to match the changes to the compass, and to promote the use of a small utility item created with an otherwise valuable resource.
-Changed mushrooms so that they don't turn to Foul Food when placed in a Cauldron with Dung. This is to correct a problem that prevented the creation of Nether Groth, and also makes some sense given mushrooms tend not to be adversely affected by the presence of poo.
-Changed the flint & steel recipe to use an iron nugget instead of an ingot, and made it shapeless.
-Changed (reduced) the rate at which you lose hunger with time slightly, to further balance Hardcore Hunger.
-Changed (reduced) the rate at which you lose hunger while pulling a Hand Crank slightly.
-Changed (refactored) the way a few things work internally to reduce the number of individual changes the mod needs to make to the item class.  I just mention this in case any problems result.
-Changed the fermented spider eye recipe to use red mushrooms instead of brown, to better fit the new roles of the two mushroom types.  Also fixed a problem with the previous release where they couldn't be crafted at all.
-Changed Silverfish so they only drop arcane scrolls in the end dimension.  This is to further discourage farming them from the single spawner in each stronghold, and also fits better with the differences in their behavior between dimensions.
-Fixed problem with Hearty Stew not working with pork, mutton, or wolf as an ingredient.  It was previously only working with beef.
-Fixed problem with the cake recipe using a regular vanilla egg instead of a Raw Egg.
-Fixed problem with soup bowls disappearing if the player consumed soup or stew and their inventory was full.
-Fixed same problem for potions and glass bottles.
-Fixed problem with hunger still draining with time in creative mode.
-Removed ability to get milk from mooshrooms using a bucket.  They only produce Cream of Mushroom now.
-Removed easter-egg head drops from pigs.  Sorry guys, but that gag had run its course ;)

Version 4.61

Note: There was an error in the previous change log that specified mushrooms as part of the recipe for Kebabs.  The actual recipe is mutton, carrots, potatoes, and a stick, with no mushrooms involved.  

-Changed the order in which carrots are cooked in the Cauldron so that they cook up *before* any soup or stew recipes are created to prevent ordering problems between mushroom and Hearty Stew.
-Changed melons and pumpkins to only stack up to 16, to prevent them becoming hyper-efficient transportable food sources.
-Changed "Food Poisoning" (a.k.a the "Hunger" effect) so that you can't eat while suffering from it.  This is to prevent exploits involving eating a whole bunch of potentially poisonous food at once so that you are only affected by it once.
-Fixed problem with the Hearty Stew, mushroom stew, and Groth recipes using the *old* mushroom items instead of the new.  This basically made these items impossible to craft unless you had old mushrooms laying about.  Also note that Hearty Stew requires *brown* mushrooms, not just any mushroom as stated in the previous release notes.  This problem was the main reason behind this small release.
-Fixed problem with raw carrots having a higher food value than intended.
-Fixed problem with mushrooms being able to be placed and grow in any light level.

Version 4.60

Note: This release is for version 1.4.7 of Minecraft NOT 1.5.  Don't even ask if it works with 1.5.

-Added Hardcore Hunger to the mod.  This rebalances many aspects of how food and hunger work in Minecraft to make it a more crucial aspect of gameplay.  Because this change is rather extensive, the individual changes that comprise it will be listed independently below.  Please keep in mind that this feature will likely be further balanced over time based on additional play testing, given that its impact on play is rather subtle, substantial, and far reaching.  Desserts in particular will receive additional attention in the near future, specifically their recipes, with this release mainly focusing on staple foods.  The number of changes in this release may be daunting, but give it a try and it will hopefully all make sense :)
-Added the concept of "fat" which replaces saturation as hunger's secondary value.  Fat is only built up when you eat food in excess of what is required to fill your hunger meter, OR when you eat deserts when you are already full.  Having some fat is useful, as it effectively increases the amount of time you can go without starving.  However, having too much fat will result in penalties.  Also, unlike saturation, fat only burns off *after* your hunger goes below your fat level, thus it functions as a backup store rather than as just an outright bonus to hunger.  Right now, being fat doesn't affect Steve's visual appearance, but I may add that in the future.
-Added visible display of fat to the hunger meter so players can better manage their overall hunger state and fat levels.  Saturation being an invisible value just sucked.
-Added a number of new "complex recipes" to the mod, which will be listed as individual changes following this.  As a general rule, recipes that require more than 1 ingredient will restore more hunger and are also a more efficient use of the food you have on hand (most produce multiple portions).  Also, "dessert" (cake, pie, cookies, etc.) items tend to have very high fat gain, but very low hunger restoration, making them useful for when you want to put on fat.  Unlike regular food, desserts are also edible when your hunger meter is full.
-Added the Cooked Carrot as a new food item.  It is made by....cooking a carrot :)
-Added the Tasty Sandwich as a new food item.  It is made by combining cooked meat or fish with bread in the crafting grid. 
-Added Steak And Potatoes as a new food item.  It is created by combining cooked steak and cooked potatoes in the crafting grid.
-Added Ham And Eggs as a new food item.  It is created by combining cooked pork and a cooked egg.
-Added Steak Dinner, Pork Dinner, and Wolf Dinner as new food items.  They are created by combining cooked meat of the corresponding type along with cooked carrots and potatoes.
-Added the Kebab as a new food item.  It is created by combining raw Mutton, carrots, and potatoes in the crafting grid with a stick, then cooking the result.
-Added Chicken and Fish Soups as a new food items.  They are crafted by cooking chicken or fish, along with carrots, and potatoes in the Cauldron, with at least 3 bowls for the individual servings).  Note that with all soups and stews, you can use either the raw ingredients or the cooked ones, but anything you dump in raw will have to cook first before the soup itself is made.
-Added Hearty Stew as a new top-tier food item (it's the most efficient source of food currently in the game).  It is created by cooking either raw steak, pork, mutton, or wolf, along with carrots, potatoes, brown mushrooms, and flour in the Cauldron, with 5 bowls for the individual servings.
-Added recipe to convert baked potatoes into boiled potatoes in the Cauldron.  This simplifies many of the soup/stew recipes above, as it means if you dump a bunch of baked potatoes into a Cauldron trying to make soup, they will first convert, then apply to the soup recipe.
-Added high efficiency bowl recipe consisting of 3 wood Siding in a V pattern.
-Added effects from low hunger, health, and excessive fat such as movement, mining speed, and attack penalties, along with a few that are left to the player to discover.  As a general rule, all penalties (starting with the loss of the ability to sprint and/or heal) start to kick in when the relevant meter is around the half-way mark, so if you keep them above (or below in the case of fat) that point, you will be entirely free of detrimental effects.  A short text description of the most severe effect you are currently experiencing is displayed above the hunger meter to provide further feedback.
-Added potential food poisoning effects to all raw meats, fish, and eggs to further emphasize the importance of cooking food.
-Added the ability to eat pumpkin seeds, because coming across a pumpkin while starving to death and not being able to eat it sucks ;)
-Added the ability to eat raw mushrooms for the same reason.  This unfortunately required a new item internally, so the old ones are labeled as "Old Mushrooms", and are not edible, but may be converted to the new ones just by dropping them into the crafting grid.
-Added the ability for mushrooms to grow on any block with a solid top surface, not just fully opaque cubes.  This means they can now grow on stuff like upside down slabs and Tables.
-Changed hunger to decrease slowly with time, regardless of whether you are doing anything or not, which discourages AFK play (Steve will die if you leave him unattended for too long).  Extra hunger on top of this is still drained based on your activities.
-Changed hunger so that it now applies consistently across difficulty levels, and will cause you to starve to death regardless of the setting to discourage switching difficulty to avoid its effects.  The only difficulty this does not apply to is peaceful, given its limited value in AFK play.
-Changed (reduced) stack limits on all food items to 16 to make the quality of food you are carrying more significant.  Note that this will not affect existing stacks, so all your items are safe, but any newly created stacks will be limited to 16.  This also includes increasing the stack limit of mushroom stew to 16, so it is now stackable like other food items.
-Changed (tweaked) the values on most existing food items to generally make them less effective.  
-Changed Donuts so that they require both Flour and sugar to cook in the Cauldron.
-Changed the mushroom stew recipe to require a brown mushroom, and flour in a Cauldron with 2 bowls for the individual servings.
-Changed the pumpkin pie recipe to require a pumpkin, sugar, a Raw Egg, and Flour.
-Changed (reduced) the growth rate on edible vanilla crops as part of Hardcore Hunger, and to both encourage larger farms, and the use of bone meal as a fertilizer.  This also serves to balance them more relative to each other, with, for example, potatoes and carrots taking longer to mature than wheat.
-Changed (reduced) the number of "seed" items that crops drop to make creating a large farm a more significant long-term effort, to reduce the number of excess seeds in the game, and to give melons a more clearly defined role in producing seeds for chicken feed.
-Changed (greatly reduced) the rate at which the player heals to increase overall level of challenge, the importance of staying fed under Hardcore Hunger, and to give an actual purpose to healing items & potions.
-Changed the way Minecraft works internally so that blocks with different subtypes can play different step sounds per subtype.  At present this change only affects dirt and Packed Earth slabs, but will likely be used for other blocks as well in the future.
-Changed Dung blocks so that they are part of aesthetic earth blocks, which allows them to behave in a manner more consistent with their material type.  This necessitates a conversion for previously existing Dung blocks, which will now be labeled as "Old Dung", and may be performed by just dropping them in the crafting grid.  Note that this change will affect Dung beacons, which will no longer function with the old blocks.
-Changed the Wood Blade (used in making Water Wheels) to have a max stack size of 1, to suit its bulky nature.  Similar to the food stack change above, this will not affect existing stacks.
-Changed the amount of hunger you need in order to be able to heal, to be a bit more forgiving, given that managing your hunger is now a larger challenge overall, that it now takes place at a slower pace, and so that it's more obvious when it happens.  You now lose the ability to heal when described as "Peckish", which is the first detrimental hunger effect.
-Fixed vanilla issue where you could silk touch harvest *lit* redstone lamps, as that problem was also extending to the Block Dispenser.
-Fixed vanilla issue where you could still feed animals their breeding item (e.g. wheat) when they were already in love mode by right clicking on them ("player choice" my hindquarters).
-Fixed vanilla issue where mushrooms appeared so visually low in your inventory that they were covered by the stack count and became hard to identify as a result.
-Removed the apple drop on oak leaves.  I have additional plans for apples for a future release, but for now, I wanted to remove them as an easy food source from performing unrelated activities (like chopping wood) to fit with Hardcore Hunger.  The apple drop always just felt rather weird anyways, in a "oh look...random food in my inventory from nowhere" kinda way.
-Removed wheat seed drop from tall grass.  Domesticated crops like wheat, potatoes, and carrots, must now all be obtained through finding a village.
-Removed melon slice to melon block recipe so that they can't be compacted into an easy to transport food source without the use of a silk-touch enchant.

Version 4.59

-Added the ability for snow to accumulate around tall grass, flowers, saplings, and other similar forms of vegetation, to provide a more uniform and aesthetically pleasing distribution.  Note that spruce saplings will grow when covered in snow, but other varieties of tree will not.
-Changed (optimized) the way the ray-tracing vs snow works from the last release, to prevent potential performance issues.
-Fixed problem that was causing add-on authors to have difficulties updating to version 4.58 of BTW.  This change is the primary reason for this release.
-Fixed problem that was causing Hardcore Spawn to cycle through a short list of respawn locations rather than respawning the player at a truly random location.
-Fixed visual glitch where if you destroyed a slab (or other similar block) with snow resting on it, the snow would briefly appear floating above the area it previously occupied.
-Fixed problem with snow not being to accumulate in the space in front of Detector Blocks, or in a Lens beam.

Version 4.58

-Added the beginnings of Hardcore Villagers to the mod.  Note that this is just the start of the changes I will be making to them, but I wanted to get these in now as it establishes a base-line of behavior for them, and these changes may affect existing builds (they eliminate the ability to create automated villager and iron golem farms).  Villagers no longer reproduce on their own, and instead must be given diamonds to cause them to enter love mode (similar to animals with wheat/carrots).  They will also no longer create iron golems on their own, and zombies may no longer be "cured" to turn into villagers.  As such, villagers must be found in order to obtain them, bred to create a population, and the player has a much more vested interest in protecting them from harm.  Future changes will expand upon this behavior in order to make villagers a more interesting part of the game overall.
-Added the ability for snow to accumulate on partial blocks with a solid top surface, like slabs and Siding.  This means the player can no longer avoid snow accumulation by doing stuff like building roads out of slabs, and will also result in more pleasing looking buildings in snow biomes.
-Added textures to Dirt Slabs with grass on them so that they appear with snowy sides when they have snow on top of them, as happens with regular grass blocks.
-Changed blocks rotated by the Turntable, blocks swallowed by the Block Dispenser, and silverfish blocks so that the particles they produce respect the options for number of particles displayed.  This should help performance on low end systems that use these options, in situations where there are a lot of automated systems running.
-Changed the Infernal Enchanter so that it can apply enchantments to tools normally restricted to the vanilla anvil (e.g. unbreaking to a bow, or efficiency to shears).
-Changed the Cauldron and Crucible so that their inventory may not be accessed if the open side is obstructed by a solid block (similar to chests).
-Changed the way gravel behaves when harvested with a fortune enchant so that it no longer ever drops flint.  This behavior fits BTW's ability to filter gravel into sand and flint with the Hopper much better, as just getting flint from a harvest becomes more of a penalty than a bonus.
-Changed the probability of mobs spawning with enchanted equipment to be uniform across difficulty levels to further discourage players changing their difficulty to affect mob trap output.
-Changed (reduced) the frequency that skeletons spawn with enchanted bows as they were outputting at too high a rate in mob traps due to my previous changes to them almost always dropping them on death.
-Fixed problem with the Packed Earth texture that was causing visible seams between blocks.
-Fixed problem with Ender Spectacles and True Sight not functioning with minimal particle settings.  They'll now work, but with a greatly reduced number of particles being displayed.
-Fixed problem with Ender Spectacles and True Sight creating a buildup of particles while the game is paused.
-Fixed problem with the Lens not projecting onto surfaces anymore.  It will now project on *all* solid surfaces neighboring on a beam's end point.
-Removed clay drop from silverfish in the overworld, as it was unfortunately encouraging spawner based traps (which are bad...mkay?).  They will now only drop clay in the end dimension under the assumption that no eating equates to no poop.
-Removed numerical debug display of item damage since this could be considered an exploit under Hardcore Info.
-Removed ability to rotate Siding, Moulding, and Corners by right clicking with an empty hand.  This feature was making the corresponding blocks feel "less solid", was leading to exploits such as creating cheap doors out of siding, and was also leading to excessively easy griefing in SMP.  Since the inclusion of a more refined placement method for these blocks, this feature has also become less significant.  Note that they may still be rotated on the Turntable.
-Removed right-click rotation on Axles for the same reasons as above.  The only mod block that can be rotated in this manner now are Gear Boxes, as it is more of a configuration setting for them than an actual physical rotation.

Version 4.57

-Added Packed Earth as a new block type.  It is created by placing two dirt blocks one on top of the other in the crafting grid (they may be converted back to regular dirt in the crafting grid as well, allowing them to be used for bulk storage), and provides a means of creating dirt paths to be used in conjunction with Hardcore Movement.  This block provides the same movement bonuses as other "man made" blocks, and vegetation will not grow onto it, thus providing additional aesthetic options for road design.  
-Added Packed Earth slabs that may be created by placing two Packed Earth blocks side by side in the crafting grid, to provide further refinement in creating dirt paths.
-Added sources for all the remaining Arcane Scrolls that were missing from the mod.  Happy hunting :)
-Added a new common drop to witches: "Witch Wart".  This item replaces redstone in potion brewing recipes in order to extend the duration of various potions, which gives specific value to finding and farming witches without the balance destroying effects of their previous vanilla drops.  This also serves to make potion brewing more challenging and rewarding.
-Added a new common drop to silverfish to make farming them much more worthwhile.
-Added the ability to use hoes on the block that shall not be named.
-Changed snow so that it can accumulate on any block with a solid top surface, such as upside down slabs and Tables, since snow is now a more significant factor in the construction of roads with the addition of Hardcore Movement to the mod.
-Changed skeletons so that if they're carrying a magical bow, it will drop on death with a much greater frequency than regular bows.  Thus, if you see one holding a magic bow, it's much more worthwhile to kill them to try and get it.
-Changed skeletons in the nether so that they fire infinite arrows, and will not drop Rotted Arrows upon death.
-Changed the Arcane Scrolls drop on Ghasts, and removed the drop from iron golems and villagers.
-Changed (reduced) the rate of spread of silverfish.
-Changed compasses and clocks on the stats page so that they can't be used as a means to get a compass heading or time without actually making the items in question.
-Changed Bloodwood Saplings to apply the movement penalty associated with other vegetation under Hardcore Movement.
-Changed librarian villagers to buy book shelves rather than sell them.
-Fixed problem with fire not rendering properly on top of some mod sub-blocks, like Tables.
-Fixed problem with Night Vision Beacon effect displaying "Night Vision II", even though there's no second level to that effect.
-Fixed problem with Composite Bows producing 2 string when broken down in a Cauldron, even though they are made with just 1.
-Fixed problem with Mouldings sometimes auto-connecting to aesthetic blocks of the same material type (e.g. Columns).
-Fixed problem with wood fences made out of anything other than oak not cutting into Corners with the Saw.
-Fixed problem with not being able to place pressure plates on mod fences.
-Fixed problem with some Arcane Scrolls dropping in creative mode (they aren't supposed to).
-Removed sound associated with entities moving through vine traps as it was resulting in excessive bandwidth consumption in SMP.
-Removed enchanted books from villager trades since they aren't used in the mod.
-Removed particle effects originating from beacon powers as they provided little in the way of information, and got really annoying in bases with beacons in place.  Particles from actual potions will still be displayed.

Version 4.56

-Changed squid so that they won't stop moving when the player is far away.
-Fixed problem where silverfish could rampage out of control and level entire buildings.  My apologies for this one guys.  I sincerely hope they didn't cause too much damage to anyone's world, and this bug fix is the reason for this emergency release.

Version 4.55

-Added Hardcore Movement (movement journal day 5).  This change affects movement speed (for both the player and mobs) on various material types so that building paths and roads becomes an important part of the game.  As a general rule of thumb hard surfaces, or those traditionally used in the making of roads (e.g. cobble, brick, gravel, planks, wool, iron, etc.) increase movement speed, while soft surface (grass, dirt, etc.) leave it unchanged, and materials that you would expect to slow you down (tall grass, snow, crops, Groth, reeds, sand, etc.) do so.  All materials that provide a bonus or penalty do so by an equal amount so as not to discourage construction out of a variety of materials.  It also removes potions of swiftness from the game (the recipe has been removed and existing potions will cease to have any effect) as these significantly decrease the value of both rail networks previous to this change, and to roads with it, and require very little effort on the part of the player to create.  Try it...this changes everything :)
-Added sources for efficiency and respiration Arcane Scrolls.
-Added changes to silverfish to make them a more interesting, useful, dangerous, and a better integrated part of the game.  These are left to the player to discover.
-Added an additional side-effect to one of the beacon types that is left to the player to discover.
-Changed Soulforged Steel blocks to be impervious to wither-based destruction.
-Changed the way animals and plants behave in the end dimension.
-Changed (tweaked) the spawn rate and range of something in relation to something else, and added sounds and particle effects to the same.  I will say no more :)
-Changed (refined) the way the game determines what surface an entity is on.  This should be most noticeable with the step sounds that are played when walking on very thin surfaces like freshly planted Groth, but the change is particular important with Hardcore Movement since the surface you're on is a much more significant factor now.
-Fixed problem with Wind Mills & Water Wheels not rendering when viewed from high above.
-Fixed mod option for skipping the end game text.
-Fixed problem with signs, Vine Traps, and Blood Wood Saplings blocking the Hopper from ejecting items.
-Removed the option for disabling the limiting of squid spawns as their drops are now more important and require a specialized mob trap.

Version 4.54

-Changed the looting beacon effect to apply to *all* deaths within the area of influence, not just ones caused by players.  This means that it will act as a bonus to the output of mob traps and automated animal farms, which makes the related beacon much more desirable overall.
-Changed (loosened) the spawn restrictions for mobs within nether strongholds, which increases the number of wither skeletons, blazes, and magma cubes which will spawn within them significantly.  They can now spawn anywhere within the volume of a nether stronghold, not just around "cross roads", which should be much more intuitive when creating mob traps, and also makes exploring them much more interesting.  This change is the primary reason for this small release, as I know a lot of folks are currently working on their wither skeleton farms to build the various beacons in the mod, and with this change their spawn conditions are much more evident.
-Fixed problem with the True Sight beacon effect only applying if you were wearing a helmet.
-Fixed problem with "ghost items" being created when shift-clicking to the Infernal Enchanter.

Version 4.53

-Added the last (for now anyways) of the new beacon types: obsidian.
-Changed the way Hardcore Chests works to completely rework the behavior of ender chests in the mod, and removed the option for disabling it from the config file.  Don't worry...all your previously stored items are safe (whether you had Hardcore Chests enabled or not), but how to access them is left for you to discover ;)
-Changed the means of obtaining Nether Groth Spores without mycelium slightly, but I don't think anyone has figured out how to do it yet anyways :)
-Changed the way the Block Dispenser "silk touch harvests" blocks it's swallowing to simplify the related code and so that it universally applies to any new blocks that may be added to the game without further changes.  Please let me know if any problems arise as a result.

Version 4.52

-Added Soulforged Steel beacons.
-Added sound effects for when beacons power up and down.
-Added an alternate means of creating Nether Groth Spores that doesn't require mycelium, and which is left to the player to discover.
-Fixed problem with not being able to set a player's spawn location through the command console or command block.
-Fixed problem with compasses not behaving consistently near beacons.
-Fixed problem with torches being able to float in mid-air next to some sub-blocks.
-Fixed problem with upside down wool slabs taking longer to harvest with shears than regular ones.

Version 4.51

-Updated to the latest version of MCP.  This should fix a number of multiplayer issues, and is the primary reason for this release.  Note that it *may* necessitate a clean install of Minecraft and the mod to prevent further issues.
-Added recipes so that books (of all kinds) may be rendered down into Glue, with 2 books being required for 1 Glue.
-Changed Hardcore Spawning so that players leaving the end dimension are always returned to the original spawn point in the overworld.
-Fixed problem with most aesthetic block types responding like Concentrated Hellfire when used as part of a beacon pyramid.
-Fixed constant flashing on night vision beacon effect.
-Fixed vanilla problem where the player would get "caught" on chests when passing beside them, as it was frigging annoying.

Version 4.50

-Added Hardcore Beacons as a new mod feature.  This completely revamps the way vanilla beacons work to make them more difficult to construct, more powerful (as in...not useless), and WAY more interesting overall.  The details of this system are left to the player to discover.  Note that more beacon types are on their way, but the stuff that is in there already is so cool that I wanted to get it out while I work on the rest :)
-Added internal hooks so that add-on authors can create custom beacon types.
-Changed (refactored) the way the mod works internally to reduce the number of base-class modifications made to Tile Entities.  This affects the chest, and mob spawner.
-Fixed vanilla problem where beacon blocks would not drop their inventory if the block is destroyed.
-Fixed problem with shears taking double damage when harvesting webs.

Version 4.42

-Updated the mod to version 1.4.7 of Minecraft.
-Added ability to harvest webs with shears without requiring the silk touch enchant on them.
-Added the ability to render Mutton down into Tallow.
-Added the ability to create sandstone Siding and other sandstone sub-blocks out of all the different sandstone block types.
-Added high efficiency recipes for White Stone, nether brick, brick, and sandstone stairs using Moulding of the corresponding type.
-Changed Hardcore Spawn to be enabled by default.  It can still be disabled through the mod's config file.
-Changed the way the Hibachi determines if blocks above it should be incinerated when it is lit, so that it is a little more consistent and logical.
-Changed Hardcore Buckets so that vanilla dispensers can dispense and retrieve water buckets in the end dimension.
-Changed (refactored) the way the mod's inventory management functions work internally to be much cleaner.  I mention this as it may affect add-on authors.
-Changed the way Hardcore Spawn works to fix problems with spawning in empty space on skyblock style maps.
-Fixed problem with shears taking longer to harvest Wool Slabs than wool blocks.
-Fixed problem with Wicker blocks dropping Soap blocks when cut by the Saw.
-Fixed problem with item stacks only merging with a single partial stack before creating a new stack when added to some mod inventories.
-Fixed problem with item stacks sometimes not merging properly with existing partial stacks when added to a double chest by the Hopper.
-Fixed problem with the way various crops (wheat, potatoes, and carrots) display when growing in a planter.  Previously, they were displaying a bit too low, making it difficult to tell when they were fully grown (carrots in particular).
-Fixed crash bug in SMP when a player has the Anvil GUI open, and another player destroys the Anvil.

Version 4.41

-Updated the mod to version 1.4.6 of Minecraft.
-Added raw and cooked Mutton as new food items, as I got tired of waiting for Mojang to get around to it :)
-Added a "clean" version of the Chopping Block.  When first created, it will be clean, and will become dirty through use. Dirty blocks may also be cleaned by using Soap in a heated Cauldron, with a single bar of Soap cleaning 4 Chopping Blocks.
-Added the ability to grind skeleton skulls into bone meal with the Mill Stone.
-Added internal functionality to differentiate between ice blocks formed out of source water blocks, and those that aren't with Hardcore Buckets enabled.  This means that source ice will turn back into source water when harvested, so that you will no longer get unsightly holes in your frozen lakes when breaking it, and that ice blocks you move yourself will melt into temporary water as they do now.  Note that all ice that was in existence previous to this change is considered to be made of source water, which may result in old manually placed ice blocks turning into source water when broken.
-Added internal functionality so that smooth stone pedestals and oak tables, use the same texture indexes the old blocks of the same type did, so that texture pack artists can keep their old textures for those blocks.  Note that oak benches also use the same textures as oak tables for consistency.
-Added internal functionality so that add-on authors can determine how their blocks function when cut by a Saw.
-Added internal hook to specify the size of the animated Stoked Fire texture, for use by MCPatcher.
-Changed the vanilla bow so that it will fire any Rotted Arrows in your inventory before regular ones, given that Rotted Arrows are less valuable (since they can't be reused) and do the same damage.  Note that this doesn't affect the Composite Bow since it can not effectively fire Rotted Arrows.
-Changed infinity enchanted arrows to shatter on impact, similar to Rotted Arrows.
-Changed the way Hardcore Spawning works so that it functions properly on super-flat maps.
-Fixed problem with Benches and the mod's custom fences not rendering properly under certain circumstances.
-Fixed problem with mod food-items not displaying particles with the right texture when eaten.
-Fixed problem with golems not displaying dig particles for the block they are walking on when wandering around, and the same for players when they are sprinting.  Similar to the food fix above, they now also display correctly for mod blocks.
-Fixed problem with the wood-based column recipes granting 4 columns, instead of the appropriate 1.

Version 4.40

-Added a new block type: the Bench, for all block types with sub-blocks.  It is crafted with 3 Siding on top of a Moulding (same as a Table, with a shorter "leg").
-Added fences for all block types with sub-blocks.  These may be crafted either with 3 Moulding of the type in a horizontal row, or the vanilla recipe of 6 full blocks in two horizontal rows for stone-based blocks (i.e. non-wood).
-Added brick Siding, Moulding, Corners, Pedestals, Columns, and Tables.
-Added sandstone Siding, Moulding, Corners, Pedestals, Columns, and Tables.
-Added stone brick Pedestals, Columns, and Tables.
-Added wood Pedestals, Columns, and Tables, for all wood colors.
-Added smooth stone Tables.
-Added Boiled Potatoes as a new item.
-Added a small amount of damage to falling Hardcore Melons, along with custom death messages for them.
-Added sound to falling Hardcore Melons when they don't explode.
-Added general purpose internal hooks for when an arrow initially impacts with a block, and when it is in a state of collision with a block, that may be useful for add-on authors.
-Added an internal hook for when blocks finish falling, that may be useful to add-on authors.
-Added high efficiency recipe for nether-brick fences (3 Moulding).
-Changed the dimensions and texture of wood Table Legs so that they match the top of fences.  This was done because it opens up many aesthetic possibilities like building shelving, trestle bridges, and cool looking stairways out of a combination of Tables, Benches & fences.
-Changed the way Hand Cranks work so that the "use" animation (the extended arm) is only played when the crank is actually moved so that its usage is more intuitive, and also changed it so that it can not be operated if your hunger level is below a certain point.
-Changed ALL Pedestal recipes to consist of six blocks of the type, topped by a single Siding.  This is for consistency because Pedestals can now be made out of materials that can be obtained pre-Anvil (namely wood).
-Changed ALL Column recipes to consist of three Moulding of the type in a vertical line, for the same reasons as above.
-Changed chickens so that they can be fed by hand again, as while it made sense that they couldn't, it was causing too much confusion due to lack of consistency with the other animal types.
-Changed the hardness on nether brick Siding, Moulding, Corners, Pedestals, Columns, and Tables to match that of nether brick blocks.
-Changed the way Hardcore Melons work so that melons require arrows to have a certain minimum velocity to cause them to explode when hit.
-Changed Hardcore Melons so that they won't explode when falling into water.
-Changed (reduced) the number of mobs that spawn wearing armor to further balance the iron output of mob-traps.
-Changed the way a bunch of sub-blocks work internally to facilitate the inclusion of new aesthetic block types.  Because of this, old versions of these blocks already placed in your world may not auto-connect properly, and will no longer function in recipes.  My apologies for this, but having to support recipes for both the old and new versions was making the mod's recipe code get completely out of control, and was likely also hell for people using mods that display recipes, as both the old and new versions would be listed.  To help with this, I've added "old" to the name of each of the blocks that may be problematic (e.g. "Old Corner"), so that they can be easily identified, and I've included conversion recipes for all these old blocks, so you can just drop them into the crafting grid and they will be converted into the new.  In the case of old blocks in the world no longer auto-connecting properly, just harvest the old blocks, replace them, and any problems should be resolved.
-Changed smooth stone Pedestals, Columns, Siding, and Corners so that axes aren't efficient on newly placed ones.
-Changed all wood based sub-blocks to have appropriate burn times in the furnace.
-Changed the collision volume around Tables (of all types) and of vanilla fences so that it precisely reflects their shape.  This means that you can "click around" their various parts to the blocks behind them, and that things like arrows will pass through the empty space surrounding them.
-Fixed problem with Lightning Rods not being able to rest on top of others.
-Fixed problem with pumpkins dropping way too many seeds when they explode.

Version 4.38

IMPORTANT: This version requires a CLEAN install of BTW to function properly.  This means that you need to redownload Minecraft (delete your bin directory and run the game without the mod installed), then install 4.38 to it.  Just copying over the old install will likely result in bugs and potential crashes.  My apologies for this as I normally try to make such changes when vanilla updates to prevent these kinds of problems, but this one slipped through the cracks.

-Added Hardcore Melons.
-Added nether brick Siding, Moulding, Corners, Pedestals, Columns, and Tables.
-Added internal functionality to determine when a block has a center "hard point" to a particular facing to determine if things like torches, Lightning Rods, and Stakes can "stick" to them.  This allows for a number of blocks to attach to others that previously weren't possible, and may be useful for add-on authors in establishing similar functionality with their blocks.  This also marks the triumphant return of torches sticking to the sides of Panels ;)
-Added the ability to melt down Lightning Rods in the Crucible.
-Changed the order in which the Cauldron processes ingredients so that gunpowder is created before string is converted into wool.  This allows for the dumping in of the raw materials required to make Fuses, without your string being turned into wool.
-Changed some code internally to eliminate base classes that were getting modified in the releases of the mod that I wasn't actually modifying.  This is what necessitates the reinstall mentioned above.
-Changed Wind Mills & Water Wheels so that they can not be placed when overlapping with another entity, including the player.
-Changed the way vertical Wind Mills are placed to accommodate the above change, and to make their placement more intuitive.  They are now placed so that their vertical position *starts* (either top or bottom) at the Axle you click on.  In other words, if you're looking upwards, it will place the Wind Mill going up from the Axle you click on, if you're looking down, then going downwards from it.
-Fixed "pick block" functionality (middle mouse button) to work on a bunch of mod blocks.
-Fixed some Corners not placing properly in SMP.
-Fixed Dynamite not firing out of vanilla dispensers in SMP.
-Fixed Splash Potions not firing out of vanilla dispensers in SMP.
-Fixed Buckets not dispensing properly out of vanilla dispensers in SMP, with Hardcore Buckets disabled.
-Fixed problem with being able to place Urns, Grates, Wicker, and Slats while the player or another entity was in the space the block was to occupy.

Version 4.37b

-Fixed crash bug when right-clicking on wolves with an empty hand.

Version 4.37

-Added the Lightning Rod as a new block.  It is created with 3 iron ingots in a vertical line.  With the addition of vertical Wind Mills, lightning has become a much bigger problem, so this simple block was added as a way to address it.  They also makes awesome mounts for skulls ;)
-Added the ability to pickup Vases without breaking them using the silk touch enchantment.
-Added ability for Vases to blow up if they are broken while containing Blasting Oil.
-Changed the collision volume around the Vase, Planter, and Hopper so that it precisely reflects their shape.  This means that you can "click around" their various parts to the blocks behind them, and that things like arrows will pass through the empty space surrounding them.
-Changed the Hopper to always deposit into the top chest in the inventory gui, when depositing into double chests, as it was a minor annoyance that it didn't do so.
-Changed Hardcore Chests so that ender chests access the same inventory regardless of what dimension they are in.  This was done because it was originally intended this way, and it turns out that chests in other dimensions weren't saving their contents when servers were restarted anyways.
-Changed Zombies and Skeletons so that they drop any armor they are wearing or any non-standard equipment they are carrying on death at a greatly increased rate (sometimes the equipment breaks, but most of the time you get it), because chasing after a rare armored mob to only have it drop nothing is hela-lame. Also, this boosts iron output on mob-traps back up after it was reduced in a previous release.
-Changed mobs to spawn with equipment with equal probability on all difficulty levels.  This was done so that mob-trap output is not difficulty level dependent, as that just leads to gamey nonsense.
-Changed zombie pigmen so that they only spawn with gold swords rarely, but they almost always drop them on death.  The overall drop rate is unaffected by this change (mob trap output will not be affected), it just makes it much more tempting to go after pigmen you see holding swords, and creates a more direct connection between what mobs are holding and what they drop.
-Changed zombie pigmen to restore their gold nugget drop, as with the above change it gives the impression they're slowly trying to forge their own weapons.  They do so at a reduced rate to what they used to mind you.
-Changed the way the damage on dropped items is computed to provide a better range of values on items with low maximum damage (like gold swords).
-Fixed vanilla dispenser not being able to fire Dynamite.
-Fixed the Companion Cube not properly showing its appreciation for being consumed by fire.
-Fixed problem with fire rendering on the side of blocks if it had infinite burn ones (like netherrack) below it.
-Fixed problem with not being able to feed wolves Wolf Chops.

Version 4.36

-Updated the mod to version 1.4.5 of Minecraft.
-Added particle effects when Soul Urns shatter.
-Changed how Dirt Slabs render internally to hopefully resolve visual issues with them when used in combination with high-res texture packs, when they have grass growing on them.
-Changed the sound mechanical devices make when they break, to something more appropriate.
-Changed a few more things internally to reduce the number of base class changes the mod requires.
-Fixed problem with Corners not placing properly.
-Fixed problem with the Block Dispenser not firing splash potions.
-Fixed the vanilla dispenser not being able to fire Soul Urns.
-Fixed problem with not being able to use a hoe on grass if it was in front of a Detector Block or in a Lens beam.

Version 4.35

-Updated the mod to version 1.4.4 of Minecraft.
-Added the ability for blocks of Concentrated Hellfire to burn indefinitely (like Netherrack), but *in any direction* (unlike Netherrack which only burns like this to the top).  This provides for much greater decorative options using fire.  Let the giant flaming sword construction commence! ;)
-Added the ability to grow sugar cane diagonally bordering on water, because I've always found it annoying that you couldn't, and I am a take-no-prisoners-certified-base-class-modifying-maniac.  Fear my wrath puny sugar canes!  FEAR ME!!!!
-Added recipe for chiseled stone brick.  You can create it on the Anvil with 12 stone brick blocks in a rectangular pattern.
-Added internal hook to specify if blocks can burn infinitely (like netherrack).  This may be useful to add-on authors.
-Added internal hook to specify if a block extinguishes fire above it (like an unpowered Hibachi).  This may be useful to add-on authors.
-Added internal hook for when blocks are destroyed by fire.  This may be useful to add-on authors.
-Changed the way vanilla fire renders so that it prefers a flammable side-surface to a non-flammable bottom surface.  For example, if you light the base of a tree on fire, the fire will appear on the side of the tree, instead of on top of the dirt next to it.
-Changed (refactored) things internally to reduce the number of base class edits the mod requires, to facilitate future version updates.
-Changed (refactored) the way mechanical blocks work internally to simplify the code somewhat.  This may be of interest to add-on authors.
-Changed the way fire works internally to make it easier to set which blocks are flammable.  This may be useful to add-on authors.
-Changed (reverted) Mojang's "fix" to items getting stuck in blocks as it created more bugs than it fixed.
-Fixed problem where if a repeater was swallowed by a Block Dispenser, connected circuits would not always properly update their state.
-Fixed problem with the Block Dispenser not properly handling silverfish infested blocks.
-Fixed problem where mechanical devices could be overpowered from directions in which they didn't have an axle-input.
-Fixed vanilla bug that caused particles (especially torch flames) to flash all over the screen in an exceedingly annoying fashion.

Version 4.34

-Added the Chopping Block as a new block type.  This block has grooves cut in it which means that it can be placed in front of a Saw while neither destroying the block, nor the Saw itself.  It is created with 6 smooth stone in a "U" pattern on the Anvil.  Note that trapping a player or mob between a Saw and Chopping block will result in a *big* bonus to damage caused by the Saw, and the same bonus to skull-drops as if they were killed by a Battle Axe.
-Added custom death messages for the Saw, Dead Weight, Groth, and for when the player is killed between a Saw and Chopping Block.
-Added high efficiency recipe for the Saw involving wood Siding instead of planks.
-Added Arcane Scroll drop to blazes as they can now reliably be farmed.
-Added the ability to plant carrots and potatoes with the Block Dispenser.
-Changed (reduced) the cost for using the Infernal Enchanter from base 50, to base 30 in order to better match the values used with the vanilla enchanter.
-Changed skeleton Arcane Scroll drop so that they don't drop from wither skeletons.
-Changed the "limit pigman and magma cube" option to the more general "limit nether mob spawns", and applied it to blazes and wither skeletons as well.  These mobs can now only spawn on netherrack, and netherbrick.
-Changed the Mining Charge recipe to use slime balls instead of Glue, as it fits the idea of Glue being a permanent adhesive vs slime being a "tacky" substance better.
-Changed the limited slime spawning code so that they can now also spawn on grass, gravel, and sand (as well as the previous dirt and smooth stone), to better fit them being able to spawn above-ground now.
-Changed skeletons and wither skeletons to be able to spawn in the nether regardless of light level, to match the other nether mobs.  Without this they couldn't spawn near fire and lava, which obviously doesn't make much sense in the nether.
-Fixed a very small problem in the Water Wheel rendering code that caused a tiny gap to appear between the struts and blades.
-Fixed problem with the Block Dispenser being able to harvest wheat, potato, and carrot crops before they were fully grown.

Version 4.33

-Added high efficiency recipe for item frames involving Tanned Leather surrounded by wood Moulding.
-Added internal functionality to allow silk touch to function or not on blocks based on their subtype.  This was used to allow White Stone and Flint blocks to be harvested without converting into other blocks when using silk touch, but it may be useful for add-on authors as well.
-Added Crucible recipe that first converts gold bars into gold nuggets when there isn't enough Concentrated Hellfire present to produce redstone out of a full bar.
-Changed the green "you are here" marker on maps placed in frames to point in the direction you are looking at, instead of the direction the map is facing, as it feels far more natural given the direction of the pointer when the map is being held.  In other words, the pointer now points in the direction you are looking if your viewing the map from straight on, instead of pointing in the opposite direction, which is the direction the map itself is pointing in.
-Changed wolves so that they will lose their angry state after their target is dead.
-Changed cake so that it is only eaten on right-click, to match the other changes made by Mojang in this regard.
-Changed (refactored) several parts of the mod code to reduce the number of base-classes the mod changes.  This will speed up the process of porting to new versions of Minecraft in the future.
-Changed Glue and slime balls so that they are entirely separate materials with their own uses.  Slime is a tacky material that is used for creating things like sticky-pistons, while Glue is a permanent adhesive.  Several mod recipes have been changed to reflect this, but the end result is that they can no longer be used interchangeably in recipes, and all mod recipes involve Glue, not slime.  This was done because slimes are much more readily available in vanilla now.
-Changed how chicken possession in the nether works internally to pave the way for additional changes of a similar nature in the future.
-Fixed crash when attempting to zoom maps out with the Anvil.
-Fixed problem with Stoked Fire being picked up by the Block Dispenser.
-Removed ability of the Block Dispenser to pick up skulls due to code complications.  I may address this later, but for the time being, the BD is simply not effective on skulls.
-Fixed problem with maps in Item Frames not updating properly on world load.
-Removed map player location indicator when players are off the edge of the map.  I left a slight "border" in there so you still get the indicator if you are slightly off the edge, but it doesn't extend very far at all anymore.
-Removed map display of location of other players in multiplayer.
-Removed XP dropped from all sources other than mobs.

Version 4.32

-Added ability to drop player skulls on death.
-Added Crucible recipe to melt down the vanilla anvil into iron ingots.
-Added overpower reaction to Mill Stones, Screw Pumps, and Turntables, since these blocks can now be overpowered due to the inclusion of the Vertical Wind Mill in a previous release.
-Added ability to rotate skulls on the Turntable.
-Changed axes of all kinds to be effective at harvesting placed skull blocks.
-Changed (increased) the volume of the screams produced when grinding netherrack to better fit the new Mill Stone sounds.
-Fixed problem with exploding Blasting Oil sometimes appearing to destroy blocks even though they still exist on the server.
-Fixed crash when the Enderdragon collides with Endermen.
-Fixed problem with carrots and potatoes "popping" out of tilled soil when bonemeal is applied, and with not being able to plant them in soil to which bonemeal has already been applied.
-Fixed problem with the Companion Cube & Slab not displaying properly in the creative mode inventory.
-Fixed problem where rapidly double right-clicking on the Anvil could cause any Moulds it contained to disappear.
-Fixed occasional texture glitch with the Hand Crank.

Version 4.31c

-Fixed problem with SMP servers crashing if started without a world loaded.
-Fixed soft-crash bug when killing a mob with your fist.
-Fixed bug with mod-block GUIs not opening in SMP.

Version 4.31

-Updated the mod to version 1.4.2 of Minecraft.
-Added ability for skeletons, zombies, and creepers to drop heads of the corresponding type upon death.
-Added *significant* bonus for collecting heads from mobs if they are killed with a Battle Axe.
-Added in internal mechanism for several mod blocks to help prevent them "jamming" if an update is missed for whatever reason.  This affects Stoked Fire, Buddy Block, the Hibachi, Bellows, Block Dispenser, Detector Block, Gear Box, Hand Crank, Light Block, Mill Stone, Pulley, the Saw, and Screw Pump.
-Changed mobs so that they'll drop any carried equipment regardless of whether they are killed by the player or another source.
-Changed Fuses, Elements, & Filaments to be created in the Cauldron before silk is converted to wool.
-Changed (increased) the durability of Tanned Leather Armor to relate better that of regular leather.
-Changed the Hand Crank to not activate on left click, so that it behaves in accordance with the changes made to similar blocks (like the lever) in 1.4.
-Changed the name of the vanilla Anvil, , removed all GUI functionality, removed the damage it takes from falling, changed its bounding box to better reflect its shape, added the ability to rotate it on the Turntable, and changed the recipe for it to only require 7 iron ingots (no blocks).
-Changed the name of the "Stewing Pot" back to the "Cauldron", and renamed the vanilla one to the "Cistern".  I just couldn't take it anymore, and if I'm going to be renaming vanilla blocks anyways for things like the Anvil, I may as well go whole hog on it :)
-Changed the mod's reliable block update code to be off by default due to it apparently causing memory leaks on SMP servers.  However, with the above changes to block updates, the impact of this should be relatively minimal, and players can re-enable it in the config file for their single-player games if it causes too many problems.  I'll be working to resolve the memory leak in the near future, but for the time being it was causing too many problems to leave on by default.
-Changed the sounds on several mod blocks to make use of the new ones in vanilla.
-Fixed problem with tame wolves displaying the angry wolf texture.
-Removed the ability of mobs (skeletons & zombies) to spawn carrying leather, gold and diamond armor (only iron, and chain).  This was done to prevent the devaluing of gold, diamonds, and Glue.
-Removed ability of zombies to drop carrots, potatoes, and iron ingots.  In the case of iron ingots, this was done because they now drop large amounts of iron just due to their armor and weapons.
-Removed ability of zombie pigmen to drop gold ingots and nuggets.  This was done because they drop a large amount now with their carried swords.
-Removed glowstone dust, redstone, and gunpowder from the items that witches drop to prevent the devaluing of those resources.
-Removed a bunch of stuff that villagers used to sell, including anything made out of diamond.  I'll be tweaking villagers further in the future, but for now, this was too unbalanced to leave as is.
-Fixed vanilla bug with the extinguish sound not playing when you put out a fire.
-Fixed problem with Stewing Pots and Crucibles not exploding when Blasting Oil is overheated.

Known Issues with this release (will be resolved shortly):

-Soul Urns and Dynamite can not currently be dispensed from the vanilla dispenser.
-Maps mounted in frames will not display properly when you load a saved game if they are not exposed to the sky.
-The Block Dispenser can not currently "throw" splash potions.
-The Detector Block may currently miss updates on chunk load that may cause Gear Box breakage due to Wind Mills spinning out of control.

Version 4.30

-Added vertical Wind Mills to the mod!  Rejoice! They are created with 8 Sails in a rectangular patten on the crafting grid, rather than the usual 4, and are now the only means of obtaining mechanical power in the nether, other than a Hand Crank.  Note that regular Wind Mills already placed in the Nether will continue to function, to avoid breaking existing builds, but if you place a new regular Wind Mill, it will not function, and a vertical one must be used instead.
-Added Blasting Oil as a new item.
-Added back the ability for Ender Spectacles to see spawn locations in the end dimension.  I had mistakingly thought that spawns in the end were not dependent on light-level, which they actually are.
-Added crafting recipes to convert White Stone Siding, Moulding & Corners back into their larger block types.
-Changed the Dynamite recipe to reflect the recent changes with Hardcore Explosives.
-Changed the way water works with Hardcore Buckets enabled in the end dimension.
-Changed Wind Mills to not rotate in The End.  Water Wheels will be required to generate power there (in conjunction to the above change to water).
-Changed ghasts to drop Nitre instead of gunpowder.
-Fixed problem with Ender Spectacles not preventing enderman attacks in SMP.
-Fixed problem with being able to process Endstone in the Cauldron.  This was never intended, and the Kiln is the proper method of doing so.
-Fixed problem with the Block Dispenser picking up White Stone as White Cobble.
-Fixed problem with white smoke emitted by Stewing Pots & Crucibles moving downwards when the player approaches.
-Fixed problem with player location not displaying on maps while riding in boats or minecarts, or while standing beaneath leaves.
-Fixed problem with nether wart growing at an extremely reduced rate.

Version 4.22

-Added Hardcore Explosives to the mod.  This involves several new blocks and items, and I'll leave the details for players to discover :)
-Added the Barrel as a new block type.  It is crafted with 8 wood Moulding in a square pattern, with Glue in the middle.
-Added the Element as a new item.  It is now required to create a Hibachi, replacing the Filament in the previous recipe.
-Added config file option to disable the mod's reliable block update code, strictly as a test for server operators.  This option will be removed in a later release.
-Added ability to rotate logs on the Turntable.
-Added new recipe for cookies using Flour instead of wheat, and removed the old vanilla recipe as part of Hardcore Grinding.
-Added additional tests to ensure the mod has been properly installed and that crucial base-classes aren't being overwritten.  I was getting pretty sick of the "the mod works fine with parts of it overwritten by other mods" tech support nonsense.
-Added internal functionality for add-on authors to allow custom blocks to be cooked in the Kiln.
-Changed Ender Spectacles so that Endermen will not attack if you look at them while wearing them.  Note that this replaces the same functionality that used to be assigned to pumpkins.  Pumpkins will thus no longer work as a means of defense against them.
-Fixed problem with the player not receiving the bread achievement after cooking Flour in the furnace.

Version 4.21

-Added "Hardcore Spawn" as new optional game mode (off by default).  This mode is largely intended for anarchy servers where it prevents such problems as spawn-camping, players immediately returning to cause problems after they are killed, and idiocy like intentional suicides to get back to original spawn.  It thus makes traps and general base defense much more effective.  Despite being primarily intended for anarchy play, it can also make for an interesting single-player experience for the more hardcore amongst us as it gives much more impact to player death and encourages player construction and exploration over a wider area.  Note that with Hardcore Spawn enabled, spawn build protection is automatically disabled, as it becomes irrelevant.
-Added "Hardcore Player Names" as a new SMP server option.  This is largely intended for anarchy servers, where player names act as a rather unfair way of detecting a player's location without line of sight, and of immediately identifying friend or foe (which eliminates a lot of potential tension in encountering another player).  It totally disables player names appearing above a player's avatar, but may be disabled in the mod's config file.
-Added new cheat/server-op command "/loc" that will display current co-ordinates within the world.
-Added new usage case for the "/time" cheat/server-op command.  Entering it without parameters will return the current overworld time.
-Changed endermen from being lame and annoying, to being cool and sinister.
-Changed maps so that they won't display your location, or draw in new terrain, while you are underground or inside (you have to have open sky above you).
-Changed the Stake so that it is treated as a block when filtered by a Hopper.
-Changed Rotted Arrows so that only 4 are required to break them down in a stoked Stewing Pot, rather than 8.
-Changed the way Planters display to hopefully resolve some performance issues on lower end systems.
-Changed the way Unfired Pottery displays internally to avoid code duplication with the display of the various cooked pottery types.
-Removed option for reverse Gear Box placement as it had become redundant due to the ability to rotate Gear Boxes after placement.  Also, it was no longer working properly with SMP and thus was becoming more trouble than it was worth.

Version 4.20

-Added the Stake as a new block type.  It is crafted with a string on top of a wood Moulding.
-Added Hardcore Bedding as a new mod feature.  This effectively disables beds as a means to set spawn position and to skip the night.  This was done to encourage construction (especially of rail networks), restore the balance between day and night activities within the game, restore the impact of weather on gameplay, and to give player death more consequence.  Beds are just a bad feature, mkay?
-Added Hardcore Info as a new mod feature.  This removes any information in the debug menu that can be used to gain an in-game advantage, while leaving in place any info that would be used for tweaking performance and such.  It also adds a new display for how close the player is to a chunk boundary, since this can be used to workaround bugs in redstone circuits due to how block updates work in vanilla, while not providing cheaty info about which direction the player is facing.  Long story short: no more in-game GPS :)
-Added ability to cut wood stairs with the Saw.
-Added recipes to melt the Ocular of Ender, and Ender Spectacles in the Crucible.
-Added Hardcore Chests to the options that are displayed when a player joins a multiplayer server.
-Added a new aspect to Hardcore Chickens.
-Changed Pedestal placement so that it works more like vanilla slabs.
-Changed (refined) the tests that the Ender Spectacles use to determine if mobs can spawn somewhere to provide more accurate results.  This will resolve problems like them not indicating snow as a valid spawn location.
-Changed the Crucible so that gold items are melted before iron.
-Removed vanilla recipes for turning red & yellow flowers into dyes as part of Hardcore Grinding.  This may be done in the Millstone.
-Fixed problem with arrows bouncing off of mobs.
-Fixed problem with mooshrooms wearing breeding harnesses having mushrooms poke through them.  Mooshrooms now convert to regular cows when you put a harness on them.

Version 4.16

-Added the Ocular Of Ender as a new item.
-Added Ender Spectacles as a new item.
-Changed the name of Carbon Powder back to "Coal Dust", as Carbon Powder just sounded way too high-tech, and I really don't care about mod names conflicting with those from other mods anymore :)
-Fixed problem with Bellows not being able to blow items through trapdoor blocks.
-Fixed problem with the Block Dispenser picking up emeralds instead of emerald ore.

Version 4.15

-Added the ability for the Bellows to blow items of different "weights" different distances.  This should open up item filtration possibilities that weren't present in the past.
-Added a concept of undertow to Hardcore Buoy to prevent items from floating upwards in downward flowing water.
-Added internal hooks so that add-on authors can assign which of their custom items can be blown by the Bellows, and how far.
-Changed (tweaked) several aspects of the way items behave in water with Hardcore Buoy enabled to create a more refined experience where they act in a way that feels much more natural.
-Changed the way Screw Pumps work to prevent several possible exploits.
-Fixed problem with bows and glass bottles not floating properly in Hardcore Buoy.
-Fixed problem with items sometimes getting stuck on Saws in water flow with Hardcore Buoy enabled.
-Fixed problem with stone Siding and Corners floating in Hardcore Buoy.
-Fixed fucking annoying door-banging and fucking headache-inducing vanilla problem with fucking zombie sieges spawning even when fucking zombies shouldn't be able to fucking spawn somewhere (like in fucking lit up areas) because I just couldn't fucking take it anymore.  BANG!  BANG!  BANG!!!!!  AHHHHHH!!!!  GET OUT OF FUCKING MY HEAD! HIRE A FUCKING GAME DESIGNER! Fuck.

Version 4.14

-Added a new optional game-mode (on by default) called "Hardcore Buoy".  WARNING: This game mode will definitely break existing builds, as it drastically alters the way water-flow is used for item transport and filtration.  However, it is much more interesting, and opens up many filtration possibilities that weren't present in the past.  It may be disabled in the config file, but I strongly recommend leaving it enabled and adapting your builds, as future mod content will likely be dependent upon it.
-Added internal code for removing recipes from the Cauldron & Crucible.  This should be useful to add-on mod authors.
-Added internal code for adding and removing recipes to the Mill Stone, for use by add-on mod authors.
-Changed (optimized) the way the Mill Stone works for better performance in SMP.
-Fixed smoke particle effect when the Block Dispenser dispenses a block or item.

Version 4.13

-Added upside down Wicker Slabs.
-Added upside down Companion Slabs.  Unfortunately, due to the way the metadata was structured for this block, this may mean that a small number of 
Companion Slabs already placed in your world may convert to upside down slabs.
-Added ability for Moulding to auto-connect to corners.  This should make several shapes possible that weren't before with Moulding only auto-connecting to other Moulding.
-Added crafting recipe to recombine Wickers Slabs back into Wicker Blocks.
-Added birthing effects to villagers.
-Added high efficiency recipe to make stone brick stairs out of stone brick Moulding.
-Added the ability to grow tall grass and flowers by applying bone meal to grass back into the mod.
-Added a new variety of cat (tabby) to the game.
-Changed the Wicker Slab recipe to be only 2 wide to fit the recipes of Wool & Dirt Slabs, or "slabs that you can make with your hands".
-Changed the way Screw Pumps function to hopefully fix a problem some users were experiencing with a stack overflow.
-Removed ability to create Wool Slabs with the Saw, as it didn't make a whole lot of sense.  You can still of course create them in the crafting grid.
-Fixed problem with multi-color wood stair recipes involving Moulding, not working properly in SMP.

Version 4.12

-Added a new animated texture for Stoked Fire.
-Added particle effects when mechanical devices explode due to misuse.
-Added high-efficiency recipes to make different colored wood stairs out of the various colors of wood Moulding.
-Added code to communicate whether Hardcore Buckets is on when connecting to a server so that clients don't need to have the option set to the same value in their config file for buckets to behave properly.
-Added code to prevent players from being kicked from servers in SMP for flying while standing on moving Platforms or Wind Mills.  I couldn't reproduce this problem myself mind you, so I can't be 100% this will resolve the problem for everyone.
-Changed (optimized) several mod blocks to consume less bandwidth in SMP.  This applies to: Bellows, Nether Groth, Blood Wood, powered cake (you know you want to), Cement, Hopper, Soulforged Steel, Bloodwood Saplings, Mining Charge, Block Dispenser, Buddy Block, Detector Block, and the Turntable.
-Changed (increased) the range of Nether Groth spore release due to Steve's freakishly long arms.
-Changed (increased) the distance at which animals and villagers will continue to follow you if you're holding a tempting item.  This is to help compensate for it being way more annoying to get them to follow you again in 1.3 if they lose interest, and to make transporting them long distances less annoying overall.
-Changed (increased) the speed at which villagers follow you while you're holding a diamond slightly, to match their normal movement speed.
-Changed Cauldrons & Crucibles to produce white smoke when they have a fire beneath them, instead of black, as this is far more noticeable given that fire produces black smoke.
-Fixed the Bellows not lifting entities on top of it when it expanded.
-Fixed blowing particles on Bellows.
-Fixed items blown by the Bellows appearing to jump from place to place instead of moving smoothly.
-Fixed Nether Groth spore release visual effect.
-Fixed Mining Charge explosion visual effects.
-Fixed Hopper particle effect when it is "dripping" XP.
-Fixed vanilla bug that caused XP Orbs to have an invalid position on the client immediately after spawning, causing them to be initially invisible.
-Fixed problem with the Wind Mill not displaying its warning message when there's not enough room to place it.

Version 4.11

-Added Hardcore Grinding.  This removes the vanilla recipes for bone meal, sugar, bread and cake, requiring the player to use the Mill Stone to grind each of these (wheat may be ground into Flour, then baked into bread or crafted into cake).  Thanks to Sarudak for originally proposing this idea, and for going so far as to create a BTW add-on mod that convinced me of what a great idea it is :)
-Added Rotted Arrows as a new item.
-Added ability to fill water bottles from non-source water blocks, as this is rather useful in Hardcore Bucket mode.
-Added some of the newer mod blocks to the creative inventory.
-Added internal functionality for removing vanilla crafting recipes, as this was needed for Hardcore Grinding, and should prove useful for add-on mods.
-Added recipe for breaking down arrows in a stoked Stewing Pot.  It's not lossless though.
-Changed (reduced) the amount of Bone Meal required to make Kibble, to help balance its overall usage in relation to fertilizing crops.
-Changed the amount that villagers buy books and paper for, as their relative value didn't make a whole lot of sense given that it was more productive to sell unfinished vs. finished and more resource intensive goods.  This effectively decreases the value of paper slightly, while increasing the value of books significantly.
-Changed the Column recipe to be two vertical strips of stone in the crafting grid instead of 1, and to produce twice as much.  This is because it fits the recipe for the Pedestal much better, and just looks better overall.
-Changed the Arcane Scroll drop types on pigmen and magma cubes to adjust for the removal of the blaze drop below.
-Fixed problem with weird artifact water being left behind when placing a water bucket with Hardcore Buckets enabled.
-Fixed problem with buckets not showing up in the creative inventory with Hardcore Buckets enabled.
-Fixed problem with the Block Dispenser being able to pickup end portals.
-Fixed problem with villagers selling Hemp and writable books in SMP, rather than buying them.
-Fixed problem where librarian villagers were buying Hemp instead of Priests.  This simply would not do.
-Fixed red particles when living entities come into contact with a powered Saw.
-Fixed Placenta! Woot! :)
-Removed the Arcane Scroll drop from blazes, as the only way to effectively farm them is through spawners.

Version 4.10

-Added the Screw as a new item.
-Added the Screw Pump as a new block.
-Added Hardcore Chests.  This is a multiplayer standalone server optional mode (you can turn it off in the config file, and it does not apply to single-player or LAN) that causes Ender Chests to use a communal inventory for all players in the world, much as they worked in the vanilla pre-release.  This is to prevent them wrecking anarchy SMP play by preventing all possibility of having your valuable items looted/stolen.  Note that this will cause items already stored in Ender Chests to not be accessible by players on your server, so you'll probably want to warn your players to retrieve their items before installing this version if you intend to leave this mode enabled.
-Added a version check when connecting to a server with BTW installed.  If your version and that of the server don't match, a warning message will be displayed to indicate this.  I also added a version display in single-player when the world is first loaded.  You can check it later by popping up chat ("t" is default key).
-Added recipes to recombine all the new Siding, Moulding, & Corner blocks from the last release.  Note that wood blocks may only be recombined with ones of the same color.
-Changed Hardcore Bucket mode to be on by default for the mod.  With the addition of Screw Pumps, it is now the official mode of play for BTW, but may still be disabled through the mod config file if you have no concept of fun ;)
-Changed (increased) the amount of time it takes for the Bellows to change state to encourage the use of slower Turntable settings with it, to help reduce SMP lag from unnecessarily fast timers.
-Changed the Bellows so that it won't pump unless it receives a continuous mechanical power state for the duration of the time it takes to change state.  This is to prevent exploits in using high-speed timers (such as pulsars) to pump Bellows.
-Changed Wind Mills and Water Wheels to not be displayed unless the chunks around them are loaded.  This is to prevent them giving away base locations in SMP Anarchy play due to them being temporarily visible when the surrounding terrain would normally make it impossible to see them.
-Changed the way Gear Boxes and Axles are handled internally to minimize the network traffic associated with them.
-Fixed problem with Oak Corners dropping Oak Mouldings when destroyed.
-Fixed problem with Hoppers and Bellows dropping the old wood siding when they are broken through misuse.
-Fixed problem with wood slabs & fences not dropping the correct Mouldings or Corners when cut using a Saw.
-Fixed erroneous semi-colon in the mod's config file.
-Fixed problem with Hardcore Sheep where certain parts of the breeding algorithm were using the parent sheep's dye color rather than their original color to determine the color of offspring.
-Fixed problem with empty buckets not stacking properly in Hardcore Bucket mode.
-Fixed vanilla bug in Hardcore Bucket mode where milking a cow would replace an entire stack of empty buckets with a single milk bucket.

Version 4.01

-Added ability to use bonemeal on Hemp due to popular demand!  Rejoice!
-Added Hardcore Bone.
-Added wood Siding, Moulding, and Corners for each of the different colors of vanilla wood, as it just felt really weird without them since the different colors were added to the game.  Note that old wood blocks of these types (which can be identified by shortened names such as "Moulding" instead of "Oak Moulding") will not mix with the new ones in recipes, and will not stack with the new, but placing then removing the old blocks will correct this problem.
-Added Stone Brick Siding, Moulding, and Corners.  More varieties of such blocks will be coming in the future once extended blockIDs are made available, but given that stone brick is probably the most popular building material right now, I figured this one was worth it, and I needed a simple test case for the new Siding, Moulding & Corner code.
-Added the ability for Moulding to connect to other Mouldings of the same type.  Try it out, you'll see what I mean :)
-Added the ability to use Soul Urns as fertilizer on netherwart & Nether Groth, just like with Bloodwood Saplings.  This provides a method of kick-starting netherwart farms, albeit a very expensive one.
-Added the ability for priests to buy Hemp.
-Added recipes to convert Unfired Pottery back into clay balls in the crafting grid to make it a little easier to start over when you mess up while spinning pottery.
-Changed Vine Traps to use a system similar to vanilla slabs to determine whether they should be placed upside down or not.
-Changed the recipes for both Blood Wood Saplings, & Nether Groth Spores to require 8 Soul Urns each.  You're creating life here after all :)
-Changed recipes for Dirt and Wool Slabs to require two of the full blocks side by side in the crafting grid.  This is so that they conform better to other vanilla slab recipes, and conflict less with other mods while retaining the ability to make them without a crafting table.
-Changed the order in which the Crucible cooks its contents so that items are melted down before new ones are created for convenience. The overall order now is: combustible items burn, items melt down, then new items (such as Soulforged Steel) are created.
-Changed priests to buy the book & quill, rather than books that are already written.  This is to avoid the annoyance of putting a single letter in a book in order to be able to sell it.
-Changed Wool & Dirt slabs to handle light opacity in the same way as vanilla slabs.
-Changed the bounding box on Hemp so that it resizes to reflect its growth state.
-Changed shovels (including the Mattock) to be effective when used on tilled earth.
-Fixed problem with Unfired Pottery sometimes displaying the cooking texture when it is first place in the Kiln, only to change back to the regular texture, then back again to cooking.
-Fixed problem with melon and pumpkin stems not displaying properly when the seeds were first planted in Planters.
-Fixed problem with being able to place blocks like torches and redstone on top of empty Planters.

Version 4.00

-Added full support for SMP!  Yes, that's right: the moment you've all been waiting for is here, and BTW is fully multiplayer!  Installation instructions for the server can be found in the readme.  Further refinements will of course be made in the future, but for now: Have fun guys, and WOOT!!!! :)
-Added particle effects when retracting rope with the Anchor.
-Added particle effects when clay is rotated on the Turntable.
-Fixed problem with stone bricks not appearing in the creative inventory.
-Fixed problem with stone brick not appearing to change into mossy or cracked when the blocks converted.
-Removed code for universal wolf ownership as it really didn't make sense for SMP.  This may mean that you have to retame your wolves if you tend to switch between MC accounts.

Version 3.97

-Added upside down Wool Slabs.
-Changed netherwart to not grow in the overworld as it was just a bad design decision on Mojang's part to allow it to do so, and especially conflicts with the mod's focus on making the nether more interesting.
-Changed LAN code to be more reliable.  LAN play is still not officially supported though, and is strictly "use at your own risk", but progress is being made towards supporting it in the future.
-Changed the mod's reliable block update code to only apply to blocks that actually need it (redstone based, mech power, etc.).  This is to resolve performance issues that it was causing, particularly in the Nether, and in LAN play.

Version 3.96

-Added the ability for pigs to eat Kibble. They won't follow you if you're holding it though...it's not that appealing ;)
-Added ability to melt chain armor down in the Crucible, since you can now buy it from villagers, and it looks like ass.
-Added shift-click functionality to villager merchant gui, as it was frigging annoying without.
-Changed the name of Dog Food to Kibble.
-Changed the recipe for Kibble to involve bone meal and a dash of sugar.
-Fixed problem with the Block Dispenser being able to suck the wool off of baby sheep.
-Fixed problem with not being able to render Tanned Leather Armor and Breeding Harnesses into glue.

Version 3.95

-Added Hardcore Chickens.
-Added Dog Food as a new item.
-Changed mutant sheep to provide a more interesting gameplay experience.  They're much more refined little mutants now.
-Changed Glue so that it can only be produced out of leather, and leather-based goods (leather armor, saddles, etc.).
-Fixed problem with several mod blocks not rotating properly on the Turntable.
-Removed option to disable Hardcore Sheep.  It's just the way the mod works.
-Removed the ability of wolves to consume rotten flesh.

Version 3.94

-Added Hardcore Sheep.
-Added ability to place Bloodwood logs sideways, and for the trees to grow with sideways facing branches.  Note that this may halt the growth of current Bloodwood trees already placed in the world (it won't affect new ones though).
-Changed vanilla item code to resolve a problem where the visual state of items was not being communicated properly.  This was making things look weird when item stacks combined, as the individual stacks weren't indicating the multiple items within them, making it look like items were disappearing instead of combining.
-Fixed problem with items getting embedded in planters so that they couldn't be picked up.
-Fixed problem with the Companion Cube not rotating properly on Turntables.
-Fixed problem with Stewing Pot and Crucible contents not displaying properly after chunk-load.
-Fixed problem with grass growing on dirt blocks underneath dirt slabs.
-Fixed problem with animals appearing to drop two Breeding Harnesses on death, when they're really only dropping 1.
-Fixed potential problem with sheep getting stuck in the eating animation if you put a breeding harness on them while they were eating grass.
-Fixed problem with being able to fill a single slot of the brewing stand with multiple potions by shift-clicking on a stack of them.  Now you can fill multiple slots with a single shift-click instead ;)

Version 3.93

-Added *most* mod blocks and items back into the creative mode inventory.
-Changed all axes to be effective versus cocoa beans.
-Changed lighting on Dirt Slabs so they more closely resemble vanilla slabs with smooth lighting turned off.
-Changed the way Hoppers, Cauldrons, & Crucibles collect items on top of them.  This required base-class edits, but should get rid of all the problems in 1.3 with entities falling through them.  It should also resolve the old issue of players occasionally falling through them when walking on them.
-Fixed problem that was causing the game to crash when a Companion Cube was placed in the Mill Stone.
-Fixed problem with the Saw breaking if old wood slabs were placed in front of it.
-Fixed problem with the Stewing Pot inventory GUI being labeled as "Crucible".

Version 3.92

WARNING: This version has not been coded or tested to work in multiplayer!  Future updates of the mod will attempt to address this, but for now, attempting to play BTW in multiplayer (this applies to LAN play as well) will most likely have unanticipated and potentially disasterous results!

-Updated the mod to version 1.3.2 of Minecraft.  It was hell :)
-Added the Dirt Slab as a new block type.  They are made with a single dirt block in the crafting grid, not requiring a crafting table to make.
-Added ability to plant cocoa beans with the Block Dispenser.
-Added high-efficiency redstone repeater and stone pressure plate recipes using stone Siding, instead of stone blocks.
-Added high-efficiency recipe for wood pressure plate using wood Siding.
-Added high-efficiency recipe for the Pulley using wood Siding
-Added high-efficiency conversion recipe for Moulding to sticks.
-Added high-efficiency shapeless book recipe.  It involves 1 piece of Tanned Leather, and 6 pieces of paper to create 2 books.
-Added recipe to break-down Composite Bows in a stoked Stewing Pot.
-Added crafting recipes to combine two Wool Slabs (of the same color) back into a Wool block.
-Added much more noticeable particle effects from valid book shelves to the Infernal Enchanter.
-Added lots of jerkiness to Platform movement, due to numerous player requests.
-Changed the way Corners and Moulding are placed, so that they appear based on where the player places them on another block.  Give it a try, you'll see what I mean :)
-Changed Siding, Pedestals (upside down), Planters, Saws, Anchors & Tables so that you can place stuff on top of them (like torches and redstone), when they are in the correct orientations.  Basically, if a mod block has a solid top surface, you should be able to place stuff on it now.  Warning though: this also means that mobs can spawn on them.
-Changed the Wool Slab recipe to only require a single wool block in the crafting grid, similar to dirt slabs.  The general idea is that simple or soft materials do not require a crafting table to turn into slabs.
-Changed the way Cauldrons and Crucibles work internally, in a substantial fashion.  Let me know if any problems result.
-Changed ropes and anchors so that you need to click on them without any item at all in your hand to retract a rope (previously, you could click with any non-rope item in your hand).
-Changed the Redstone Eye recipe to use three gold nuggets instead of a gold ingot.
-Changed the Lens recipe to use gold ingots instead of nuggets, and glass panes instead of glass blocks.
-Changed vanilla dispensers so that they can't place and retrieve buckets of liquid in hardcore bucket mode.
-Changed high-efficiency sign recipe so that it produces 3 signs, instead of 1, to reflect change to vanilla.
-Change the Hopper so that it can not eject items directly into another Hopper bellow it, if the below Hopper has a filter in place.
-Fixed problem that was causing slimes and magma cubes to drop the wrong Arcane Scrolls (they each have different ones now, and neither are knockback), and for the magma cube drop to be too rare.
-Fixed problem with sheers not taking damage when used to harvest Bloodwood Leaves.
-Fixed problem with the Anvil not dropping any moulds it contained when destroyed.
-Fixed problem with Cement not being able to flow through Nether Groth.
-Fixed problem with Canvas being placeable so that they overlap other Canvas or paintings.
-Fixed problem with Cauldron inventories not updating properly when the player went through a Nether Portal.
-Fixed problem with the Bellows being able to blow items in water.
-Fixed vanilla problem with fire not hissing when the player put it out.
-Removed the changes that the mod made to the vanilla enchanter, since many of these are now handled in the vanilla code, and the mod now has its own enchanting system through the Infernal Enchanter.
-Removed mod code for increasing the number of pork-chops that pigs drop on death, since this is now done by vanilla.
-Removed mod blocks and items from the creative mode inventory due to changes in code architecture.  While I do not officially support creative mode, most of these will be restored in a later release.
-Removed the disabling of the End-Game text due to changes in code architecture.  This will be restored in a later release.
-Removed birthing particles from animals due to changes in code architecture.  These will be restored in a later release.
-Removed Bellows blowing particles due to changes in code architecture.  This will be restored in a latter release.
-Removed newest property of Soulforged Steel due to changes in code architecture.  This will be restored in a latter release.
-Removed "spot light" effect on a block that intersects the beam from a Lens due to changes in code architecture.  This will be restored in a later 
release.
-Removed visual effect when Nether Groth releases spores due to changes in code architecture.  This will be restored in a later release.
-Removed explosion particles on Mining Charges & Dynamite due to changes in code architecture.  These will be restored in a later release.
-Removed red particles when a living entity is damaged by a Saw due to changes in code architecture.  These will be restored in a later release.

Version 3.91

-Added the Mould as a new form of pottery.  The Mould is an item that is ignored when crafting.  It may be used to turn the Anvil into a crafting grid with a custom shape and size, to aid in general mass-crafting.
-Added the Canvas as a new item (Fabric surrounded by Moulding 4X4).
-Added ability to melt vanilla cauldrons down in the Crucible.
-Added another mysterious property to Soulforged Steel blocks.
-Change the Anvil so that you can leave Moulds in it between uses, to preserve custom crafting grids created as described above.
-Changed Nether Growth so that lava and other fluids will flow through it, destroying it in the process.
-Changed the name of "Nether Growth" to correct a typo.
-Changed how the mod works internally to avoid a conflict in creative mode with the last released version of BTB.
-Changed Hopper to eject items from a random stack in its inventory rather than always the first occupied one, to help prevent exploits.
-Fixed problem with player being able to pick up Netherrack with Nether Growth on it with the Silk Touch enchantment, when you're not supposed to be able to.
-Fixed problem with the Lens being activated by light-sources with way too low a light level (like redstone repeaters and nether portals).  Now it will only respond to sources like torches, Light Blocks, jack'o'lanterns, etc., as was originally intended.
-Removed alternate recipes for Rope and paper that were added in version 3.80, as this functionality is now effectively replaced by Mould items.
-Removed the various forms of Unfired Pottery from the creative-mode inventory, since the finished versions are already there, and it was just cluttering the interface for nothing.
-Remove ability to use bricks as "filler" in the Block Dispenser and Hopper.  Sorry guys, but it was way too open to exploits.

Version 3.90

-Added Nether Growth Spores as a new item.  Hint: They are created in a manner similar to Bloodwood Saplings, involving the various form of fungus in the MC world, with a pinch of Dung.
-Added what must be my best feature of all time: I disabled the end-text.  Not only does this save you the annoyance of having to skip it every time you leave the end, if you've never completed the game it saves you the temptation of sitting through something really lame and from the inevitable soul-crushing dissapointment that is bound to result (trust me...you'll be much happier just respawning at home and pretending it never happened).  For the masochistic however, I've included an option in the config file to re-enable it so that you can still enjoy the sweet sweet suffering.  Who's your daddy?
-Added spawn-restrictions to slimes so that they can only spawn on dirt, and smoothstone.  This provides the player the ability to limit the spawning of slimes within their bases, as they can get really annoying otherwise.  This option may be disabled in the mod's config file for people that may already have slime-farms built out of other materials.
-Added spawn restrictions to squid so that they can only spawn in significant bodies of water.  This can also be disabled in the config file, but otherwise, no more squid jamming up your mob traps, or finding shallow pools of water containing stranded squid!
-Added small audio cues to when a Hopper swallows an XP or Dragon Orb, and to the Infernal Enchanter when it enchants an item.
-Changed the amount of Rotten Flesh & Bones required to render into Glue to 16 each.  Feathers have also been changed to 32.
-Changed the Infernal Enchanter to consume an Arcane Scroll when an item is enchanted.
-Changed how shift-clicking in the Hopper inventory works so that items that work as filters automatically go to the filter slot.
-Changed the drop-rate of all rare drops from mobs to be about 1/4 of what it was before.  They did not at all balance well with the recent changes to facilitate mob-farming and made iron in particular an entirely trivial resource to accumulate.  Those wishing to automate iron production more extensively should look into iron golem farms.
-Fixed problem with snow golems dropping Dragon Orbs on death, even though they weren't supposed to.
-Fixed problem with snow golems dropping Arcane Scrolls on death, even though they weren't supposed to.
-Fixed problem with axes not being effective on wood Moulding.
-Removed the Infernal Enchanter and Arcane Scrolls from the creative inventory.
-Removed Arcane Scroll drops in creative mode.

Version 3.80

-Added the Infernal Enchanter as a new block type.
-Added Arcane Scrolls as a new item type.
-Added Candles as a new item (2 Tallow + Hemp Fibre).  These will have additional uses down the road once the extended block IDs are available in vanilla.
-Added a new mysterious property to Soulforged Steel blocks.
-Added ability to lift XP and Dragon Orbs with Platforms.
-Added ability to clump snowballs together in the Block Dispenser in the same way as clay balls.
-Added ability to use bricks in the Block Dispenser as "filler".  Inventory slots containing bricks will be ignored by the BD when it attempts to dispense, allowing the player to effectively limit the amount of available inventory space within a BD without affecting its operation otherwise.
-Added recipe to convert gold nuggets into gold bars in the Crucible, using the standard 9 to 1 conversion ratio.
-Added ability to place Vine Traps "upside down" so that the top of them will be flush with the blocks next to them.  They can still be placed the old way by placing them on the top of a block.
-Added alternate rope recipe with the Hemp Fibers placed horizontally instead of vertically for convenience in mass crafting.
-Added alternate book recipe with paper in a horizontal line for same reason as above.
-Changed some of the graphics for Tanned Leather based items so that they don't look weird on the hot-bar.
-Changed the way the Crucible processes items so that it always burns combustible objects it contains before doing any other processing.  This is to prevent the Crucible from overflowing if it contains a surplus of bows or other single-stack combustible objects while you are doing other processing.
-Changed pigs to drop 1 to 3 pork chops on death instead of 0 to 2, to reflect upcoming changes to vanilla, and to further incentivize their use in Tallow production.
-Changed the sound pigs make when giving birth to be more appropriate to the situation.
-Changed the recipe for Padding to consist of 3 feathers (middle row), surrounded by 2 Fabric (top and bottom rows).  This is to increase the value of both chicken farms (particularly given the below change to Tallow), and Hemp in the late game.
-Changed the Slats filter in the Hopper to allow Hemp leaves to pass through.
-Fixed problem with the Block Dispenser always converting any leaf blocks it picks up into oak leaves.
-Fixed problem with only oak planks being able to be converted to Potash in the Stewing Pot.
-Fixed problem with the Block Dispenser overwriting any tall grass, vines, or shrub blocks in front of it which was creating problems with automatic farms for these resources due to a recent vanilla change.  The BD will no longer be able to place blocks if one of these blocks is in front of it.  
-Fixed problem (and potential exploit) with wood Siding, Moulding, and Corners burning just as long as wood planks in a furnace.
-Fixed problem with upside down wood slabs breaking Saws.
-Fixed problem with upside down stairs not rotating properly on the Turntable.
-Fixed problem with placenta not always properly displaying.
-Removed recipes to convert chicken and eggs into Tallow.  Sorry for this, but chicken farms are way too open to exploits, which severely devalued other types of animal farms (particularly pigs), and this also encouraged the creation of certain kinds of chicken farms which are detrimental to game performance.
-Removed ability to enchant Soulforged Steel equipment on the enchanting table.

Version 3.72b

-Fixed problem with Buddy not being able to detect when stone bricks are converted to mossy or cracked.

Version 3.72

-Added the ability to farm mossy and cracked stone brick.  Mossy is formed by letting water drip through regular stone brick.  Cracked is formed through doing the same with lava (Thanks to Gilberreke for this idea!).
-Added functionality to the Crucible to destroy all flammable blocks (those that can normally be consumed by fire) as well as an assortment of items that feel like they should probably be incinerated in a vat of molten metal.  Note that this can actually be rather useful in say getting rid of bows that are dropping from mobs and otherwise jamming up your Crucibles.
-Changed Spiders to drop spider eyes regardless of whether they are killed by the player.  These aren't technically a rare drop, so my previous changes to drop rare regardless of damage source weren't effective on them.
-Changed the way Turntables process updates to hopefully correct some block-duplication bugs that were occuring with blocks attached to their rotated column.
-Fixed problem with the growth rate of baby cows being affected by them being turned into mooshrooms due to standing on mycelium.
-Fixed problem that would allow you to speed through shallow water while wearing Plate Armor by sprinting and jumping.

Version 3.71

-Added a new aesthetic block type for flint.  NOTE TO TEXTURE-PACK ARTISTS: This block is intentionally visually identical to bedrock.  This is to provide players with the ability to hide stashes within bedrock in SMP, and also to provide players with a way to achieve uniform flooring at bedrock level.  Currently, it has its own texture in the mod's texture file, but once extended block IDs become available, it will use the bedrock texture straight from vanilla to prevent people disabling its use in hiding stuff through a texture pack.  As such, I recommend simply copying your bedrock texture for your TP, as any customization you may perform now will be lost later, altering the look of player worlds.
-Changed Mining Charges to NOT convert cobble in item form to gravel.  This was a design error on my part that severely devalued sand, gravel, and Mining Charges by allowing essentially infinite conversion from cobble to gravel with a single charge.  This change is the main reason for this release.
-Changed Mining Charges so that it will take at least two blasts to destroy any item with one (ores remain indestructible to Mining Charges).
-Changed mobs to drop a single larger Dragon Orb on death instead of a bunch of little ones (they still contain the same total XP out of them).  This is to cut down on the number of simultaneous entities in the world and help with performance.

Version 3.70

-Added a new variety of XP orb that is dropped from mobs and animals when they are slain by something other than the player.  These "Dragon Orbs" may not be picked up by the player, and require additional processing to be useful.
-Added the ability to filter Dragon Orbs using a soul sand filter in the Hopper, which will convert them into regular XP orbs.  Note that regular XP orbs can also be collected by a Hopper containing a soul sand filter.
-Added the ability to use iron bars as a Hopper filter.  These will allow items that can be stacked to pass through, while leaving those that can't behind.  As with other filters, blocks can not pass through either.
-Added stoked Stewing Pot recipe to render down bows into string and sticks (2 of each...it's not lossless).
-Added some "interesting" effects to Soulforged Steel Armor that I'll leave it to you to discover.  However, I will say that one of these changes involves increased effect to a particular kind of enchantment.
-Changed vanilla animal and monster AI so that they will wander regardless of the range to the player.  This effectively fixes Mob traps being disabled with distance (assuming the corresponding chunks aren't unloaded).
-Changed Mining Charges so that they convert cobble stone (in both block and item form) into gravel when they detonate.
-Changed vanilla behavior so that rare drops can spawn from mobs on death regardless of what kills them.  In other words, you don't have to kill them yourself to get the rare drops.
-Changed the Tanned Leather Armor, Breeding Harness, Dynamite, and Tuning Fork item textures to have a bit of visual noise so that they look a bit better, and fit in more with other game textures.
-Changed the way the Sterwing Pot & Crucible work internally so that their recipes can have multiple outputs instead of being limited to just producing 1 item type.  The bow conversion recipe in this release is an example of what I mean.  This will have additional uses in the future, makes for some more interesting crafting functionality, and further serves to differentiate the functionality of these devices from their vanilla crafting counterparts. 
-Changed the size of the bounding box on XP orbs so that they'll fit through tight spaces when channeling them with water-flow.  They now have the same size collision box as items do.
-Changed (optimized) the vanilla code for XP orbs being drawn towards the player to offset the cost of having more of them in the environment due to other changes in this release.
-Changed (refactored) the way the Pottery code works for when it is spun on the Turntable both to simplify and to provide a standard interface for crafting on the Turntable for the upcoming mod API.
-Changed the sound effect on Hoppers when they are opened and closed.
-Fixed the way the Composite Bow renders in third person so that the player appears to be drawing it.

Version 3.64

This is an emergency bug-fix release to resolve the following problems which only affect players using Harcore Bucket Mode.  My apologies for any incovenience this may have caused:

-Changed the way ice tests for melting in HCB so that it only tests for melting based on environmental conditions (biome, overhead cover, etc) are done on block placement.  There was just too much potential damage to old worlds with erroneous biome data.
-Fixed major problem in HCB where pretty much *ALL* ice would melt with time.
-Fixed problem with the Detector Block not properly resetting its state when pushed by a piston.

Version 3.63

-Added Tuning Forks as a new item.  These are created on the Anvil using Soulforged Steel.  The pitch of a fork may be changed by crafting the fork again.  Right-clicking on a regular block with one will play the note associated with that block, just as if a note block were sitting on it.  Right-clicking on a note block with one, will set the note block to always play that particular note.  For the musically inclined, this makes setting up large numbers of note blocks to play songs MUCH less annoying, and can also just be fun to play around with in striking various surfaces for impromptu jam-sessions :)
-Added ability to pick up ice blocks with the Block Dispenser in preperation for the upcoming change to vanilla where you'll be able to harvest them with silk touch.  Note that the final details with regards to how ice will behave in different environments in vanilla MC may not have been settled yet, so please keep in mind that at some point any devices built around ice now may cease to function in a future MC update.
-Added a few more particles to the animal birthing process due to a brilliant player request.  Thanks to FlowerChild for this idea and to placenta for being so damn cool!
-Changed ice blocks in Harcore Buckets mode to not produce water source blocks when harvested or melted, and to melt if they are either not above ground, or in a biome in which they can't naturally form.
-Changed ice blocks to melt instantly when placed in the nether, and to not produce water source blocks when doing so.  This basically duplicates some of their placement restrictions in upcoming versions of MC.
-Changed the way wolves produce dung so that they will not do so unless there is open space in the neighboring blocks (entities don't count for this...just blocks).  In other words, the block they are attempting to produce dung into has to be empty (or water, or fire...or other replaceable blocks).  Short version: wolves don't poop into occupied blocks.
-Changed Dynamite to explode on contact with lava.
-Changed unlit Dynamite so that it converts to an item at the exact position of its entity (minor visual change).
-Changed the way the Block Dispenser places levers, so that if there isn't a valid surface opposite the BD, it will attempt to place the lever on the ground.
-Changed the way water acts when placed with a bucket in HCB mode so that it flows a bit more naturally instead of almost instantly dissapearing like it used to.
-Changed (nerfed) Soulforged Steel weapons to reflect the changes that were made to the vanilla ones when enchanting was introduced.  They should be much less powerful now.
-Changed the Detector Block and Buddy to act as other solid blocks in terms of relaying redstone signals through them.  My apologies for any existing builds that this may break, but I hope you will find the functionality gained through this change will offset that, as you can do some pretty cool stuff with this.
-Changed animal AI so that adult children stop trying to follow their parents, as this was causing problems with particular setups for automated breeding facilities.
-Changed (refactored) the mod's custom code for growing big trees (oak) to bring it up to date with recent changes in the vanilla code-base and to make it simpler to update in the future.
-Changed animals wearing Breeding Harnesses so that they will now damage each other if their collision volumes become imbedded (damn those hooks).  This is to prevent exploits with animal breeding facilities where the animals are forced into situations where they exist in the same space.
-Changed (nerfed) the amount of XP dropped by villagers when they are slain, to better fit their new(ish) breeding mechanic.
-Fixed problem where wolves were always producing dung in the same direction, as opposed to it being released relative to the direction their ejector-port is facing, due to a change in the vanilla code.
-Fixed problem with creatures avoiding Vine Traps under certain circumstances.  They should be much more reliable now when used in mob-traps.

Version 3.62

-Changed the way Gear Boxes power up and down so that powering down takes 1 tick (1/20th of a second) less time than powering up.  In normal operation, this should make very little difference, but for the dirty bastards that were using exploits to create infinite power-loops, it means that these loops will slowly bleed off power until they are non-functional.  However, I've provided an option in the mod config file to disable this setting as testing has revealed that it can break particularly complex existing builds.  Please give it a try though and let me know what you think.
-Changed the way moving Anchors update to hopefully prevent associated Platforms in separate chunks from occasionally breaking off during chunk save/load.
-Changed the way Stoked Fire updates to be MUCH more reliable.  It should not revert to regular fire now before a fixed time interval elapses.  It may take a bit longer to provide a bit of visual variance, but it absolutely won't take less time, which means that Bellows being pumped on the third setting of the Turntable should now be 100% reliable.
-Fixed vanilla bug where scheduled block updates were getting dropped on chunk save/load.  This was causing a number of issues like redstone clocks freezing under those circumstances, and Detector Blocks failing to notice rain for extended periods.  These kinds of things should be MUCH more reliable now.  This may not sound like it, but it's a REALLY big deal.
-Fixed problem with not being able to jump on Platforms when they were moving downwards.
-Fixed problem with items visually jerking about when dropped on moving Platforms.
-Fixed problem with the Block Dispenser placing regular minecarts when attempting to place chest or furnace carts.
-Fixed vanilla bug where pets riding in Minecarts would constantly try to teleport to you, causing weird visual glitches.

Version 3.61

-Added Redneck Fishing.  Yeehaaaaa!
-Added the ability to throw unlit Dynamite if you don't have flint & steel in your inventory.
-Added the ability for dispensers (both vanilla and the Block Dispenser) to shoot dynamite.
-Changed the way stoked fire updates so that it more consistently stays stoked for a longer period.
-Changed the way the Cauldron and Crucible react to inventory state changes which should both improve the rate at which the Cauldron changes its visual inventory height, and resolves a problem in BTB where items wouldn't start cooking immediately upon being deposited in these blocks with a pipe.
-Changed the way Bloodwood Saplings self-plant so that only those dropped from leaves will do so.  This avoids a base-class modification, prevents a work-around where the player would drop Bloodwood saplings instead of planting them to avoid angering Pig men, and allows Planters containing soul sand to have a regular collision volume to fix problems with water flowing over them.
-Fixed problem with the bottom rows of the Crucible and Stewing Pot not being ejected when they are tipped.
-Fixed problem with not being able to cook anything in a Stewing Pot if it contained Foul Food and Dung.
-Fixed problem with Ropes and Anchors sometimes being destroyed on chunk-load if the associated Platforms were already in motion when the chunk was saved.  This may still happen one last time if your setups were saved with older versions of the mod, but should no longer happen with freshly saved chunks.  This involved changing a lot of the code for Pulleys & Platforms in order to increase reliability on chunk/save load so it probably resolved a number of related problems as well.
-Fixed problem with still being able to tell rabid wolves to sit after feeding them wolf chops.  Many wolves were harmed in the making of this feature...and how I laughed.
-Fixed problems with the Block Dispenser not being able to swallow glass panes, and not being able to place Wicker, Rollers, and Grates.
-Fixed problem with the Block Dispenser ejecting entities (arrows, eggs, etc.) in such a way that they skipped over the first block they would normally travel through.
-Removed ability to make clay blocks out of Nether Sludge.  Sorry guys, but I should have thought this one through better.  I have bigger plans for this in the future than fit with these conversions recipes, and I'd prefer to get rid of this now than break more people's automated systems down the road.

Version 3.60

-Added the ability to "tip" Stewing Pots and Crucibles by applying mechanical power to them.
-Added ability for the Bellows to blow light items that are in front of it.
-Added ability to have villagers follow you if you're holding a diamond.
-Added ability for cows to mutate into moosrooms with time if they are standing on mycelium.  This should largely remove the annoyance of transporting mooshrooms over long distances once you find a mushroom biome.
-Added ability for mushrooms planted on mycilium to grow into giant mushrooms with time.  This opens the door to the creation of giant mushroom farms.
-Added recipe to convert 4 Nether Sludge into a clay block.  Note that this applies to "clumping" with the Block Dispenser as well.  I'll be adding a separate Nether Sludge block once the extended block IDs become available, but in the meantime this will allow players to make Pottery out of Nether Sludge without consuming an additional block ID.
-Added a new type of Planter made with grass.  Flowers and Tall Grass will naturally sprout from these planters with time, and Planters filled with dirt will no longer sprout flowers in this manner (to help with various automation systems involving Planters).  Also, grass in these Planters will spread to neighboring dirt blocks with time, so these new Planters serve as a convenient method of transporting grass from location to location without relying on a silk touch enchantment or Block Dispenser.
-Changed the Detector Block so that it won't "see" blocks lifted by platforms while they are in motion.  This actually has some extremely handy uses, and in practice, feels more natural as well (since rails and redstone are very thin vertically).
-Changed the particle effect produced by the Bellows so that the particles blow in the direction the Bellows is facing.
-Changed Rope so that it can only be climbed by the player (not monsters or animals, except for spiders obviously).  This is both because it makes sense and gives a unique purpose to using Ropes in base construction, but also because it removes the need for the mod to modify EntityLiving.class, which increases compatibility with Optifine.
-Changed the texture for Foul Food so that it is more visually distinct.
-Changed rendering of Platforms and their associated blocks (anchors, ropes, lifted blocks, etc.) while in motion so that there is less of a visible transition between the moving and non-moving states due to lighting.
-Changed the lighting on the Wind Mill so that it looks better relative to the environment, and doesn't appear so dark at night.
-Changed the visuals on the Stewing Pot to more closely resemble the Crucible.  Looks cooler overall :)
-Changed the way the Mill Stone ejects items, so that they'll always fly outwards from the Mill Stone.  No more items landing on top and other weirdness :)
-Fixed problem with Block Dispenser picking up a dry shrub when attempting to pick up tall grass.

Version 3.59

-Updated to version 1.2.5 of Minecraft.
-Added support for jungle trees into the mod.  This includes things like growing them on Planters, and in front of Detector Blocks.
-Added the ability for sideways-facing Siding to transmit Turntable rotation to the block above.
-Added ability to overpower *any* mechanical device that is hooked up directly to a Wind Mill during a storm.  This generally results in breakage of the device, but it also opens up the possibility for other effects as it provides a general interface to do so for the eventual mod API.
-Added code back in for breaking attached Axles when a Gear Box is rotated on a Turntable.  I hated what that change in a recent release did to the mechanical system.  This applies to other mechanically powered blocks, like the Bellows and Saw, as well.
-Fixed splash-screen texts referencing the "Cauldron" instead of the "Stewing Pot".
-Fixed problem with being able to place lily pads on Planters.
-Fixed problem with Water Wheels & Wind Mills staying in place if the Axle they're attached to is rotated to an alignment that no longer supports them.
-Removed mod code for shift-clicking to the furnace, since that is now done in vanilla MC.

Version 3.58

-Updated to verstion 1.2.4 of Minecraft.
-Changed Blood Wood logs to craft into reddish planks (same as jungle trees).
-Changed the Saw to output planks of the appropriate color when cutting logs.
-Removed Mojang's new code for saving and loading the sit state of pets, as it was bugged and caused wolves to stand up when they weren't supposed to on chunk load.  I've reverted it back to the way it previously was, in which pets would always be sitting on load to fix this.
-Removed all trace of the juicy stuff I'm working on for the April 10th release, so don't bother looking :)

Version 3.57

-Added a separate block ID for Soulforged Steel so that it has its own unique (and rather interesting) properties.  Old blocks will need to be harvested and placed before they exhibit the new attributes.
-Fixed problem with netherwart constantly popping off of Planters.
-Fixed problem with Lens beams not properly propagating into the space in front of a Detector Block if that space was previously occupied by a block.
-Fixed problem with Lens beams not properly propagating through a series of Lenses spaced 1-apart if that beam was then interrupted by an entity.
-Changed creative mode functionality so that mod blocks from other mods don't automatically appear in the creative inventory, as it was causing a crash with Millenaire when the inventory was accessed.
-Changed the internals of the mod-block facing-code to better integrate with BC's Builders in BTB.

Version 3.56

-Added 2 extra inventory slots for rope to the Pulley to accommodate the new map height introduced in Minecraft 1.2.
-Added code back into the mod to prevent sitting wolves from standing to attack when their owner was attacked by a monster, or attacked one.  This was removed in a previous release due to the AI-rewrite in 1.2.
-Fixed problem with the Crucible not detecting stoked fire under it when it is first placed.
-Fixed problem with not being able to light fires in front of a Detector Block, or in a Lens beam, with flint & steel.

Version 3.55

-Added the ability to consume Foul Food.
-Added occasional subtle random creak sounds to Axles when powered to provide general ambiance to large mechanical devices.
-Changed Bloodwood Sapling recipe so that it now include a Jungle Sapling, and it is performed in the Cauldron instead of on a Workbench.
-Change Donuts so that they can always be consumed regardless of hunger level.  They're junk-food afterall.
-Changed tamed Wolves and Cats so that they always recognize the player in SSP as being their owner, regardless of whether it's the same player that originally tamed them.
-Changed pets (Wolves and Cats) so that they teleport *behind* the player instead of just randomly around when they are following you.  This should help prevent them from getting under-foot while you are walking around.
-Changed the sound of the Gear Box powering-up to be a creaking rather than a bang.
-Removed the Ocelot's ability to eat fish laying on the ground as it was causing bugs with untamed Ocelots entering breeding mode and was not an intentional feature.  I'll likely do something with this in the future, but for now they can only be fed by hand.
-Fixed problem with the player not having infinite enchanting levels in Creative Mode.

Version 3.54

-Fixed problem introduced in last release where the animal birthing process would no longer produce particles or sound effects.
-Fixed problem introduced in last release where animals wearing Breeding Harnesses could still move around.

Version 3.53

-Updated to version 1.2.3 of Minecraft.  WARNING:  This was a hellish update and it wouldn't surprise me if it introduced bugs.  Please make sure to backup your savegames before installing.
-Fixed problem with the Lens using the Slats texture when it projected a beam onto a solid surface.
-Fixed vanilla map-conversion crash-bug that would result from slabs at height level 128 on old maps.
-Removed many of the tweaks the mod made to wolf behavior due to the rewrite of Minecraft's AI system.  These will be readded to the mod (if necessary) in the future once the dust settles on the AI code.

Version 3.52

-Added Nether Sludge and Nether Bricks as new items.
-Added the ability to use the Lens as a light-level detector when used in combination with a Detector Block.  Just point a Lens directly at a Detector Block (in a neighboring block), and off you go!
-Added a placeable version of the Slats (see name change of Rollers below) that functions in the same way as iron bars or glass panes.
-Added ability to create Potash out of Blood Wood (1 to 1), and Saw/Soul Dust (16 to 1 ).
-Added the ability to shift-click items into the Anvil crafting-grid.  Also added this same functionality to the vanilla workbench, and furnace.  This should make mass crafting, particularly of storage-type blocks, much more convenient.
-Added the ability to render Ink Sacks into glue at an 8 to 1 conversion ratio.
-Added the ability to rotate the following blocks on the Turntable (if they have the correct orientations to make this possible): Anchor, Siding, Moulding, Corner.
-Added the ability for the Block Dispenser to spit out items into blocks that are normally "replaceable" (eg. water, lava, snow, etc.).  It should now eject items under the same circumstances under which it can place blocks.
-Added a separate texture for the top block of Hemp plants.  This is to allow texture-pack creators to create an independent image for the top, but I also made a slight change to the default texture to take advantage of this.  Note that this will only work if the tops of the plants are freshly grown; old tops will remain unaffected by this change.
-Added sheep running away when the player attempts to apply Dung to them.  They don't like that.
-Changed the name of the "Rollers" to "Slats", and changed the textures representing them to reflect this.
-Changed how the Block Dispenser places redstone repeaters so that they are always facing away from the Block Dispenser.  This is useful in employing the BD as a base-3 memory unit.
-Changed (reduced) the volume of the sound that clay and Unfired Pottery make when being rotated on the Turntable. This is to make the sound less overwhelming in large-scale automated setups.
-Changed the Mill Stone Gui to display its contents horizontally instead of vertically.  The vertical display was due to an old feature idea that got scrapped long ago, with the horizontal making far more sense for the way it operates.
-Fixed problem with the Block Dispenser not being able to place Blood Wood Saplings on Planters that contain soul sand.
-Fixed problem with water-flow not being able to transport items over Planters (those that don't contain soul sand...such planters will still stop item flow, just like with regular soul sand).
-Fixed problem with Water Wheels and Wind Mills catching fire due to being hit with flaming arrows, and displaying a huge flame sprite as a result.
-Removed the ability to use Foul Food as fertilizer.  Too much potential for abuse.
-Removed the ability to push Axles with pistons to prevent exploits involving the creation of infinite mechanical energy loops.

Version 3.51

Note: This release is NOT compatible with the 2.X versions of Better Then BuildCraft.  If you are using that mod, please upgrade to the 3.x branch of BTB.  A new release of BTB will be coming out shortly after this release of BTW to handle this incompatibility issue.

-Added magical visual effect to the Soul Urn.  Your lives are now complete.
-Added the ability for the output of one Lens to feed directly into the input of another.
-Added the internal FCIBlockClimbable interface for the upcoming mod API to provide add-on mods the ability to designate individual blocks as climbable by the player.
-Added internal functionality for getting and setting mod block facing based on a meta-data value to better interface with the BuildCraft Builder in Better Then BuildCraft.
-Added an internal hook to allow for the adding of multiple variations of the same item type to the creative-mode inventory to support Better Then BuildCraft.
-Fixed problem with Lens not lighting up the area around non-solid blocks when the beam first intersects with them.
-Fixed problem with the end point of a Lens beam being able to activate another Lens, even if the beam wasn't facing directly into the Lens input.
-Fixed problem with the Lens projecting onto a surface if there was an entity right next to that surface.
-Fixed the Hopper recipe to not work with stone Corners.
-Fixed problem with a Lens not registering that a beam feeding into its input was turned off if that beam was interrupted by a block.

Version 3.50

Note: This release is NOT compatible with the 2.X versions of Better Then BuildCraft.  If you are using that mod, please upgrade to the 3.x branch of BTB.  A new release of BTB will be coming out shortly after this release of BTW to handle this incompatibility issue.

-Added the Lens as a new block type (finally).  I'm not shitting you. I'm not trolling.  This is for really real time.
-Added a new variety of the Planter that may be created by placing soul sand in an empty Planter, instead of dirt (no bone meal is required).  This allows for the growing of netherwart and Bloodwood trees, but will not allow for maturation of these plants outside of the Nether.  Bloodwood saplings can plant themselves on these blocks just like with regular soul-sand.
-Added the ability to power mechanical devices with a Hand Crank sitting on top of them.
-Added internal hooks for the swallowing of BC pipes by the Block Dispenser for use in Better Then BuildCraft.
-Changed the way Wheat grows so that its growth rate will be at maximum if growing in a Planter, regardless of the status of neighboring blocks.
-Changed the Rollers recipe to use 4 Moulding instead of 9, to fit the recent changes to Wicker & Grates.
-Changed the size of the collision volume on a Hopper without a filter, to match that of one with a filter.  This resolves a number of issues with items falling through the cracks between blocks in certain setups, and makes Hopper behavior more consistent overall.  It should also now be possible to flow items over a Hopper with a filter in the same way as one without.
-Changed the way Urns render so that they appear directly beneath a Hopper if they are placed under one.  This makes the whole botteling of souls process look better and makes it a tad more intuitive.
-Changed the Planter with soil recipe to include bone meal in between the dirt and the Planter.
-Changed the Crucible so that overheating combustible ingredients within it will have the same unfortunate consequences as with the Cauldron.
-Changed the way the Detector Block handles the detection of wheat growth internally.  This is so that beams from the Lens aren't blocked by the block above fully gown wheat.  There should be no noticeable change to how this works with the 
DB, but I mention it just in case problems crop up.  Please let me know if they do.
-Changed the communication layer with Better Then BuildCraft to make future version of the two mods less dependent on each other.
-Fixed problem with Plate Armor not returning enough Soulforged Steel when melted down in the Crucible.
-Removed ability to convert Urns to Soul Urns within the Hopper inventory.  Now, the Urn MUST be placed beneath the Hopper in order to do this.  This is to avoid confusion with what is essentially duplicate functionality that was causing people to not even realize the process could be automated.  It also serves to encourage automation of the simplest portion of the overall process of creating Soul Urns which will hopefully lead to players deciding to undertake other aspects of it as well.

Version 3.492

-Added the ability to enchant Composite Bows.  Note that the infinity enchantment will only provide you with an infinite supply of *regular* arrows, not Broadheads.  It makes for a nice back-up though if you run out of Broadheads. Also, the requirement for an infinity bow to have a single arrow in your inventory to fire appears to be a bug in the MC code, rather than an intentional design-decision, so this requirement doesn't apply to the Composite Bow.  In other words, if you run out of Broadhead Arrows with an infity bow, it will always continue to fire regular arrows as a back-up regardless of whether you have regular arrows in your inventory or not.
-Added "magical arrow" render for arrows fired from infinite bows to help distinguish them visually, and make it less confusing as to why the arrows can't be picked up again after firing.
-Added ability for Broadhead arrows to receive the enchantment of the firing bow (again, with the exception of infinity).
-Added ability to pick-up arrow entities (arrows fired from bows) in the Hopper.  This applies to arrows regardless of their source (skeletons, dispensers...whatever), but not to the magic arrows described above that are fired from infinity bows.
-Added ability for Saws to harvest vines, just like shears.
-Added ability to cut fences into wood Corners with the Saw since you now tend to accumulate an excess of them while exploring mine-shafts.
-Added internal functionality for placing items with the Block Dispenser, both to act as an interface in the upcoming API, and to allow for placing BuildCraft Pipes in Better Then BuildCraft.
-Changed zombie pig-men and magma cube spawning so that they may only spawn on netherrack or netherbrick.  This allows the player to create bases in the nether that won't become occasionally infested with pig-men.  There's a config file setting to disable these changes if you desire.
-Changed the way the Hopper processes collisions with items internally, which should result in a slight increase to performance.  This should have no apparent effect, but let me know if any problems arise.
-Changed the Grate recipe to use 4 sticks instead of 9.
-Changed Gear Boxes so that they may be rotated on the Turntable withou breaking any attached axles (to match functionality of rotating by hand).
-Fixed problem with being able to apply a Breeding Harness to an animal that's already wearing one.
-Fixed problem with sheep regrowing wool while wearing a breeding harness.
-Fixed problem with colored wool not being converted into Glue in the Cauldron.
-Fixed problem with Blood Leaves dropping apples.
-Fixed problem with mechanical power distribution if you manually rotate a Gear Box that is neigboring on an Axle that has a Wind Mill or Water Wheel on it.
-Fixed vanilla bug with requiring the player's inventory to contain arrows when the bow has an infinity enchantment, to match the functionality of the composite bow.  See above for details.

Version 3.491

-Updated the mod to version 1.1.0 of Minecraft
-Changed Hardcore Bucket mode so that lava may no longer be collected in a bucket to avoid exploits involving using it as a fuel.  Attempting to do so will result in the player taking damage.
-Changed the Block Dispenser to be able to properly place and retract Blood Leaves.
-Changed shears to be effective vs Blood Leaves.

Version 3.49

-NOTE: This release is for Minecraft 1.0, NOT 1.10.  Don't bother asking.
-Added method of synthesizing redstone dust through metling down Concentrated Hellfire & golden nuggets in a Crucible.  Gold Bars may also be used if sufficient Concentrated Hellfire is present (requires 9 to 1).
-Added ability to rotate Axles and Gear Boxes by activating (right clicking) them with an empty hand.
-Added high-efficiency fence gate recipe using Moulding and a Siding.
-Added ability to render down saddles in the Stewing Pot for 3 Glue.
-Added ability for villagers to toss the milk.
-Changed the name of the Cauldron to the "Stewing Pot" to avoid confusion with the vanilla Cauldron.
-Changed picks to be effective against the Detector Rail Variants.
-Changed the Crucible recipes so that the creation of Steel always takes place before all other activities.
-Changed the Hopper so that Pipes don't suck the Filters out in Better Then BuildCraft.
-Changed the code for animal-breeding partner-selection to further reduce the likelihood that animals will ignore closer breeding partners for ones that are farther away.
-Fixed problem with the Kiln not resetting its cook state when its contents are switched.
-Fixed problem with Cement causing a crash if it spreads below the limits of the world (only applies to user-created maps without a bedrock layer at the bottom).

Version 3.48

-This is an emergency release to handle incompatibility problems between BTW 3.47 and BTB 1.01.  It will be immediately followed by a release of BTB (V1.02) for the same reason.
-Added internal functionality to facilitate communication between BTW and BTB and remove install-order depedency between the two mods.

Version 3.47

-Added functionality so that if you activate (right-click) Siding, Mouldings, or Corners with an empty hand, it will toggle the orientation of those blocks, allowing you to easily reallign them should the initial placement not be to your satisfaction.
-Added notifications so that the Buddy Block will react when a neighboring chest opens or closes.
-Added the ability to rotate chests on the Turntable.
-Added ability to transform Blood Wood into charcoal in both the furnace and Kiln.
-Added shapeless conversion recipes for stone Corners to Moulding, and Moulding to Siding.
-Added a mod installation integrity test to BlockFire so that the mod won't work at all if it isn't installed properly instead of just crashing at some unspecified point.
-Added internal functionality to toggle the facing of various mod-blocks to act as an interface with the BC wrench in BTB.  This is strictly an internal code change, but affects the following blocks: Anchor, Anvil, Axle, Bellows, Block Dispenser, Buddy Block, Companion Cube, Corner, Detector Block, Gear Box, Mining Charge, Moulding, Saw and Siding.
-Added click sound when switching timing settings on the Turntable to provide a little more feedback.
-Changed the Tallow texture to look like a bar, as I don't know what the hell it was supposed to look like before :)
-Changed wolves to drop cooked wolf-chops on death instead of raw if they're on fire.
-Changed (reduced) the number of planks that are produced when a Gearbox breaks, so that you can't profit from it when building them out of Siding.
-Changed (refactored) the mechanical power code internally to be more modular both to make BTB simpler, and for the upcoming BTW API.
-Changed (refactored) the refined tools code to consolidate the functionality that makes regular tools effective against particular blocks with that for the refined tools.  This is to aid in making tools effective against particular BTB blocks.
-Fixed problem with Buddy not powering down if it is pushed by a piston while in its on state.  This change will also cause Buddy to emit a redstone pulse when first placed, which makes sense given the way it operates (maybe also useful when used in combination with BD?).
-Fixed problem with the Saw breaking when various aesthetic blocks were placed in front of it.  This affects the Block of Wicker, Table, Wicker Slab, Grate pane, and Wicker pane.
-Fixed problem with saplings sending out neighbor notifications and setting off Buddy in the middle of their growth cycle.
-Fixed problem with Unfired Pottery sometimes not reverting to item form when pushed over an empty space by a piston.

Version 3.46

-Added the Refined Shovel and Long Sword back into the mod.  The Long Sword is now simply called the "Refined Sword".  Along with the following changes, this is intended to provide flexibility for people that wish to apply individual specialized enchantments to each of their tools, while retaining the ability to have general purpose tools for sane people like me that prefer that option :)
-Changed the Refined Pick to not work as a shovel, changed its icon back to what it previously was, and changed its recipe to use 3 iron instead of 4.
-Added the Mattock as a new item.  It replaces the dual pick/shovel functionality that the Refined Pick previously had.
-Added the Refined Axe as a new item.
-Changed the Buddy Block recipe to reflect the new 4X4 Anvil crafting.
-Changed the recipes for the Detector Block and Block Dispenser to both better fit the 4X4 crafting grid, and to represent the more complex internal circuitry you'd expect these devices to require.
-Changed the recipes for all the Plate Armor pieces to both look better in the 4X4 crafting grid, and to consume more Soulforged Steel overall.

Version 3.45

-Added the ability for the Block Dispenser to pick up the following block types without altering them: dirt with grass, book shelves, coal ore, lapis ore, diamond ore, redstone ore, giant mushroom blocks and Mycelium.  This should allow it to function similarly to tools with the silk touch enchantment.
-Added the ability for the Refined Pick to function as both a pick and a shovel.
-Added ability to melt down the Cauldron in the Crucible.
-Added high-efficiency piston recipe involving wood Siding instead of planks.
-Changed the Anvil crafting grid to be 4X4 instead of 3X3, and changed all the recipes associated with the Anvil to require the larger crafting grid.  This was done to resolve player confusion over which recipes require the Anvil as it will now be readily apparent from the recipes themselves, plus this method fits the overall vanilla design and tech-progression much better, and allows for much more costly recipes at higher tech-levels.
-Changed the following recipes to match the new 4X4 crafting grid of the Anvil: Refined Pick, Refined Hoe, Battle Axe, Armor Plate, Plate Helm, Chest Plate, Plate Leggings, Plate Boots, Broadhead Arrowhead, Stone Siding, Stone Moulding, Stone Corner, Obsidian Pressure Plate, Redstone Eye, Detector Block, Block Dispenser, Column, Pedestal, and Block of Soulforged Steel.  Almost all these items are now more expensive to produce to help balance their power.
-Changed wolf behavior so that they'll only lean their head at you if you are holding food and they are either hungry or wounded.  This provides a visual feedback mechanism as to when they need to be fed to supplement their whining. (Thanks to RaustBlackDragon for suggesting this!)
-Changed the Buddy Block internally for a slight increase in performance.
-Changed the Battle Axe to enchant as a weapon instead of a tool.  Who really bothers to enchant axes to begin with?
-Changed the Battle Axe so that it can cut through spider webs.
-Changed the way enchantment levels are (randomly) selected on the enchantment table.  First a maximum enchantment level is selected based on the number of bookshelves, capped by the player's current level (so that enchantments aren't displayed beyond the level currently possible for the player).  The top slot will always display a random value up to the maximum level possible, the second slot will display half the maximum level (rounded down), and third slot will always display the maximum enchantment level possible.  Additional fine-tuning can be achieved by placing or removing bookshelves (sticky pistons and/or Block Dispensers can be useful for this).  This should save the player a TON of clicking when attempting to enchant items to a particular level.
-Changed the Block of Soulforged Steel so that it can be melted down in the Crucible, but can't otherwise be broken up into individual bars through regular crafting.
-Fixed problem with the mechanical system that allowed infinite power loops to be created.
-Fixed the Hopper being able to place items on the potion brewing stand, as it was not intended to be able to do this.
-Fixed problem with being able to pick up Light Blocks in their lit state using silk touch.
-Fixed problem with shovels not being effective vs Unfired Pottery.
-Removed crafting recipes for the Refined Shovel and Long Sword, as their functionality is entirely integrated into the Refined Pick, and Battle Axe.  Your old items will still function, and can still be melted down, but these tools are no longer officially part of the mod.

Version 3.41

-Added a placeable version of the Wicker item, which functions like a glass pane.
-Added functionality for Blood Leaves to not render as translucent when the fast graphics option is enabled.  This unfortunately required the Blood Leaves to use their own block ID.  This change will only apply to leaves generated after this update is applied.
-Added leaf-decay to Blood Leaves.  This change will only apply to leaves generated after this update is applied.
-Added ability to fire throwable potions out of the Block Dispenser, just as with the regular dispenser.
-Added the ability for the Block Dispenser to "process" sheep.
-Changed the way mod blocks are added to creative mode internally to make it easier for me to add in new blocks with time and to provide a unified system for doing this once the mod API is released.
-Changed Wind Mills and Water Wheels so that their top can extend beyond the block height-limit (normally 128), without causing any problems.
-Changed vanilla animal breeding behavior so that animals will always select the *closest* animal already in love-mode to attempt to breed with.  This should prevent animals getting "stuck" trying to breed with an inaccessible animal when there is a more suitable partner nearby.
-Changed the Rollers Hopper filter to allow leather to pass through it.
-Changed Blood Wood Saplings to anger the residents of the Nether when you plant them.
-Changed Blood Wood Sapling growth so that they will not grow if they are up against the height-limit of the world.
-Changed Wind Mills and Water Wheels to be destroyed with a single hit from the player in creative mode.
-Changed Hopper Filters to properly filter all the vanilla items added in version 1.0.
-Fixed bug with nether wart being able to grow on Planters, when it's not supposed to be able to.
-Fixed a number of instances where an item would lose its enchantments when entering or exiting a mod-block's inventory (like with Hoppers).
-Fixed problem with Detector Blocks, Hoppers, and Buddy Blocks, sometimes failing to properly notify their neighbors of redstone state-changes.
-Fixed problem with the Saw breaking when double wood-slabs were placed in front of it.
-Fixed vanilla bug in creative mode that was causing weird results when attempting to break blocks near entities, as it was causing a lot of problem with Wind Mills and Water Wheels.

Version 3.40

-Added the Blood Wood Sapling as a new block type.
-Added Blood Wood as a new block type.
-Added Blood Leaves as a new block type.
-Added Soul Dust as a new item type.
-Added ability to burn Saw Dust as a furnace fuel.
-Added ability to cut wood slabs into Moulding using the Saw.
-Changed the Vine Trap block to be named "Aesthetic Vegetation" both internally and in the config file, since it is now sharing a block ID with Blood Leaves and Blood Wood Saplings.  NOTE: If you changed the value of the block ID on Vine Trap blocks in the previous release, make sure to update the names in your config file before loading an old world!
-Fixed problem where items ejected from destroyed mod blocks with inventories, would lose their enchantments.

Version 3.30

-Added the Vine Trap as a new block type.  Crafted with 3 vines in a row, mobs will think it's a solid block only to fall right through when they walk on it.
-Added the Breeding Harness as a new item.
-Added all the mod blocks to creative mode.  If you have any other mods installed, it should also display blocks from them as well.
-Added sounds and particles to the birthing of baby animals.
-Changed baby animals so that they can jump only half as high as adults.  This allows for separation of adults from babies in automated breeding facilities.
-Changed baby animals so that they won't eat loose wheat that's laying about.
-Changed wolves so that they will ONLY produce Dung when they have been fed.
-Changed wolves so that they will whine when they are hungry, not just when they are wounded.
-Changed (increased) the amount of XP dropped from villagers.
-Changed enchanting so that you can re-enchant an item that is already enchanted, losing the original enchantment in the process.
-Fixed problem with minecarts not running properly over the detector rail variants provided by the mod.
-Fixed problem with the Refined Pick Axe and Refined Axe not being effective against certain mod blocks.
-Fixed problem with Saws ignorning armor when damaging a player.
-Fixed problem with rope sometimes disappearing at certain viewing angles on top of a moving Anchor.
-Fixed flint and steel not producing fire in front of a Detector Block.
-Fixed nether portals not being able to form in front of a Detector Block.
-Fixed problems with occasionally being able to walk through the collision area of Wind Mills.
-Fixed problem with Platforms sometimes descending through other Platforms and destroying them.
-Fixed the straps of the Leather Vest not displaying over the shoulders of the player.

Version 3.27

-Added XP for slaying villagers.  In the battle against the Enderdragon, the souls of the innocent/barely-sentient are the most valuable of all!
-Added ability to feed animals by just throwing wheat on the ground near to them in order to help with automating breeding.
-Changed animals so that they will change the target of their affections if the desired animal has already bred with another.  This avoids confusion in group situations.
-Changed Wolves so that they won't move to attack a mob that has hit the player, if they are sitting.
-Changed wolves so that they will only eat loose food if they are hungry or wounded.
-Changed Cauldron recipe to have bone on top of the water bucket, as it is more intuitive that way.
-Changed the time it takes to update the Bellows, slowing it down by 1 tick (1/20th of a second), to avoid confusion due to some very fast timers only sometimes working with them.
-Changed axes to be effective against melons.
-Changed potions to increase their maximum stack size to 8.
-Fixed the growth rate of Hemp which was reduced to a quarter of what it should have been by a change to the way chunks update that Mojang made in 1.0.
-Fixed rate of flowers growing on Planters for the same reasons as above.
-Fixed size of collision area around Grates so that they are more like glass panes and iron bars.
-Fixed crash bug when attempting to plant seeds with the Block Dispenser.

Version 3.26

-Fixed problem with brewing stands crashing the game when opened.  ***WARNING***: This fix will delete the contents of Cauldrons already in your world.  Make sure to empty out your Cauldrons BEFORE installing this version, or you will lose anything they contain.  This was unfortunately necessary due to Mojang naming the tile entities for the Brewing Stand, as "Cauldron", creating a nasty conflict between the two block types that could only be resolved through resetting the tile entities on the Cauldrons, wiping their contents clean in the process.
-Fixed problem with Ropes not being climable.

Version 3.25

-Updated to version 1.0 of Minecraft.
-Removed support for the Forge.
-Added massive amounts of incompatibility with just about every mod out there!  This feature was added due to popular demand and so that players will no longer have to spend time worrying about what other mods to install!
-Added ability to enchant refined tools and armor.  Due to the inherently magical nature of Soulforged Steel, they have the same increased capacity to receive enchantments that gold does.
-Added a damage value to the Composite Bow, similar to that of the regular bow.  It has a durability of 1.5 times that of the vanilla bow.
-Changed the Buddy Block so that it doesn't react to changes in the invisible detection block in front of a Block Detector.
-Changed (reduced) damage on the Longsword so that it is the same as the Battle Axe.  However, the Battle Axe enchants as a tool, while the Longsword enchants as a weapon, making it a potentially much more effective dedicated instrument of mob dismemberment.
-Changed the Detector Block and Buddy to be solid blocks within the code and modified the redstone code to accept solid blocks as valid sources of power.  This allows stuff like torches to stick to the side of them despite the loss of the Forge functionality mentioned below, and also corrects a visual glitch where redstone wire running over the top of them wouldn't correctly appear to connect down the sides of the block.
-Changed (reduced) the amount of Tallow produced by beef, chicken, eggs, and wolf chops so that pork is by far the greatest source of fat in the game.  Each of those other foods will now require multiple units to produce a single unit of Tallow (with chicken and wolf producing the least fat of all).  This is to provide a specific purpose to farming pigs since they were no longer a very useful animal to keep around.
-Changed the Hibachi to no longer incinerate pistons, or piston arms, that are above it.
-Fixed problem with aesthetic blocks (like columns) not rendering properly when next to a Grate block.
-Removed the "axe tweaks" from the mod since vanilla now handles the axe versus various appropriate blocks on its own.
-Removed the refined pick-axe's particular effectiveness versus several vanilla blocs (like redstone ore), since vanilla now makes all picks effective against them.
-Removed the refined shovel's particular effectiveness versus soul sand, as this is now vanilla functionality.
-Removed ability to "stick" objects like torches and redstone wire to Siding and Tables.  Sorry guys, but this was a necessary side-effect of moving away from the Forge, as continuing to support this functionality would have required an inordinate number of changes to a large number of base-class files.
-Removed recipes to tan leather using wood logs, as these were a temporary measure to help correct the lack of wolves spawning in 1.8 (this has since been fixed in 1.0).
-Removed mod recipe for crafting pumpkins into pumpkin seeds, since that is now provided in vanilla Minecraft.


Version 3.22

-Added ability to grow mossy cobble.  Monster Spawners will now slowly (and I do mean slowly) cause any cobblestone within their vicinity to transform into mossy cobble with time.  This feature is specially dedicated to Battosay who has been waiting on it very patiently :)
-Added a block version of the Grate so that it can be placed just like glass panes or iron bars.
-Added the stone Moulding as a new block.  It's made on the Anvil with stone Siding.
-Added the stone Corner as a new block.  It's made on the Anvil with stone Moulding.
-Added seperate texture for the top and bottom of the Pedestal.  This won't be visible with the default mod textures, but was added to aid in texture pack creation.  My apologies, but it required a slight rearangment of the texture file to maintain the overall format.
-Fixed Mining Charge recipe involving slime-balls to produce the appropriate 2 Mining Charges instead of 1.
-Fixed Kiln outputting the block version of the Urn instead of the item version.

Version 3.21

-Added an abstract block type called "Aesthetique Opaque".  This allows for each of the following new blocks to be contained in a single block ID (as well as allowing for future additions):
-----------
-Added a Wicker block (made of 4 pieces of Wicker). There is also a recipe to convert Wicker Blocks back into Wicker.
-Added a Dung block (made with 9 pieces of Dung), along with return conversion recipe.
-Added a Steel block (made with 9 pieces of Steel), along with return conversion recipe.  Both recipes can only be performed on the Anvil.
-Added a Concentrated Hellfire block (made with 9 pieces of Concentrated Hellfire), along with return conversion recipe.
-Added a Padding block (made with 9 pieces of Padding), along with return conversion recipe.
-Added a Soap block (made with 9 pieces of Soap), along with return conversion recipe.
-Added a Rope block (made with 9 pieces of Rope), along with return conversion recipe.
-----------
-Added an abstract block type called "Aesthetique Non Opaque".  This allows for each of the following new blocks to be contained in a single block ID (as well as allowing for future additions):
-----------
-Added a block version of the Urn.  This allows the Urn to be placed *beneath* a powered Hopper in order to collect the souls coming out of it to aid in the automatic production of Soul Urns (the old method of putting the Urns directly in the Hopper also works). 
-Added the Column as a new block type, made using three smooth stone in a vertical line, on the Anvil.
-Added the Pedestal as a new block type (it can face upwards or downwards), made with three smooth stone in a horizontal line with another just above in the middle slot, on the Anvil.
-Added the Table as a new block type (3 Siding above 2 Moulding).  Table legs will reposition themselves to conform to neighboring Tables.
-Added a Wicker slab (made from 3 pieces of Wicker as per the standard slab recipe, or by cutting a Wicker block in half with a Saw).  There is also a recipe to convert Wicker Slabs back into Wicker.
-----------
-Added high efficiency chest recipe using wood Siding.
-Added a recipe to convert Wicker back into sugar cane.
-Added ability to melt iron bars in the Crucible at an 8 to 3 conversion ratio.
-Changed Unfired Pottery to require a solid surface beneath it or it will revert into item form.  This is to aid in automatic production, as you can now easily push it off the Turntable with a piston to convert it to an item.
-Changed the Saw to produce 4 planks and 2 units of Saw Dust whenever it cuts a log.
-Changed the Mining Charge so that it may be indirectly powered by redstone.
-Changed the Mining Charge recipe so that it outputs 2 Mining Charges instead of 1.
-Changed the Dynamite recipe to use three pieces of paper instead of one (all along the left side).
-Changed the pitch and volume of the click the Block Dispenser makes when it can't dispense a block or item so that it's less annoying.
-Changed Wicker recipe to only require 4 sugar cane instead of 9.
-Changed Nethercoal recipe to only require 1 unit of Hellfire Dust, and 1 of Carbon Powder.
-Fixed mechanical devices sounding weird due to Mojang's new explosion sounds.

Version 3.20

-Added the Mining Charge as a new block type.
-Added Dynamite as a new item.
-Changed the way the Block Dispenser updates so that it will more reliably respond to rapid changes in redstone state.  This should improve its usability as a ROM, and make it easier to work with in combination with Buddy.
-Changed the Buddy Block to introduce a minimal delay (1 tick or 1/20th of a second) before powering up when it detects a change to fix problems with certain blocks (like ladders) being placed next to its output side.
-Changed Hand Crank so that it can be placed on top of the Buddy Block, and so that it only sends out update notifications when it powers on and off.
-Changed the Detector Block so that you can stick stuff to the sides and top of it (torches, minecart rails, redstone wire, etc.)
-Changed Saw Dust, Potash, Soap, Redstone Eye, Filament, & Hardboiled Eggs to be properly filtered by Hoppers.
-Changed Siding so that you can stick stuff to the solid side of it.
-Fixed problems where Urns that were in mid-flight when a game was saved, and reloaded, would dissapear.

Version 3.10

-Added the Buddy Block which acts as a BUD (block update detector) with a uni-directional redstone output (facing determined on placement).  The recipe consists of Redstone Eyes (1 on each side), smooth-stone (in each corner), and redstone dust (in the center).
-Added high-efficiency ladder recipe using Moulding, and a book shelf recipe using Siding.
-Added ability to convert Sticky Pistons back into regular pistons by heating them in a Cauldron with Soap (at a 4 to 1 piston/soap ratio).
-Changed Composite Bow to have a draw-time similar to how the vanilla bow functions as of 1.8.
-Changed the Turntable to notify neighboring blocks when it rotates, or when blocks on top of it rotate.  This is to allow the Buddy Block to be used in counting Turntable rotations (particularly useful in automating the spinning of Pottery).
-Changed the way saplings grow into trees so that wood and leaf blocks properly notify their neighbours when they come into existence.  This is so that they work properly with the Buddy Block, and Saws.
-Fixed a problem with player taking damage while riding a minecart on a descending Platform.

Version 3.0

-Added features that bring the mod into the New Age!  The moment you've all been waiting for is finally here, but I won't rob you of the pleasure of discovering it for yourselves :)
-Changed the amount of damage Wind Mills and Water Wheels can sustain so that they are much more resistant to attack.
-Fixed problem with Hardcore Buckets mode being enabled by default unless the config file for the mod was installed.
-Fixed the Plate Helm returning only 5 Steel when melted in the Crucible instead of the proper 6.
-Fixed problem with the Block Dispenser not being able to eject items when powered the way it's supposed to.
-Fixed power transfer problems when Wind Mills and Water Wheels were destroyed in cases where they are directing mechanical power in two directions simultaneously.  This was causing some axles to break at odd times when the attached power-source was destroyed.
-Fixed problem with vines not being able to grow in front of Detector Blocks.

Version 2.99

-Added Wool Slabs, both as an aesthetic block and as a method of providing color-coded off-bits when using the Block Dispenser as a ROM.  They are fully functional with regards to the various dying methods in vanilla Minecraft and the mod, and may be created using the same standard "3-blocks in a line" recipe used for other slabs in the game.  They can also be created by placing a wool block in front of the Saw.
-Added optional "Harcore Bucket" mode (off by default...can be turned on in the config file).  This basically prevents the player from being able to transport water & lava source blocks and is a mode intended to make fluid flow (and by extension, the generation of mechanical power) far more interesting without causing additional performance overhead, by requiring the player to actually build canals and such to have access to liquids.  Give it a try and let me know what you think.
-Added Hard Boiled Eggs as an item.
-Added ability to render eggs into Tallow at a 4 to 1 conversion ratio.
-Added Potash as an item.
-Added Soap as an item.
-Added Saw Dust as an item.
-Added the ability to smelt ore and produce charcoal in the Kiln.
-Changed the number of wood planks produced when using the Saw on a log to 5 instead of 6.
-Changed the Hopper "filler" item to be brick instead of clay balls.  This is to aid in automating production of Pottery.
-Changed Unfired Pottery to no longer use a tile entity.  This means that it can now be pushed by pistons.
-Changed the Kiln to be an actual block.  This change is invisible to the player but allows the Kiln to be far more flexible in its functionality.  Unfortunately, this has also required changing the time it takes Pottery to cook and may mess with existing auto-Kilns as a result.
-Changed high-efficiency Saw recipe for the sign to use 1 Moulding and 1 Siding.
-Changed amount of Rotten Flesh required to render into glue from 2 units to 4.
-Changed trap door filter on the Hopper to allow narrow objects (bones, arrows, sticks, etc.) to pass through (instead of items that stack up to 64) as the old functionality was no longer really useful with the changes made to stack sizes in 1.8.
-Changed the Hopper filters to properly process new items added in 1.8 (pumpkin/melon seeds, ender pearls, etc.).
-Changed the way the Hopper processes items slightly (a larger refactor is coming for the API), so as per usual with such changes, let me know if you spot any oddities with the Hopper filters over the next little while.
-Changed the Wicker and Rollers Hopper filters to not allow Ink Sacks to pass through (they previously could because the Minecraft code considers them to be "dye powders").
-Changed the Block Dispenser to be able to pick-up vine blocks and tall grass.
-Changed the Block Dispenser to place clay blocks if it contains 4 or more clay balls to aid in the automated creation of Pottery.
-Changed the Block Dispenser to have 16 inventory slots instead of 9 to facilitate its usage as a ROM.  This also makes some sense considering the BD doesn't really have any kind of internal mechanism taking up space, unlike the regular dispenser.
-Changed the Axle recipe to be horizontal instead of vertical, as it's far more intuitive.
-Fixed problem with the Saw cutting saplings when it's not supposed to.  Also applied this to Melon & Pumpkin stems.
-Fixed problem that would sometimes cause Stoked Fire to periodically go back to being regular fire even though it was being continually blown upon by the Bellows.  Stoked fire should be much more consistent as a result.

Version 2.98

-Fixed problem with non-Steel tools not being able to harvest various mod-blocks and redstone.  This major bug is the main reason for this small release.
-Fixed problem with Hemp Fibre-based Filament recipe producing 2 Filaments instead of 1.

Version 2.97

-Added ability to throw Urns, and fire them out of dispensers & Block Dispensers.
-Added ability to convert cobblestone to smoothstone in the Crucible.
-Added ability to turn sand into glass in the Crucible.
-Added ability for the Block Dispenser  to pick up and place whole melons.
-Added ability to render rotten flesh into Glue (requires 2 units of flesh).
-Added ability to render chicken and steak into Tallow.
-Added ability to block with ALL the refined tools (Long Sword, Battle Axe. Refined Pick, Refined Shovel) EXCEPT the Refined Hoe (since right-clicking is required for tilling).  This should make blocking more interesting as it gives you an option should you be surprised by a monster with a tool other than a weapon in your hand.
-Added ability to fire Broadhead Arrows out of vanilla dispensers.
-Changed the Kiln so that it can be constructed out of 4 brick blocks instead of 5.  This means you can now have two sides open on a Kiln to aid in automation.  As always, the block at the bottom of the Kiln MUST be brick.
-Changed Cement recipe to be produced in a heated Cauldron, and to consist of 1 block of sand, 1 of gravel, a bucket, and a Soul Urn.
-Changed name of 'Steel' to 'Soulforged Steel'...for real this time :)
-Changed Steel recipe in the Crucible to produce 1 piece of Steel for each piece of iron, Carbon Powder, and Soul Urn.  This makes Steel a lot harder to initially produce, but given that you can remelt it indefinitely, is a fair balance IMO and makes it much more satisfying to create your first full set of Steel equipment and encourages automation of the process.
-Changed priority of filament recipe in Cauldron so that Filament are always made first when possible, before converting string into wool.
-Changed the Saw to be able to handle a variety of materials that should prevent it breaking in odd circumstances.  This allows it to handle stuff like sawing pumpkins and melons, amongst other things.
-Changed foul food to work on pumkin stems, melon stems, and mushrooms as fertilizer.
-Changed the way the Block Dispenser creates particles when destroying a block, which will hopefully resolve a problem with them hanging around when the BD is used in massive numbers.  Let me know if the problem persists.
-Changed the 3D model for the unfired Urn to give it a top.
-Changed recipe for the filament to produce 1 unit instead of 2.  Sorry guys, but it was severely devaluing glowstone dust.
-Changed recipe for the filled Planter to no longer include a water bucket so that they can be mass-crafted.
-Changed companion cube being ground in Mill Stone to eject string and red dye only after it has been completely ground down.  No more soul-damning string grinding :)
-Changed the name of Polished Lapis to the "Redstone Eye", moved its recipe to the Anvil, and changed the recipe to require 5 pieces of lapis (top and middle rows), one piece of gold (middle square), and one piece of redstone dust (bottom row) to produce 2 eyes.
-Moved the Detector Block recipe to the Anvil.
-Changed the Block Dispenser recipe so that it could only be made on the Anvil.
-Changed the Axe Tweaks to use the Forge tool system and removed the option to disable them from the config file since they should no longer cause incompatibility problems as a result of this change.  This should also allow axes from other Forge mods to take advantage of the axe tweaks as well, and be effective on BTW blocks.
-Changed the refined Pick, Shovel, and Battle Axe to all use the Forge tool system.  This should extend their usefullness to blocks from other Forge mods (*if* they use the system as well).
-Changed picks to be effective against Siding (both stone and wood since they share the same blockID).
-Changed Refined Pick to be effective on all mod-blocks that normally require a long time to remove (such as the Block Dispenser), and to be effective on some vanilla blocks that function similarly as well (such as the furnace, regular dispenser and stone stairs).  Let me know if I missed any.
-Changed axes to be effective against melons and fence gates.
-Changed the refined shovel to be effective on Soul Sand.
-Fixed the hit-box around the 3D model of the unfired Urn to match its shape.
-Fixed problem that caused tanning leather to require 16 normal wood instead of 32, as intended.  The process requires 16 dark wood, 32 normal, or 64 birch, given that darker barks generally contain more tannin.
-Fixed problem with the Hopper not handling a large influx of souls properly, and only creating 1 Soul Urn when it should have created more.
-Fixed problem with melon or pumpkin stems growing on planters being able to overwrite occupied neighbouring blocks with the melons they produce.
-Fixed the way Detector Blocks detect arrows to prevent various kinds of odd behavior.
-Fixed problem with not being able to pick up arrows and Broadhead Arrows fired out of a Block Dispenser.

Version 2.96

-Added the Urn as an item (a new form of pottery).
-Added the Soul Urn as an item.
-Added Polished Lapis (created with 4 pieces of Lapis and sand within a heated Cauldron).
-Added recipe to convert pumpkins into pumpkin seeds, since it is coming in 1.9 anyways and will allow people to start working on their farms now.
-Added ability to grow pumpkins and melons on Planters.
-Added ability to melt down glass panes into glass blocks in the Crucible at an 8 to 3 ratio.
-Added *temporary* tanning recipes using wood (logs) instead of dung to simulate the creation of tannin out of bark.  The darker the wood, the less is required.  This is a temporary measure since wolf-spawning seems to be so infrequent to non-existant in 1.8, which I'll leave in place until that gets fixed/changed.  If it remains this way, I'll come up with a more permanent solution.
-Changed Detector Block Recipe to use Polished Lapis instead of regular lapis for the eyes.
-Changed Saw to output 6 wooden planks (instead of 4) when processing a wood block.  This makes the Saw a MUCH more efficient solution for cutting down trees than an axe.
-Changed Filament recipe to require either a Hemp Fiber or a String.
-Changed stone Panel (Siding) recipe (on the Anvil) to produce 2 Panels instead of 1.
-Changed Obsidian Pressure Plate to only be craftable on an Anvil.
-Changed Block Dispenser recipe to require a Soul Urn in the centre.
-Changed the name of "Coal Dust" to "Carbon Powder" to avoid confusion with similar items from other mods.
-Changed the name of "Panels" to "Siding" to avoid confusion with similar items from other mods.
-Changed the name of "Steel" to "Soulforged Steel" to avoid confusion with similar items from other mods...and because it contributes significantly to Steve's moral degradation to be making his equipment out of tortured souls.
-Changed Hand Crank to cause exhaustion when operated (equivalent to jumping 4 times).
-Changed Planter so that it won't sprout flowers next to a stem, to prevent interfering with melon and pumpkin farming.
-Fixed problem with Nethercoal and Coal Dust not working properly as furnace fuels.
-Fixed problem with Steel recipe only outputting 1 unit instead of 4.
-Fixed problem with damaged items not being able to be melted down in the Crucible.
-Fixed problem where ingredients added one at a time to a Crucible or Cauldron would not always start the cooking process when the correct number were finally added.
-Fixed crash when shift-clicking to a full inventory with various mod-blocks.
-Fixed problem with dropping duplicate ghost-items when closing the Anvil crafting-grid.

Version 2.95

-Updated to version 1.81 of Minecraft.  Note that a few items in the mod still need to be adjusted to work with the new systems (like the Composite bow, and proper Hopper filtration of the new items), but everything should be functional.
-Added Padding as an item (Fabric + feather).
-Added Filament as an item (glowstone dust + redstone dust in Cauldron).
-Added recipes to convert Fabric and Rope back into Hemp Fibers for storage purposes.
-Changed the recipe for the Armor Plate to require padding (placed right below the Steel).
-Changed the recipe for the Light Block to use a Filament instead of glowstone dust, and glass panes instead of glass blocks.
-Changed the recipe for the Hibachi to use a Filament instead of glowstone dust.
-Changed Hemp to ONLY grow under Light Blocks if they are underground.  No more growing it under pumpkins :)
-Changed the Crucible over to use the same generic recipe system I introduced for the Cauldron in 2.93.  As before, please keep a close eye on the Crucible and what it is outputting, and please let me know of any problems, as this was a rather large refactor of the way the code for it works and errors could have easily been made.
-Changed the rail to iron conversion in the Crucible to 8 to 3 instead of 16 to 6.  Please forgive my lowest common denominator fail :)
-Fixed problem with the Battle Axe only returning 3 units of Steel when melted down in a Crucible, rather than 5.
-Fixed problem where Planters that didn't contain soil could sprout flowers.
-Removed recipe to convert two Hemp Fibers into string.  Sorry guys, I didn't like it as it blurred the lines between what was spider silk, and what was Hemp within the game, and opened up a whole can of worms design-wise with regards to what could be done with one and not the other.  Besides, there's now a peaceful source of string with webs.


Version 2.94

-Added ability for the Detector Block to see Broadhead Arrows.
-Added ability for Block Dispenser to fire Broadhead Arrows (will apply this to regular Dispenser in the future too).
-Added ability to render leather armor in the Cauldron.
-Fixed problem with flour-based cake recipe.
-Fixed problem with Saw not being able to be placed facing upwards or downwards.
-Fixed Block Dispensers ability to fire regular arrows.

Version 2.93

-Added the Anvil.
-Added the Armor Plate as a new item.
-Added Plate Helm, Plate Breastplate, Plate Leggings, and Plate boots as new items.
-Added the Composite Bow.
-Added Broadhead arrow heads, and Broadhead Arrows.
-Added Coal Dust as an item (which can be made from both coal and charcoal)
-Added ability to cook Coal Dust & Hellfire Dust in the Cauldron to create Nethercoal (and removed the old crafting recipe to create Nethercoal).  1 unit of Coal Dust & 4 units of Hellfire Dust are required to create 2 pieces of Nethercoal.
-Added alternate recipe for the Gear Box using wood Panels instead of wood blocks.
-Added ability to melt down rails in the Crucible at 16 to 6 rail to iron conversion ratio.
-Added an option to the config file to disable the mod's minecart tweeks.
-Added ability for Detector block to "see" fully grown wheat occupying the block to the front and below it.
-Added ability for the Crucible to pick up loose objects on top of it.
-Added ability for items to flow over the top of the Cauldron if they can not be swallowed by it (same thing applies to the Crucible).
-Added ability to dye wool in a heated Cauldron at a ratio of 8 wool to 1 dye.
-Added ability to grind flowers in the mill stone to produce dyes.
-Added ability to cook cactus in the Cauldron to produce green dye.
-Added ability to cook sand and gunpowder into TnT in the Cauldron (complete with hazards).
-Added ability to cook string into wool.  I'm not sure if this makes much sense, but neither does crafting spider silk into wool to begin with and I was sick of having to manually craft string into wool to save on storage space.  Insert magical explanation for what happens to giant-spider-silk when you cook it here :)
-Added ability to render string and wool into glue, but it takes rather massive quantities.
-Added ability for Planters to sprout flowers if left alone without anything planted in them for a long while.
-Added recipe to make torches out of Nethercoal.
-Added Forge version checking.  A descriptive error message will now be displayed if you are using an inappropriate version of the Forge with BTW.
-Changed name of the Refined Axe to the "Battle Axe" and increased the damage it does to mobs.  The recipe also requires 2 more steel than previously (for the double head).  It is now a combination tool/weapon (although not quite as effective as a Longsword as a weapon).
-Changed axes to be effective against cactus.
-Changed Detector Block recipe to use two pieces of lapis (NOT blocks) for the "eyes", instead of 1 block of lapis.
-Changed Cauldron to only produce foul food after the normal cooking time has elapsed (it's no longer instantaneous). This was part of the optimization process involved in the rewrite of the Cauldron code detailed below.
-Changed explosion size when overheating explosive elements in the Cauldron to be proportionate to the quantity involved.
-Changed Steel recipe in Crucible to require Coal Dust and Concentrated Hellfire instead of Nethercoal (this recipe will likely change once again in the future).
-Changed the Hopper filters to work properly on the newer items that I've added to the mod.
-Changed Hibachi recipe to require a piece of glowstone dust in the middle instead of smooth stone.
-Fixed the bouncing on items when they are resting on a filtered Hopper.
-Removed crafting recipe to convert Concentrated Hellfire into Hellfire dust.  This was just a debug recipe I accidentally left in the last version.
-Removed ability to grind stone into panels in the Mill Stone, and moved that functionality to the Anvil.  This will likely not be their final resting place in the tech-tree, but it's certainly better than them being in the Mill Stone.
-Removed delay for items being picked up on top of the Cauldron.
-Rewrote a lot of the Cauldron code to better structure it and make it easier to add new recipes.  I mention this so that players can keep an eye out for any problems that may arise with this functionality.  Please let me know if you spot any issues.
-Integrated Version 1.06 of the Forge, and eliminated a few base-class changes as a result.  Note that 1.06 or later is *required* for this release of the mod to function

Version 2.92

-Added Ground Netherrack, Hellfire Dust, and Concentrated Hellfire as items.
-Added soul sand as a filter to the Hopper.
-Added Wind Mill Sail recipe using wood blocks instead of Moulding.
-Added a shapeless recipe for twisting two Hemp Fibers into a string.
-Added ability to grind bone into bone meal in the Mill Stone.
-Changed Nethercoal recipe to require Concentrated Hellfire instead of Netherrack.
-Changed Hibachi recipe to use Concentrated Hellfire instead of Netherrack, and remove the flint (replaced by smooth stone).
-Changed Belt recipe to use 4 Straps instead of 8 (placed in a diamond pattern).
-Changed Hopper recipe to use two wood Panels and a Corner (for the bottom) instead of wood blocks.
-Changed The Saw to no longer be powered using a Hand Crank.  It must receive continuous power from an axle to function properly.
-Changed The Turntable to no longer be powered using a Hand Crank.  It must receive continuous power from an axle to function properly.
-Changed Bellows to only produce stoked fire over a lit Hibachi.  All other fires will be blown at by the Bellows now.
-Removed recipes for Wood Blade (used in Water Wheel construction) using wood blocks.  They can only be made with wood Panels now.
-Removed grinding wool into string in the Mill Stone (sorry guys, it screwed up the early game when working towards your first bow, and didn't make much sense anyways).
-Removed recipe for Bone Meal plus a white Vase producing a white Vase (since it was totally useless).
-Changed the mod to use the Forge system for handling textures.  On the bright side, this means that this mod now has infinite texture indices for maximum compatibility with other mods.  On the down-side, this means that existing texture packs for the mod will no longer work until they are adpated to the new system.  My sincere apologies for the inconvenience this reperesents, but the decision to make this change is in the long-term best-interest of the mod.
-Along with the above, did a lot of texture work on the mod.  You should notice quite a few subtle visual improvements.
-KNOWN BUG: Currently textures will not be displayed properly on mod-blocks when they are pushed by pistons.  This will be corrected with the release of the next version of the Forge.
-Removed "fcUseDefaultLightTextures" from the mod's config file as it was no longer really relevant anymore with the custom texture packs that exist for the mod, and complicated the switch to the Forge texture system unnecessarily.
-Fixed problem with cement "battling" with water it comes into contact with.  Cement now beats the crap out of water (and lava) without even breaking a sweat, and leave in crying for its mommy (could be useful for underwater construction or filling in lava pits).
-Fixed problem where Hibachi wouldn't immediately extinguish Stoked Fire above it when turned off.
-Fixed problem where pottery couldn't be formed if not placed immediately above a Turntable.
-Fixed problem where Vases would lose their color when swallowed by a Block Dispenser.
-Fixed problem where blocks swallowed by Block dispenser wouldn't display properly textured hit effects for certain block-types (like colored wool and Vases).
-Added flying cows and rabbits that can be worn as hats.

Version 2.91

-Added alternate recipe for cake using Flour instead of unprocessed wheat.
-Added ability to melt-down various items in the Crucible.
-Added custom rendering effects to the Crucible.
-Added Pottery sloughing off clay as it is formed.
-Changed Hopper to not delay when picking up items dropped by the player.
-Fixed problem with Planters where plants could be planted on them in their default state.
-Fixed problem with Block Dispenser not being able to swallow powered cake.
-Fixed problem with Crucible consuming incorrect amounts of iron when multiple stacks were present in its inventory.
-Fixed problem with Crucible not dropping its contents when it is destroyed.

Version 2.90

-Added a pottery system.
-Added a ton of other stuff I'll let you guys figure out on your own :)
-Added support for the Minecraft Forge.  Note that you will now have to install the Forge for the mod to function.

Version 2.82

-Added alternate fence recipe using Moulding.
-Added alternate wood stairs recipe using Moulding.
-Added alternate sign recipe using wood Panels.
-Added alternate door recipe using wood Panels.
-Added alternate trap door recipe using wood Panels.
-Added alternate recipe for the Wood Blade using wood Panels instead of wood blocks.
-Removed some trailing spaces after the fcGrateID line in the mod's config file to fix a problem with all settings after that line not being read by the game.  ****WARNING****: This change may invalidate some save-files IF you had previously reassigned the values that were not being read properly.  In order to get around this, you'll need to use the default values for item ID's for lines after the one mentioned above, since this is what your save was previously using.
-Added code to ignore spaces in the config file to prevent the above kind of problems ever occurring again.
-Fixed problem with mod blocks with inventories ejecting their contents in such a way when they are destroyed, that the resulting items sometimes become stuck in neighboring blocks.  This still occurs with vanilla blocks however (like the chest).
-Block Dispensers now destroy the inventory contents of any other Block Dispensers they swallow to prevent exploits involving this behavior.
-Fixed problem with Bellows not expanding if the Axle powering it was destroyed.
-Fixed problem with player falling down through the block below if minecart he was riding was swallowed by a Block Dispenser.
-Fixed problem with scaling of textures on the switch for the Turntable.
-Made a number of changes to the mod's code structure to make it *less* dependant on the world.class (fd.class in 1.7.3).  This should reduce (not eliminate) the number of problems that people experience with the mod if they overwrite this class with one from another mod (like ShockAhPI, the Aether or MC Extended).
-Fixed problem with the Saw occasionally breaking when trying to cut blocks pushed by pistons.
-Fixed problem with regular torches sometimes rotating improperly on the Turntable.
-Fixed bug with Block Dispenser being able to pick up ice blocks.
-Changed Companion Cube to eject red dye when ground in Mill Stone as opposed to red wool.

Version 2.81

-Added custom icons for Glue and Tallow.
-Fixed problem with stoked fire returning to normal too quickly over a Hibachi.
-Reduced volume of sound-effect when Gear Box powers up.
-Cleaned up the Block Dispenser facing code.  This should correct a number of problems with the facing of dispensed blocks.
-Changed the way rendering works in the Cauldron so that time spent rendering does not translate into time spent cooking, and vice versa.  Also provided the rendering process with a "cooldown timer" so that if the fire beneath the cauldron is not stoked momentarily, rendering progress won't be immediately lost (although it won't progress during this time either).
-Changed a few things about the way stoked fire behaves so that blocks can be placed in it, and it will go out if the player hits it (just like regular fire).
-Added the ability to turn the Water Wheel by dropping water along its sides,
-Bellows now lift entities that are resting on them when they expand.

Version 2.80

-Added the Bellows.
-Added Glue.
-Added Tallow.
-Added the Haft.
-Added alternate recipe for the Wood Blade using Glue instead of goo balls.
-Added alternate recipe for the sticky piston using Glue instead of goo balls.
-Changed the Turntable recipe to use wood Panels instead of wood.
-Adjusted the visual offset of the Turntable switch to be aligned with the markers on its texture.
-Fixed problem with Gear Boxes attached to Wind Mills still sometimes breaking after rain had stopped.
-Removed changes to BlockPistonBase class and moved the code in question elsewhere for the sake of compatibility with piston mods.
-Corrected orientation problem when placing Pistons with the Block Dispenser.
-Increased the size of a couple of arrays in the modified BlockFire class to avoid incompatibilities with MC Extended.

Version 2.71

-Added the Wood Blade as an item.
-Changed Water Wheel recipe to require Wood Blades instead of wood, and to get rid of gear in centre.
-Changed Wind Mill recipe to get rid of gear in centre.
-Reduced the number of settings on the Turntable from 11 to 4 (.5 seconds/1 seconds/2 seconds/4 seconds).
-Reduced the height to which the Turntable rotates blocks above it from 12 to 2.
-Changed the Turntable recipe to replace the Axle with Redstone, and the Redstone with a Gear.
-Fixed problem with repeater always setting its delay to 4 when rotated by the Turntable.
-Fixed a rather major bug in the Detector Block logic that was introduced within the past couple of versions and which was causing it to malfunction under a wide range of circumstances.
-Fixed problem with upwards-facing Detector Blocks taking up to 5 seconds to detect something in front of them.


Version 2.70

-Added the Turntable.  Let the good times rotate!
-Added Rollers as a new item that acts as an additional filter-type in the Hopper.
-Changed Axle to drop sticks when destroyed, instead of wood, since it can now be crafted using Moulding.
-Changed rope to set an upwards facing Anchor into motion when a Pulley causes the rope to descend on the Anchor.
-Changed placement code for Water Wheels and Wind Mills so that they can not extend beyond max-height (128) in the world.

Version 2.66

-Updated to version 1.7.3 of Minecraft.

Version 2.65 (Unreleased)

-Added ability for Minecart Rails (of all types) and Redstone Wire to be lifted by Platforms.  Note that sloped-rails can not be lifted in this manner and will break if you attempt to do so.  Also, redstone is non-functional while in transit and its shape will change to reflect this.
-Added alternate recipe for Axle using Moulding instead of Wood blocks.
-Restored the ability to "stick" objects (like torches) to the Companion Cube.
-Increased the amount of iron used in the Cauldron recipe to be more consistent with other full-block recipes in the game (2 extra ingots fill in the empty spaces at the top of the Cauldron recipe).
-Fixed a few problems with pistons interacting with the empty space directly in front of a Detector Block.
-Changed moving Platforms and Anchors to break when pushed by pistons to correct a number of problems that this behavior caused.
-Fixed problem with Water Wheels and Wind Mills occasionally duplicating when the axle they were attached to was pushed by a piston.
-Fixed problem with Axles remaining powered after being pushed by pistons, when they shouldn't be powered in their new location.
-Fixed problems with Hibachis being pushed by pistons and not updating their state properly.
-Fixed problem with Light Block not updating properly when pushed by piston.  Note that this involved introducing a small delay (1/10th of a second) between when a Light Block is powered and when it actually lights up, so it may affect existing circuits in a *very* minor way.
-Made changes to Mojang's wolf-code so you can still order them to follow you even if they glitch out and don't recognize you as their owner.  HOWEVER they will likely still not attack your targets and such, as fixing that would require modification of another base-class.  Note: These bugs are entirely Mojang's, I'm just trying to help people out by fixing them up a bit.
-Fixed problem with sand and gravel not always falling properly through the empty space in front of a detector block.
-Changed the way moving Platforms handle collisions to prevent the player occasionally going through them when they stop.
-Changed the way Cauldron renders to fix some slight visual glitches.
-Fixed entity duplication bug with the Block Dispenser.
-Changed Block Dispenser to be able to place and swallow leaf blocks.
-Changed moving Platforms and Anchors to destroy Water Wheels and Wind Mills that they pass through.
-Fixed problem with Block Dispenser swallowing the extended arms of pistons.
-Fixed problem with Block Dispenser not placing pistons properly.

Version 2.64

-Updated the mod to version 1.7.2 of Minecraft.
-Fixed slight rendering glitch with the Cauldron that would appear around the top edges.
-Changed Block Dispenser recipe to tone down the amount of mossy cobble used, and to use smooth stone at the base.
-Changed Hibachi recipe to use smooth stone at the base instead of cobble.
-Changed the Detector Block recipe to use smooth stone at the base instead of cobble.
-Changed the Mill Stone recipe to use smooth stone at the base instead of cobble.
-Changed the way the Mill Stone and sideways-facing Saws eject items so that they do not wind up on top of the device in question.

Version 2.63

-Fixed Block Dispenser destroying block if its inventory is full.
-Changed Block Dispenser recipe to include more mossy cobble to compensate for no longer requireing regular dispenser.
-Changed Saw Placement to be based on player orientation rather than on the block face the saw is placed on (just like Gear Boxes).
-Changed the way the Saw drops items it generates when sawing blocks to prevent them getting stuck in neighbouring blocks.
-Similar to the changes to the Saw, changed the way the Mill Stone drops processed items so they don't get lodged in neighbouring blocks.
-Change the Saw to drop a belt when it is destroyed through misuse.
-Fixed problem with "fcFaceGearBoxAwayFromPlayer" config file setting not working properly.
-Added ability for the Saw to process Corners into Gears.
-Added the ability for the Saw to process Companion Cubes.
-Added ability for Mill Stone to grind sugar-cane into sugar.
-Created custom icon for flour to help differentiate it from sugar.
-Created custom renderer for the Hand Crank when it is in item form to help differentiate it from a lever.
-Added text messages when there's not enough room around a Wind Mill or Water Wheel to place them.
-Changed Platforms and Anchors so that player and mobs won't "pop" on top of them from below.
-Changed Platforms and Anchors so that they deal damage to players and mobs if they descend on them.
-Fixed problems associated with having 2 Anchors connected to Platforms within 2 blocks of each other resulting in Platforms being lifted incorrectly by connected Pullies.
-Added the ability for the Cauldron to "swallow" items dropped on top of it, just like a Hopper.
-Changed Nethercoal recipe to only produce 1 piece of coal instead of 2 for balance purposes.

Version 2.62

-Fixed shimmering rendering problem on Platform when viewed from a distance.
-Fixed problem with moving Anchor occasionally breaking the rope it's attached to for no discernable reason.
-Fixed gaps in Rope that would occasionally form above an Anchor when the connected Pulley was rapidly powered on and off.
-Powered cake.

Version 2.61

-Changed the crafting recipes for Platforms to use Wicker for the top and bottom surfaces.
-Adjusted the rendering of Platforms to fit the change to the Wicker recipe.
-Added custom inventory renderer for the Platform.
-Changed Mill Stone texture to make it more obvious that it needs to be powered from the top or bottom.
-Fixed Block Detector not being able to see moving Anchors and Platforms.
-Added config file setting to change the way Gear Boxes place so that the output faces away from you.
-Changed the Detector Block recipe to use one lapis block instead of two.
-Added *small* chance that Hemp Seeds will drop when you destroy tall grass.
-Changed the way items pass over filtered Hoppers.  They no longer need to descend a level to continue.
-Changed the way mechanical devices update there state to try to avoid problems with them falling out of sync.  This affect the Gear Box, the Hopper, and the Pulley.
-Fixed items popping on top of Platforms when they are lowered onto them.
-Food is now turned into "Foul Food" when you put Dung into a Heated cauldron with it.

Version 2.60

-Added the Platform.
-Added the Pulley.
-Fixed crash bug when you right clicked on a Wind Mill with nothing in your hand.
-Changed Nethercoal recipe to be shapeless.
-Fixed Block Dispenser to not be able to swallow the purple nether-portal blocks.
-Eliminated the need for a seperate Anchor item.  Similar to what I did for the Axle in version 2.10, please place any Anchor items you may have in your inventory into the world, and then re-harvest them to convert them to the proper block type.  If you have an anchor that still looks like a 2D bitmap in your inventory, then this needs to be done as I will recycle the item ID in a future release.
-Changed Block Dispenser Recipe to no longer require a regular dispenser at its centre.

Version 2.59

-Adjusted output of Mill Stone when grinding wool to match changes that Mojang recently made to the string to wool recipe.
-Added growling sound to wolves when they produce dung to help distinguish the event from background mechanical noise.
-Tweaked Gear Box placement code to always orient opposite the face of the block you place it on.  This should make Gear Box placement much more consistent and intuitive.
-Got rid of a couple of custom textures for the mod that were duplicates of ones already found in the game to save on Texture IDs. This affects the bottom of the cauldron and the bottom of the Hibachi.
-Created new custom icon for Rope.
-Added collision to drying cement so that you can walk over it instead of just passing right through it.
-Changed Cement to whimper when poured, and to scream when powered by redstone (just like the old Booster Blocks used to).
-Totally removed placement restrictions on the hatch.  It can now be placed anywhere, with or without a supporting side-block (before it just wouldn't be removed if the side-block was).
-Fixed Block Dispenser processing of snow blocks.
-Changed Block Dispenser to be able to swallow uneaten cake.  However, cake that has slices already eaten from it will still be destroyed if the Block Dispenser attempts to swallow it.
-Changed Block Dispenser to be able to dispense the Hatch.
-Changed Block Dispenser to be able to pick-up clay blocks.
-Fixed the Block Dispenser being able to swallow mob spawners.  Sorry guys, this felt way too much like a cheat to me.
-Changed Block Dispenser to fire its inventory contents in order instead of randomly.  This basically allows you to create sequences of blocks that you wish to place and could even be used to create multi-frame animations using multiple Block Dispensers and colored wool.  There's now an icon in the Dispenser's inventory to indicate which slot will be dispensed next, and manually changing the inventory of the dispenser will reset this indicator to the first inventory slot.

Version 2.58

-Quick bug-fix for problems with converting gravel into sand and flint with the Hopper filter.


Version 2.575

-Changed Wolves so they will not produce Dung or Wolf Chops, or consume loose food, if you are playing multiplayer.
-Added the ability for Wicker to separate gravel into flint and sand when used as a filter on the Hopper.
-Added config file setting to disable the axe modifications, for compatibility with other mods.
-Added the tanning process and Tanned Leather.
-Added the Strap.
-Added the Belt.
-Changed crafting recipe for the Saw to use a Belt.
-Added custom icon for Scoured Leather.
-Fixed problem with wolves cannibalising their own flesh as they die.
-Added wolves turning rabid if you try to feed them Wolf Chops.
-Changed pet Wolves to ditch their collar and display the angry texture if you piss them off.
-Added ability to use clay as "filler" in the Hopper.  The Hopper won't eject clay, so you can fill inventory slots with it to change the Hopper's effective capacity and how long it takes to fill up.
-Removed the placement restrictions on the Anchor, as, like with the hatch, they were serving no useful purpose in a game where blocks of stone can hang suspended in mid-air anyways.

Version 2.55

-Modified the hatch in vanilla Minecraft so that it is no longer destroyed when the block next to it is.  This allows the placement of hatches in the middle of floors, and makes them more versatile overall without affecting their functionality in any other way.
-Added particles to the blade of the Saw to indicate when it is getting mechanically powered.
-Changed Dung production to take into account light levels.  Wolves now output more Dung in very low light conditions (light level of 5 and below).
-Adjusted the overall rate of dung production.  An unfed wolf should now produce Dung on average once every 4 in-game days.  A fed wolf, once a day.  A fed wolf in the dark, twice a day.
-Made the recipe for making two panels into one wood or stone block, shapeless.  This means the panels no longer need to be placed side by side in the crafting grid, but that if you have two panels in any two seperate squares of the grid, they can form a block.
-Added shapeless conversion recipes to convert 2 pieces of Moulding into 1 wood Panel, and 2 corners into 1 piece of Moulding.
-Added ability to color wool and Wind Mills brown using Dung through the usual methods for dye. You can't do it to sheep however, as they tend to react rather badly when you try to rub Dung all over them.
-Changed Hopper to only deposit items into the first slot of a furnace.  This allows for the smelting of stacks greater than 64 items, or the consecutive smelting of different kinds of items in the same furnace.
-Added the Grate as an item.
-Added Wicker as an item.
-Added an extra inventory slot to the Hopper in which you may place various items that act as a filter on what items the hopper will "swallow".  You can use a ladder, a hatch, a Grate, or Wicker as a filter.

Version 2.50

-Added Dung.
-Fixed problem with Fishing Rod displaying as a gear when the line is cast.
-Tweaked Rope item icon to make it more visible.
-Changed wolf to be able to consume nearby food laying on the ground.
-Fixed problem with Detector Block occasionally not detecting precipitation quickly enough to prevent damage to Gear Boxes attached to Wind Mills. 


Version 2.40

-Added the Wind Mill.  For real this time :)
-Added Fabric made of Hemp Fibers.
-Changed the name of the Wind Mill Blade to the 'Sail'.
-Changed the crafting recipe for the Sail to use Fabric instead of Wool.
-Added the ability to individually color each blade of the Wind Mill with dye.
-Changed Detector Block to properly sense snow falling if it is facing upwards.
-Changed Wind Mill to spin out of control in snow storms.

Version 2.31

-Updated the mod to version 1.6.6 of Minecraft.
-Modified properties of all wood-based blocks in the mod so that the axe would be an effective tool on them.
-Also modified the same for all wood based-blocks in the vanilla game so that axes generally behave as you would expect (this affects the note block, wood stairs, work bench, sign, wood door, added wind mills, juke box, fence, pumpkin, Jack'O'Lantern, and the trap door) instead of not working in weird instances as was typical of the game before this change. 

Version 2.30

-Reduced drag on carts without riders.  This effectively increases the distance such a cart can travel without losing speed from 6 blocks between powered rails, to 12 blocks.
-Increased the hardness of Panels.
-Added the ability for the saw to cut Panels into Moulding, and Moulding into Corners.
-Fixed Saw to not be able to be powered from the direction in which its blade is facing.
-Added the ability for the Saw to process Sugar Cane, Wheat, and Hemp.

Version 2.25

-Updated the mod to version 1.6.5 of Minecraft.
-Isolated the code for the Block Dispenser from the regular Dispenser.  This was largely an internal change to aid in updating and to allow for future changes, with the only noticable effect being that the Block Dispenser Gui now correctly displays "Block Dispenser" instead of the old "Dispenser".
-Added shift-click functionality for transferring to and from inventory of the Block Dispenser.
-Added crafting recipe to convert 2 Omni-Slabs back into a block (either smooth stone or wood) by placing them side by side in the crafting area.
-Removed the ability to grind wood into wood Omni-Slabs in the Mill Stone, since you can now create them with the Saw, and it's really not the intent of the Mill to be used for solid blocks like this.  You can still create the smoothstone Omni-Slabs in this manner however (at least for now).
-Fixed problem with mobs and players taking damage from sides of the Saw other than where the blade was located.  Note that this will likely require adjustments to any mob-grinders that involve the Saw.
-Optimized the Water Wheel to only perform updates of certain costly aspects of its state far less frequently.  Theoretically, this should allow for placement of about 20 times as many water wheels without any drop in preformance. It wasn't a problem before, but now it's REALLY not a problem ;)
-Renamed Omni-Slab to the "Panel", because "Omni-Slab" just sounded idiotic, and I was beginning to feel more and more like a tard every time I said it :)
-Changed Block Dispenser so that it could swallow Glow Stone blocks intact.
-Changed Detector Block so that it could instantly react to trees growing in front of it.
-Added Better Than Wolves themed character-skin to the download for those of you who want to show your support for the mod in-game or in SMP :)

Version 2.20

-Added the Saw.
-Modified the Mill Stone to ALWAYS eject ALL processed items to the sides of the mill.  This opens the door to automated milling.
-Fixed problem with Block Dispenser generating pink particles when operating in fron of a Detector Block.
-Fixed Block Dispenser being able to pick-up fire, although I have to admit, it was kinda cool :)
-Changed name of Lens to "NOT A BLOCK" so that people that hack their inventories hopefully stop bothering me about it.  Disabled the crafting recipe as well, although I don't think anyone had discovered it (I had forgotten it was in there), and changed the texture to horrid day-glow pink to further hammer the point home :)
-Changed Item Render for Omni-Slab to make it easier to distringuish from a regular slab.


Version 2.10

-Added the Hopper.
-Changed Detector Block to trigger if it is facing upwards and rain or snow falls on it.  I couldn't test with snow however (rain works fine), so if someone happens to run into a snow-storm and could let me know if it works, I'd be much obliged :)
-Reviewed all the blocks in the mod and made sure they had appropriate hit-effect textures.
-Added functionality to Gear Box where if it is receiving redstone power, it disengages the gears and will not output any power, regardless of the input state.  This effectively allows you to turn mechanical power on and off through redstone control.
-The Hand Crank now breaks if you try to power more than one device with it simultaneously.
-The Axle now breaks into component parts if it is powered in an inappropriate way (for example, a total axle length of over 3 blocks).
-The Mill Stone and Cauldron now eject their contents when they are destroyed (like chests or the Block Dispenser).
-Created custom renderer for Axle block in ineventory.
-Eliminated the need for the Axle Item (the one that looks like a stick).  Please place any items of this type you have in the world, and then remove the block again to reset them to the appropriate state.  The ItemID will be recycled in future versions of the mod.
-Changed the Water Wheel to not be stackable.  I think it's a large enough object to warrant this :)

Version 2.01

WARNING: Version 2.01 of this mod requires a reinstall of the mod onto a clean copy of Minecraft!  Many base-class modifications have been eliminated, so installing over an old copy will likely result in a crash.  ALSO: The old Minecart Pressure Plates and Soul Boosters have been completely eliminated from this version.  MAKE SURE YOU ELIMINATE ALL INSTANCES OF THESE ITEMS FROM YOUR SAVE GAME BEFORE INSTALLING THIS VERSION.

-Added Axle
-Added Gear Box
-Added Water Wheel
-Changed gear recipe to use fewer sticks.
-Added icon for hemp. Thanks to Battosay for the texture (modified)!
-Completely eliminated the old Minecart Booster and Minecart Pressure Plates from the mod.
-Eliminated base-class modifications to: EntityFallingSand.class, EntityMinecart.class, ItemBlock.class, and ItemReed.class.

Version 1.87

-Added ability for player to retract rope from an anchor, by right clicking on it with anything other than a rope in his hand (Thanks to Thalmane for suggesting this!)
-Added ability for Mill Stone to convert wool blocks into string.
-Added ability for Mill Stone to "process" Companion Cubes.
-Added custom Donut icon (thanks to Craftineer for the texture!)
-Companion cubes now show their appreciation for being put out of their misery.
-Boosted resistance of Anchor to make it more obvious that it needs to be destroyed with a Pick.

Version 1.86

-Fixed problem with the Item IDs for Hemp Fibers and Scoured Leather becoming confused.
-Fixed issue with the way food stacks in the Cauldron.


Version 1.85

-Added the Omni-Slab in wood and stone varieties.
-Upgraded the mod to the latest versions of MCP and Modloader to hopefully solve some compatibility issues.
-Modified title screen to display mod-specific instructions and dispense general wisdom.

Version 1.80

-Added the Anchor.
-Added the Rope.
-Changed Gear recipe to produce 2 Gears instead of just 1.
-Fixed problem with the Block Dispenser destroying specific kinds of items in its inventory if the block in front of it already contained something.
-Added collision to the base of the Hand Crank, so that you can now step up onto it, and don't just walk right through it.

Version 1.70

-Added the Hand Crank as a new block type.
-Added the Mill Stone as a new block type.
-Added Gears as an item.
-Added Flour as an Item.
-Added Hemp Fibers as an item.
-Added Scoured Leather as an item.
-Added smelting recipe to bake Bread from Flour in the furnace.
-Added Donuts (cook flour in the cauldron).
-Modified cauldron to spit out cooked items should its inventory be incapable of containing them.
-Changed Block Dispenser so it no longer spits out an item if there is a non-opaque object in front of it.

Version 1.61

-Tweaked the way hemp grows.  It should be *slightly* faster to grow now, especially in dense fields.
-Hemp now only grows under direct sunlight OR if there is a powerful light source up to two blocks above it.  Light-blocks to the side of the plant will no longer work.
-Made Companion Cubes and Hemp Crops flammable.  This means lightning can now send a whole field of hemp up in flames.  You can also set it ablaze when the authorities arrive.
-Rate of hemp seed drop when using hoe on grass is now based on the hoe's material (stone drops more than wood, etc.)  Consistent with other tools in the game, gold is the most efficient (but least durable), with diamond probably being the best mix between efficiency and durability.
-Added custom texture for hemp seeds to make them easier to differentiate from wheat.
-Changed Hibachi code to fix potential performance issues, and to stop it going out in the rain.
-Boosted the hardness of the Hibachi and Cauldron to be more consistent with other block types.
-Added ability for Block Dispenser to "process" chickens.

Version 1.60

-Added Hemp.
-Made changes to Block Dispenser which should allow it to plant seeds from other mods.

Version 1.52

-Fixed crash bug when Block Dispenser picked up redstone dust, which probably affected other block-types as well.

Version 1.51

-Fixed problem with block dispenser not properly handling coloured wool.  This should also resolve potential problems with different sapling types and other similar blocks that may be included in the game in the future, or which are features in other mods.
-Fixed problem with multiple Block Dispensers being able to swallow entities (minecarts, wolves, etc.) at the same time.
-Changed Block Dispenser to not dispense *anything* (objects and entities included), if the block in front of it is blocked.  This may help in the construction of more complex mechanisms and is more consistent with overall behaviour.
-Fixed problem with light-blocks not powering each other indirectly.
-Fixed detector block interacting in weird ways with various other block types (redstone wire, crops, trees, etc.)
-Added sound effect to Detector Block when triggered.
-Added sound effect to Block Dispenser when it is dispensing/swallowing entities (like minecarts and boats).
-Added config file setting for using Minecraft default textures for light blocks.  This is for people using custom texture packs that feel the mod's custom textures clash with other in-game elements.


Version 1.50

-Added the Detector Block
-Disabled Minecart Pressure Plate functionality.  This is likely the last version they'll be in the game in any way shape or form, and I will soon recycle their block ids (along with the booster block).  If you haven't removed them from your worlds yet: DO IT SOON!!!!
-Changed threshold value on angle when placing Companion Cube and Block Dispenser so that they aren't accidentally placed facing up or down as frequently.  You'll have to be looking up or down at a steeper angle now to place them in the corresponding directions.
-Removed maximum value of 255 on block and item IDs in the config file for increased compatibility with Minecraft Extended mod.

Version 1.40

-Added new detector rail-types: wood and obsidian, and modified the way the normal (stone) detector rails works.  Wood triggers on any minecart.  Stone triggers on any minecart containing something (chest, furnace, or mob).  Obsidian only triggers if a minecart contains a player.
-Changed Iron Pressure Plates to Obsidian Pressure Plates.  For greater visibility contrast relative to stone pressure plates, because it makes sense that it takes more weight to move obsidian than stone (not so much with iron), to give an in-game use for obsidian, and because it's impossible to see the difference between a stone and iron detector rail (given how small the pressure plate is on the rail).
-Disabled crafting recipes for minecart pressure plates (since they are replaced by the detector rails), and when a minecart pressure plate already in the game is destroyed, it now drops its constituent resources so that players may recover them.  Note that these blocks will be completely removed from the mod in a future version so it is in your best interest to recover these resources now before they dissapear (same with the old minecart boosters).
-Completely disabled minecart booster functionality in ongoing process of phasing them out.  If you haven't cleared them out of your saves yet, and recovered the resources, now is the time to do it before they are completely gone.
-Fixed problem with nethercoal recipe that didn't allow it to be crafted in any slot.
-Reorganized the way the mod assigns block and item ids, to hopefully resolve an incompatibility problem with other mods.
-Added ability for the Dispenser Block to swallow minecarts, boats...and wolves.
-Added the Companion Cube.


Version 1.31

-Created seperate texture directory for the mod to make tracking down the graphics files associated with it easier.
-Retextured the Hibachi, and replaced the iron in the crafting recipe with cobble.  I think this fits the idea of the Hibachi being an "open-top furnace" and makes sense since stone would melt at higher temperatures than iron.  It also reduces the mod's overdependance on iron.  
-Retextured Cauldron.  Meat your new friend.
-Retextured Light Block.
-Retextured the Block Dispenser.  Also toned down the amount of mossy cobble used in its crafting recipe.
-Retextured cement.


Version 1.30

-Added a new block type: Cauldrons.
-Added Wolfchops (raw and cooked).  Finally!  A use for wolves!
-Added Nethercoal item.


Version 1.25

-Updated mod to be compatible with version 1.5_01 of Minecraft.
-Removed the recipe for the minecart booster as its functionality is replaced by the booster-rail.
-When minecart boosters already in a save file are destroyed, they now return the ingredients originally used in crafting them.  This can be used by players to salvage any resources they may have already invested in the boosters.
-Changed code to properly register the blocks in the mod through modloader.
-Changed the crafting recipe for cement to use soulsand instead of goo since it is no longer used by the booster, can be more reliably found in-game (some folks seem to never be able to find slimes), and since it makes sense in terms of the logic behind the recipe.  Of course, Steve is now solidfying souls into concrete, with all the moral ramifications that entails...
-Removed mods dependency on modifying TileEntityDispenser base class.
-Removed mods dependency on modifying BlockFire base class.
-Fixed problems where block dispenser would occasionally pick-up flint when removing a gravel block, and cobble when picking up smoothstone.
-Changed block dispenser to be able to place blocks in squares containing entities (like wolves), and to not eject a block in item-form if the block in front of it is already occupied.
-Changed block dispenser to pick-up tnt instead of triggering it to make beahaviour more consistent with other block types, to make construction of semi and full auto cannons more interesting (while convenient the way they were, it really feels like they should have separate loading, priming, and firing mechanisms), and to provide the player with a method of desposing of placed TnT. 
-Changed block dispenser to be able to plant seeds.
-Added a slight turn-on and turn-off delay to Hibachi. Fixes a number of subtle problems with how they behave and makes their function a little more believable and consistent with the rest of the redstone elements in the game.
-Partially implemented cauldron.  This feature is not complete, but I wanted to release a version compatible with 1.5_01 as quickly as possible, so I disabled the crafting recipe and left it in as is.  If you edit it into the game (you can't build it legitimately), it will be an entirely nonfunctional and utterly boring block :)

Version 1.24

-Totally isolated cement code from BlockFLuid and BlockFlowing, eliminating this mod's need to change those base class files.
-Put in fixed distance limit on how far cement could spread.  This increases the distance it can flow on level ground, to aid in it's use in construction, while limiting its down-hill spread restricting its use for griefing and its potentail for disaster.
-Changed the way cement spreads.  Unlike other in-game fluids, it doesn't only flow towards downward slopes, but instead spreads in a circular pattern around the point at which it is put down.
-Changed various aspects about the way cement displays to make it more aesthetically pleasing.
-Added dry time to cement which causes it to slowly dry instead of just instantly turning solid after being placed.
-Added partially dry state to cement which changes the visual when it's about to solidify, and also blends its height closer to that of a full block to smooth the transition.


Version 1.23

-Fixed some problems with how cement spreads, toning down its tendancy to form "the tidal wave of doom"
-Removed custom cement texture and removed mod's dependecy on a modified terrain.png
-Fixed cement bucket recipe so that it can be built in any crafting slot

Version 1.22

-Modified Block Dispensers to be able to place/collect smooth stone without converting it to cobble.
-Toned down the amount of iron used in some of the crafting recipes, as it was extremely heavy.  This affects the recipes for the Hibachi, Minecart Boosters, and Minecart Plates.
-Fixed problem with minecart pressure plate running current to far too many neighboring blocks.  It now needs to have wire running directly to it to supply current.
-Fixed problem with Hibachi burning while submerged in liquid (water, lava & cement) through constantly reigniting.  The Hibachi will no longer burn under these conditions.

Version 1.21

-Added ability for player to orient Block Dispensers upwards and downwards
-Changed Block Dispensers to only accept direct redstone current to the dispenser block, or the block directly above it. 
-Changed Hibachi to accept Redstone current From Block Above


Version 1.20

-Added Block Dispensers.


Version 1.01

-Added ModLoader support.
-Added iron pressure plates.
-Added wood and iron versions of the minecart pressure plate (stone pressure plates from previous versions automatically convert to wood to preserve their functionality).

Version 1.0

-Initial Release